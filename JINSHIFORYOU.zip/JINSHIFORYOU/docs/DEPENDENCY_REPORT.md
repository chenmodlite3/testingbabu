# Dependency & Android Compatibility Report — JINSHIFORYOU APK

Source analyzed: `JINSHIABBU.py` (4084 lines, v3.0 PREMIUM).
The original file is shipped **unmodified** inside the APK (`app/src/main/python/JINSHIABBU.py`).
A thin adapter `engine.py` exposes every algorithm to the Kotlin UI without terminal prompts.

---

## 1. Python dependency audit

| Package | How JINSHIABBU uses it | Pure python? | Android (Chaquopy 17.1) | Installed via |
|---|---|---|---|---|
| `rich` | console UI only (panels, progress, tables) | yes | works | chaquopy pip |
| `gmalg` | ZUC + SM4 + block cipher base for PAK crypto | yes | works | chaquopy pip |
| `pycryptodome` (`Crypto`) | AES-CBC / SHA1 / padding in PAK index decrypt | C ext, Chaquopy wheels | works | chaquopy pip |
| `zstandard` | ZSTD block decompress/compress (CM_ZSTD, CM_ZSTD_DICT) | C ext, Chaquopy wheels | works | chaquopy pip |
| stdlib (`struct, zlib, hashlib, json, …`) | everywhere | — | supported | bundled |

Runtime auto-pip-install fallbacks inside JINSHIABBU (`pip install gmalg/pycryptodome`)
are dead code on Android (no pip at runtime). That is why all four packages are
declared at **build time** in `app/build.gradle.kts` → `chaquopy { defaultConfig { pip { … } } }`.

`engine.py` verifies each import and reports per-package status on the
Settings screen and via `health()`.

## 2. External tools

| Tool | Used for | Found in | On a phone APK |
|---|---|---|---|
| `unluac_patched.jar` | `.luac` bytecode → `.lua` text (`robust_decompile`, `decrypt_decompile_file`) | `SOURCE/` | **not available** — needs a JVM |
| `java` | runs unluac | system / bundled JDK path | **not available** in-app |
| `luac5.3` / `luac53` | `.lua` text → `.luac` bytecode (`recompile_lua_files`) | `SOURCE/` or PATH | **not available** — no lua compiler binary for Android bundled |

Consequences (visible in the app as status dots):

- **PAK unpack / repack / inject / build** → fully functional (pure python + gmalg + zstd).
- **Lua bytecode convert** (`bgmi_to_std`, `std_to_bgmi`, `convert_file`, `repack_to_pubg`) → fully functional (pure python).
- **Lua text decompile** → falls back to saving converted raw `.luac` into `LUA_EDIT/` (original code path, no data loss). Blocked for text output.
- **Lua compile (text → bytecode)** → blocked; needs `luac5.3`.

To enable full Lua text ops you would have to ship a lua 5.3 native binary
built for Android ABI and a JVM replacement (e.g. a native unluac port).
Neither is claimed working here — none is bundled, none is faked.

## 3. Function-by-function implementation status

| Original function(s) | Mobile op | Status |
|---|---|---|
| `TencentPakFile.dump` + `_raw_unpack_pak` (in `action_unpack_pak`) | `engine.unpack_pak` | implemented, same algorithms |
| `robust_decompile` + `convert_file` | `engine.decompile_selected` | implemented; text leg blocked without unluac |
| `recompile_lua_files` (uses `LUAC_PATH`, `repack_to_pubg`) | `engine.recompile_selected` / `recompile_all` | implemented; needs luac5.3 |
| `TencentPakFile.inject_files` + `detect_dominant_style` + backup logic (in `action_inject_lua`) | `engine.inject_lua` | implemented; backup preserved |
| `build_new_pak_from_template` (in `action_build_new_pak`) | `engine.build_new_pak` | implemented, target path parameter kept |
| `action_clean_all` | `engine.clean_all` | implemented (xvaLuex, temp std luac, pycache) |
| `get_real_files` / `get_unpack_files` / dir setup | `engine.list_files`, `setup_directories` | implemented |
| `select_language` / `STRINGS` | `engine.set_language` + Settings chips | implemented (en/ru/ar/zh) |
| `action_close_termux` | not ported | replaced by normal Android EXIT (no pkill) |
| Rich banner / border animation | — | replaced by Compose splash + themed UI (terminal-only rendering) |
| interactive `safe_input` prompts | — | replaced by Compose pickers/text fields |

## 4. Android-specific decisions

- **Workspace path** `/storage/emulated/0/Documents/JINSHIFORYOU` is kept from the
  original algorithms. Requires `MANAGE_EXTERNAL_STORAGE` ("All files access") on
  API 30+; legacy storage flag set for API 29. Settings screen deep-links to the
  permission page.
- **SAF** (`ActivityResultContracts.OpenDocument`) used for importing user files;
  files are copied to app cache then handed to `engine.import_file` so the python
  side only ever deals with real filesystem paths.
- **Threading**: all engine calls run on a single python worker thread
  (`PythonBridge.executor`); UI never blocks.
- **Python startup**: `Python.start(AndroidPlatform)` in `App.onCreate` via
  `PythonBridge.ensureStarted`.
- **Bytecode**: `pyc.src = false` so stack traces keep original line numbers.
- **ABIs**: arm64-v8a, armeabi-v7a, x86_64 (armeabi-v7a/x86 require python ≤3.11,
  which is why python version is pinned to 3.11).

## 5. Testing status

| Layer | Status |
|---|---|
| python syntax of `engine.py` + original | validated (CI + `scripts/validate.sh`) |
| XML resources / manifest | validated |
| unit tests (`FormatTest`) | implemented, run in CI |
| app launch + navigation | manual / on-device (compose navigation between 9 screens) |
| file import via SAF | on-device |
| PAK unpack/repack/inject/build against real game paks | **on-device required** — use your own paks in `PAK_ORIGINAL` |
| lua text decompile/compile | blocked on-device (see §2) — reported honestly in UI |
| GitHub Actions APK artifact | workflow uploads real `app-debug.apk`, fails loudly on compile error |

## 6. Build stack (pinned)

| Component | Version |
|---|---|
| AGP | 8.7.3 |
| Gradle | 8.9 |
| Kotlin | 2.0.21 (+ compose plugin) |
| Chaquopy | 17.1.0 |
| Python (in APK) | 3.11 |
| Compose BOM | 2024.12.01 |
| JDK (CI) | 17 |
| minSdk / targetSdk | 26 / 35 |
