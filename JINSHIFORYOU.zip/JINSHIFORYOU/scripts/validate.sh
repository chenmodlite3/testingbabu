#!/usr/bin/env bash
# Local validation for the JINSHIFORYOU project (runs in Termux or any Linux).
set -e
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

echo "== python syntax =="
python3 -m py_compile app/src/main/python/engine.py
python3 -m py_compile app/src/main/python/JINSHIABBU.py
echo "OK"

echo "== xml well-formed =="
python3 - <<'EOF'
import xml.etree.ElementTree as ET, glob, sys
files = glob.glob("app/src/main/**/*.xml", recursive=True)
for f in files:
    ET.parse(f)
    print("ok", f)
EOF

echo "== yaml =="
python3 - <<'EOF'
import sys
try:
    import yaml
    yaml.safe_load(open(".github/workflows/android.yml"))
    print("workflow yaml OK")
except ImportError:
    print("pyyaml not installed — skipping (workflow uses standard GH syntax)")
EOF

echo "== structure =="
for f in \
  settings.gradle.kts build.gradle.kts gradle.properties \
  app/build.gradle.kts app/src/main/AndroidManifest.xml \
  app/src/main/python/engine.py app/src/main/python/JINSHIABBU.py \
  app/src/main/java/com/jinshifyou/app/MainActivity.kt \
  .github/workflows/android.yml README.md
do
  test -f "$f" || { echo "MISSING: $f"; exit 1; }
done
echo "structure OK"
echo "ALL CHECKS PASSED"
