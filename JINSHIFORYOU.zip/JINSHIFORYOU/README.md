# JINSHIFORYOU — Android APK (v3.0)

Offline Android app built from the original `JINSHIABBU.py` terminal tool.
Kotlin + Jetpack Compose UI, Python engine embedded with Chaquopy.
No login, no Termux, no root — everything runs inside the APK.

- App name : **JINSHIFORYOU**
- Package  : `com.jinshifyou.app`
- Workspace: `/storage/emulated/0/Documents/JINSHIFORYOU/`
- Developer: @JINSHIFORYOU

---

## 1. What's inside

```
JINSHIFORYOU/
├── .github/workflows/android.yml   # browser build (GitHub Actions)
├── app/src/main/python/
│   ├── JINSHIABBU.py                # original engine — UNMODIFIED
│   └── engine.py                    # non-interactive adapter for the UI
├── app/src/main/java/com/jinshifyou/app/
│   ├── MainActivity.kt / App.kt     # entry + python bootstrap
│   ├── engine/PythonBridge.kt       # Chaquopy bridge + models
│   └── ui/…                         # compose screens (dark purple/cyan)
├── docs/DEPENDENCY_REPORT.md        # full dependency + compatibility report
└── scripts/validate.sh              # local checks
```

## 2. Features (dashboard)

| Screen | What it does | Status |
|---|---|---|
| UNPACK PAK | Tencent PAK parse + raw fallback → `PAK_UNPACK/` | fully working |
| LUA ENGINE | decompile (`robust_decompile`) / recompile (`recompile_lua_files`) | bytecode convert working; text decompile/recompile needs `unluac_patched.jar`+`java` and `luac5.3` (see report) |
| REPACK / INJECT | backup pak → `detect_dominant_style` → `inject_files` → `PAK_RESULT/` | fully working |
| BUILD NEW PAK | `build_new_pak_from_template` with optional target root path | fully working |
| FILE MANAGER | browse all 8 workspace folders, import any file via SAF, delete | fully working |
| LOGS | live python engine log stream | fully working |
| SETTINGS | language (en/ru/ar/zh), dependency status, storage access, clean, about | fully working |

Every visible button is wired to a real python operation. Nothing is decorative.

## 3. Build the APK in the browser (GitHub)

1. Create a new GitHub repository (public or private).
2. Upload **everything inside this `JINSHIFORYOU` folder** to the repo root
   (drag-and-drop on github.com works — keep `.github/` and `app/` structure).
3. Open the repo → **Actions** tab → select **Build JINSHIFORYOU APK**.
4. Press **Run workflow** (it also runs automatically on push to main/master).
5. When the run turns green: **Artifacts** → download `JINSHIFORYOU-v3.0-debug`.
6. Unzip the artifact on the phone → install the APK
   (allow "install from unknown apps" when asked).

Requirements on the runner are handled by the workflow itself:
JDK 17, Python 3.11 (for Chaquopy pip), Gradle 8.9, Android SDK (preinstalled on ubuntu-latest).

## 4. Build locally (optional)

```bash
# needs: JDK 17, Android SDK, python3.11, gradle 8.9
gradle :app:assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

Or open the folder in Android Studio and press Run.
`gradle/wrapper/gradle-wrapper.properties` is included so Android Studio
auto-downloads the correct Gradle.

## 5. First launch

1. Grant **All files access** (MANAGE_EXTERNAL_STORAGE) when Android asks,
   or enable it from Settings → Apps → JINSHIFORYOU → Permissions → All files access.
   The engine reads/writes `/storage/emulated/0/Documents/JINSHIFORYOU/`.
2. The workspace folders are created automatically:
   `PAK_ORIGINAL  LUA_ORIGINAL  LUA_EDIT  COMPILED  PAK_UNPACK  PAK_RESULT  BACKUP  SOURCE`
3. Typical flow:
   - import a `.pak` into **PAK_ORIGINAL** (File Manager → IMPORT)
   - **UNPACK PAK** → output in `PAK_UNPACK/`
   - for Lua: import `.luac` into `LUA_ORIGINAL` → **LUA ENGINE → DECOMPILE**
   - edit the `.lua` files in `LUA_EDIT/`
   - **RECOMPILE** → files land in `COMPILED/`
   - **REPACK / INJECT** (choose pak + optional target path) → `PAK_RESULT/<pak>_MODIFIED.pak`

Originals are never overwritten: inject/build always writes a new file and
copies the original pak into `BACKUP/` first.

## 6. Troubleshooting

| Problem | Fix |
|---|---|
| Build fails at `pip install` | a native wheel is missing for your python version — pin versions in `app/build.gradle.kts` chaquopy.pip, re-run |
| Build fails "SDK location not found" | on GitHub Actions this doesn't happen; locally install Android SDK + set `ANDROID_HOME` |
| App opens, engine OFFLINE | grant All files access, then Settings → RELOAD ENGINE STATUS; full error is on the Logs screen |
| LUA decompile says blocked | needs `unluac_patched.jar` in `SOURCE/` AND a JVM — not available inside a normal APK; bytecode convert still works |
| LUA recompile says blocked | needs a `luac5.3` binary; Android has no lua compiler — see report for options |
| APK not installing | enable unknown sources; if "app not installed", uninstall any older com.jinshifyou.app first |

## 7. Validation

```bash
bash scripts/validate.sh
```

Runs python syntax checks, XML well-formedness and structure checks.
Unit tests (`FormatTest`) run in CI via `gradle :app:testDebugUnitTest`.

See `docs/DEPENDENCY_REPORT.md` for the full function-by-function
implementation status and Android compatibility notes.
