# Chaquopy Python engine
-keep class com.chaquo.python.** { *; }
-keep class com.jinshifyou.app.engine.** { *; }
-dontwarn com.chaquo.python.**
