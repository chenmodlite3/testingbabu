package com.jinshifyou.app.ui.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val key: String,
    val title: String,
    val icon: ImageVector,
) {
    data object Splash : Screen("splash", "SPLASH", Icons.Default.Info)
    data object Dashboard : Screen("dashboard", "DASHBOARD", Icons.Default.Home)
    data object Unpack : Screen("unpack", "UNPACK PAK", Icons.Default.Launch)
    data object LuaEngine : Screen("lua", "LUA ENGINE", Icons.Default.Code)
    data object Inject : Screen("inject", "REPACK / INJECT", Icons.Default.Build)
    data object BuildPak : Screen("buildpak", "BUILD NEW PAK", Icons.Default.List)
    data object FileManager : Screen("files", "FILE MANAGER", Icons.Default.Folder)
    data object Logs : Screen("logs", "LOGS", Icons.Default.List)
    data object Settings : Screen("settings", "SETTINGS", Icons.Default.Settings)
}

val bottomTabs = listOf(Screen.Dashboard, Screen.FileManager, Screen.Logs, Screen.Settings)

val dashboardCards = listOf(
    Screen.Unpack,
    Screen.LuaEngine,
    Screen.Inject,
    Screen.BuildPak,
)
