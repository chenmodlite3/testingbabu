package com.jinshifyou.app.engine

object Format {
    fun humanSize(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        var value = bytes.toDouble()
        val units = arrayOf("KB", "MB", "GB", "TB")
        for (unit in units) {
            value /= 1024.0
            if (value < 1024.0 || unit == "TB") {
                return "%.1f %s".format(value, unit)
            }
        }
        return "$bytes B"
    }

    fun statusColorName(ok: Boolean): String = if (ok) "ONLINE" else "OFFLINE"

    fun shortError(raw: String): String {
        val first = raw.lineSequence().firstOrNull().orEmpty()
        return if (first.length > 160) first.take(160) + "…" else first
    }
}
