package com.jinshifyou.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val JinsDarkColors = darkColorScheme(
    primary = NeonPurple,
    onPrimary = BgDeep,
    primaryContainer = DeepPurple,
    onPrimaryContainer = TextPrimary,
    secondary = IceCyan,
    onSecondary = BgDeep,
    secondaryContainer = BgPanelLight,
    onSecondaryContainer = IceCyan,
    tertiary = HotPink,
    onTertiary = BgDeep,
    background = BgDeep,
    onBackground = TextPrimary,
    surface = BgPanel,
    onSurface = TextPrimary,
    surfaceVariant = BgCard,
    onSurfaceVariant = TextSecondary,
    error = ErrRed,
    onError = TextPrimary,
    outline = Muted,
)

@Composable
fun JinsifyouTheme(content: @Composable () -> Unit) {
    // Always dark — this is a modding terminal, not a consumer app.
    @Suppress("UNUSED_EXPRESSION")
    isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = JinsDarkColors,
        typography = JinsTypography,
        content = content,
    )
}
