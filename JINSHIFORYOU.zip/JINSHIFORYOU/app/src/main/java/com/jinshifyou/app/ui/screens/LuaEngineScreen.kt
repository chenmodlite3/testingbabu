package com.jinshifyou.app.ui.screens

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.FileEntry
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.BusyOverlay
import com.jinshifyou.app.ui.components.FileList
import com.jinshifyou.app.ui.components.GhostButton
import com.jinshifyou.app.ui.components.JinsButton
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.components.SectionTitle
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.WarnOrange
import org.json.JSONArray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LuaEngineScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var files by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }

    val kind = if (tab == 0) "lua_original" else "lua_edit"

    fun refresh() {
        PythonBridge.call("list_files", kind) { r ->
            files = r.objects().map { FileEntry.from(it) }
            selected = emptySet()
        }
    }

    LaunchedEffect(reload, tab) {
        refresh()
        PythonBridge.call("health") { r ->
            notice = when {
                r.ok && r.data?.optJSONObject(0)?.optBoolean("lua_compile") == true ->
                    "luac + java found — full decompile/compile available"
                r.ok && r.data?.optJSONObject(0)?.optBoolean("pak_core") == true ->
                    "bytecode convert works · text decompile blocked (no unluac/java) · compile blocked (no luac5.3)"
                else ->
                    "python deps missing — pak/lua ops offline"
            }
        }
    }

    val pickLua = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            importViaSaf(context, uri, kind) { msg ->
                status = msg
                busy = false
                reload++
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "back", tint = IceCyan)
            }
            ScreenHeader("LUA ENGINE", "decompile · recompile · bytecode convert")
        }

        TabRow(
            selectedTabIndex = tab,
            containerColor = BgDeep,
            contentColor = IceCyan,
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("DECOMPILE") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("RECOMPILE") })
        }

        Spacer(Modifier.height(10.dp))
        SectionTitle(if (tab == 0) "LUA_ORIGINAL  (.luac / .slua / .lua)" else "LUA_EDIT  (.lua edited files)")

        FileList(
            files = files,
            selected = selected,
            onToggle = { name ->
                selected = if (name in selected) selected - name else selected + name
            },
            emptyText = if (tab == 0) "LUA_ORIGINAL empty — import bytecode files" else "LUA_EDIT empty — decompiled output lands here",
        )

        Spacer(Modifier.height(12.dp))
        GhostButton(if (tab == 0) "IMPORT .LUAC/.LUA FILES" else "IMPORT EDITED .LUA") {
            pickLua.launch(arrayOf("*/*"))
        }
        Spacer(Modifier.height(8.dp))
        GhostButton("REFRESH") { reload++ }
        Spacer(Modifier.height(14.dp))

        JinsButton(
            text = if (tab == 0) "DECOMPILE SELECTED (${selected.size})" else "RECOMPILE SELECTED (${selected.size})",
            enabled = selected.isNotEmpty() && !busy,
            loading = busy,
        ) {
            busy = true
            status = if (tab == 0) "decompiling…" else "recompiling…"
            val arr = JSONArray()
            selected.forEach { arr.put(it) }
            val op = if (tab == 0) "decompile_selected" else "recompile_selected"
            PythonBridge.call(op, arr.toString()) { r ->
                status = if (r.ok) r.message else "ERROR: ${r.message}"
                busy = false
                reload++
            }
        }

        if (tab == 1) {
            Spacer(Modifier.height(8.dp))
            GhostButton("RECOMPILE ALL") {
                busy = true
                PythonBridge.call("recompile_all") { r ->
                    status = if (r.ok) r.message else "ERROR: ${r.message}"
                    busy = false
                    reload++
                }
            }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(
                status,
                color = if (status.startsWith("ERROR")) ErrRed else NeonGreen,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        if (notice.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(notice, color = WarnOrange, style = MaterialTheme.typography.labelSmall)
        }

        BusyOverlay(busy, "working — see Logs for live output")
        Spacer(Modifier.height(20.dp))
        Text(
            "decompile: LUA_ORIGINAL → LUA_EDIT  ·  recompile: LUA_EDIT → COMPILED",
            color = IceCyan,
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
