package com.jinshifyou.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.Format
import com.jinshifyou.app.engine.Health
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.GradientCard
import com.jinshifyou.app.ui.components.GhostButton
import com.jinshifyou.app.ui.components.JinsButton
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.components.SectionTitle
import com.jinshifyou.app.ui.components.StatusDot
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.Muted
import com.jinshifyou.app.ui.theme.NeonPurple
import com.jinshifyou.app.ui.theme.TextPrimary
import com.jinshifyou.app.ui.theme.TextSecondary

private val languages = listOf("en" to "English", "ru" to "Русский", "ar" to "العربية", "zh" to "中文")

@Composable
fun SettingsScreen(onExit: () -> Unit) {
    val context = LocalContext.current
    var health by remember { mutableStateOf<Health?>(null) }
    var lang by remember { mutableStateOf("en") }
    var status by remember { mutableStateOf("") }

    fun load() {
        PythonBridge.call("health") { r -> health = Health.from(r) }
    }

    LaunchedEffect(Unit) { load() }

    val h = health

    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        ScreenHeader("◈ SETTINGS", "engine · language · storage · about")

        SectionTitle("LANGUAGE")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            languages.forEach { (code, label) ->
                GhostButton(
                    text = label,
                    modifier = Modifier.weight(1f),
                    enabled = lang != code,
                ) {
                    PythonBridge.call("set_language", code) { r ->
                        lang = code
                        status = if (r.ok) r.message else "ERROR: ${r.message}"
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("ENGINE DEPENDENCIES")
        GradientCard {
            Column {
                StatusDot("python engine", h?.engineOk == true)
                Spacer(Modifier.height(4.dp))
                StatusDot("gmalg (ZUC/SM4)", h?.deps?.get("gmalg") == true)
                Spacer(Modifier.height(4.dp))
                StatusDot("pycryptodome", h?.deps?.get("pycryptodome") == true)
                Spacer(Modifier.height(4.dp))
                StatusDot("zstandard", h?.deps?.get("zstandard") == true)
                Spacer(Modifier.height(4.dp))
                StatusDot("rich", h?.deps?.get("rich") == true)
                if (h?.engineOk == true && h.importError.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(h.importError, color = ErrRed, style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("EXTERNAL TOOLS (LUA TEXT OPS)")
        GradientCard {
            Column {
                StatusDot("luac5.3 (recompile)", h?.luaCompile == true)
                Spacer(Modifier.height(4.dp))
                StatusDot("unluac jar (decompile text)", h?.luaText == true)
                Spacer(Modifier.height(6.dp))
                Text(
                    "without these, PAK ops + bytecode convert still work fully. " +
                        "drop luac5.3 / unluac_patched.jar into PAK_ORIGINAL/../SOURCE to enable.",
                    color = Muted,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("STORAGE")
        GradientCard {
            Column {
                Text(
                    h?.workspace ?: "/storage/emulated/0/Documents/JINSHIFORYOU",
                    color = TextPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                )
                Spacer(Modifier.height(8.dp))
                GhostButton("OPEN ANDROID APP SETTINGS (ALL FILES ACCESS)") {
                    val intent = if (Build.VERSION.SDK_INT >= 30) {
                        Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}"))
                    } else {
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    }
                    try {
                        context.startActivity(intent)
                    } catch (_: Throwable) {
                        context.startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                }
                Spacer(Modifier.height(8.dp))
                GhostButton("CLEAN WORKSPACE (xvaLuex/temp/pycache)") {
                    PythonBridge.call("clean_all") { r ->
                        status = if (r.ok) r.message else "ERROR: ${r.message}"
                    }
                }
            }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                status,
                color = if (status.startsWith("ERROR")) ErrRed else NeonPurple,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        Spacer(Modifier.height(14.dp))
        SectionTitle("ABOUT")
        GradientCard {
            Column {
                Text("JINSHIFORYOU", style = MaterialTheme.typography.titleLarge, color = IceCyan)
                Text(
                    "${h?.version ?: "v3.0"} · DEVELOPER @JINSHIFORYOU · LIFETIME ACCESS",
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                )
                Text(
                    "android build: kotlin + jetpack compose + chaquopy ${BuildConfigCompat.version}",
                    color = Muted,
                    style = MaterialTheme.typography.labelSmall,
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        JinsButton(text = "EXIT APP", primary = false, onClick = onExit)
        Spacer(Modifier.height(8.dp))
        GhostButton("RELOAD ENGINE STATUS") { load() }
        Spacer(Modifier.height(20.dp))
    }
}

private object BuildConfigCompat {
    const val version = "17.1"
}
