package com.jinshifyou.app

import android.app.Application
import com.jinshifyou.app.engine.PythonBridge

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Start the embedded Python runtime as early as possible.
        try {
            PythonBridge.ensureStarted(this)
        } catch (_: Throwable) {
            // surfaced later via health() on the dashboard
        }
    }
}
