package com.jinshifyou.app.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.Health
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.Muted
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.NeonPurple
import com.jinshifyou.app.ui.theme.RoyalPurple
import com.jinshifyou.app.ui.theme.TextPrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onReady: () -> Unit,
) {
    var statusText by remember { mutableStateOf("BOOTING PYTHON ENGINE…") }
    var health by remember { mutableStateOf<Health?>(null) }

    val transition = rememberInfiniteTransition(label = "pulse")
    val glow by transition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow",
    )

    LaunchedEffect(Unit) {
        statusText = "INITIALIZING RUNTIME…"
        delay(400)
        statusText = "LOADING JINSHI ENGINE…"
        val result = PythonBridge.callSync("health")
        health = Health.from(result)
        statusText = if (result.ok && health?.engineOk == true) {
            "ENGINE ONLINE · ${health?.version ?: ""}"
        } else {
            "ENGINE DEGRADED — CHECK SETTINGS"
        }
        delay(1100)
        onReady()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.radialGradient(listOf(RoyalPurple.copy(alpha = 0.35f), BgDeep))),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(24.dp),
        ) {
            Text(
                "JINSHI",
                style = MaterialTheme.typography.displaySmall,
                color = NeonPurple.copy(alpha = glow),
                fontFamily = FontFamily.Monospace,
            )
            Text(
                "FORYOU",
                style = MaterialTheme.typography.displaySmall,
                color = IceCyan.copy(alpha = glow),
                fontFamily = FontFamily.Monospace,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "PAK TOOLS + LUA ENGINE",
                style = MaterialTheme.typography.labelLarge,
                color = Muted,
            )
            Spacer(Modifier.height(28.dp))
            Box(
                Modifier
                    .size(34.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(
                        Brush.sweepGradient(
                            listOf(NeonPurple, IceCyan, NeonGreen, NeonPurple)
                        )
                    )
                    .alpha(glow)
            )
            Spacer(Modifier.height(24.dp))
            Text(
                statusText,
                style = MaterialTheme.typography.labelSmall,
                color = when {
                    statusText.contains("ONLINE") -> NeonGreen
                    statusText.contains("DEGRADED") -> ErrRed
                    else -> TextPrimary
                },
                textAlign = TextAlign.Center,
            )
            Text(
                "@JINSHIFORYOU  ·  v3.0 PREMIUM",
                style = MaterialTheme.typography.labelSmall,
                color = Muted,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}
