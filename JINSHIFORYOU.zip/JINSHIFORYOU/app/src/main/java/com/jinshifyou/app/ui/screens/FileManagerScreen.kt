package com.jinshifyou.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.FileEntry
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.BusyOverlay
import com.jinshifyou.app.ui.components.GhostButton
import com.jinshifyou.app.ui.components.JinsButton
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.theme.BgCard
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.BgPanelLight
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.Muted
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.NeonPurple
import com.jinshifyou.app.ui.theme.TextPrimary

private val folders = linkedMapOf(
    "pak" to "PAK_ORIGINAL",
    "lua_original" to "LUA_ORIGINAL",
    "lua_edit" to "LUA_EDIT",
    "compiled" to "COMPILED",
    "unpacked" to "PAK_UNPACK",
    "result" to "PAK_RESULT",
    "backup" to "BACKUP",
    "source" to "SOURCE",
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun FileManagerScreen() {
    val context = LocalContext.current
    var kind by remember { mutableStateOf("pak") }
    var files by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(reload, kind) {
        PythonBridge.call("list_files", kind) { r ->
            files = r.objects().map { FileEntry.from(it) }
        }
    }

    val pickAny = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            importViaSaf(context, uri, kind) { msg ->
                status = msg
                busy = false
                reload++
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(16.dp),
    ) {
        ScreenHeader("FILE MANAGER", "/storage/emulated/0/Documents/JINSHIFORYOU")

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            folders.forEach { (k, label) ->
                FilterChip(
                    selected = kind == k,
                    onClick = { kind = k },
                    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                        selectedLabelColor = NeonPurple,
                        labelColor = Muted,
                    ),
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clip(RoundedCornerShape(14.dp))
                .background(BgCard),
            verticalArrangement = Arrangement.spacedBy(1.dp),
        ) {
            if (files.isEmpty()) {
                item {
                    Text(
                        "  folder is empty",
                        color = Muted,
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
            items(files, key = { it.name }) { f ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Text(
                        (if (f.isDir) "▸ " else "  ") + f.name,
                        color = if (f.isDir) IceCyan else TextPrimary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        maxLines = 1,
                    )
                    Text(
                        "${f.sizeH}  ·  ${f.mtime}",
                        color = Muted,
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        GhostButton("IMPORT FILE INTO ${folders[kind]}") { pickAny.launch(arrayOf("*/*")) }
        Spacer(Modifier.height(8.dp))
        GhostButton("DELETE LAST ENTRY") {
            val last = files.lastOrNull { !it.isDir } ?: files.lastOrNull()
            if (last == null) {
                status = "nothing to delete"
            } else {
                busy = true
                PythonBridge.call("delete_entry", "$kind/${last.name}") { r ->
                    status = if (r.ok) r.message else "ERROR: ${r.message}"
                    busy = false
                    reload++
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        GhostButton("REFRESH") { reload++ }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(
                status,
                color = if (status.startsWith("ERROR")) ErrRed else NeonGreen,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
        BusyOverlay(busy, "working…")
    }
}
