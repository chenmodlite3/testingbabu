package com.jinshifyou.app.engine

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

object PythonBridge {

    data class Result(val ok: Boolean, val message: String, val data: JSONArray?) {
        fun objects(): List<JSONObject> {
            val out = ArrayList<JSONObject>()
            if (data != null) {
                for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i)
                    if (o != null) out.add(o)
                }
            }
            return out
        }
    }

    private val appContext = AtomicReference<Context?>(null)
    private val executor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "py-engine").apply { isDaemon = true }
    }

    @Volatile
    private var started = false

    @Volatile
    private var module: com.chaquo.python.PyObject? = null

    fun ensureStarted(context: Context) {
        appContext.compareAndSet(null, context.applicationContext)
        if (started && module != null) return
        synchronized(this) {
            if (started && module != null) return
            val ctx = appContext.get() ?: return
            if (!Python.isStarted()) {
                Python.start(AndroidPlatform(ctx))
            }
            module = Python.getInstance().getModule("engine")
            started = true
        }
    }

    val isReady: Boolean get() = started && module != null

    fun call(op: String, vararg args: Any?, callback: (Result) -> Unit) {
        executor.execute {
            callback(callSync(op, *args))
        }
    }

    fun callSync(op: String, vararg args: Any?): Result {
        val mod = module ?: return Result(false, "python engine not started", null)
        return try {
            val py = mod.callAttr(op, *args)
            parse(py.toString())
        } catch (t: Throwable) {
            Result(false, t.message ?: t.javaClass.simpleName, null)
        }
    }

    private fun parse(raw: String?): Result {
        if (raw.isNullOrBlank()) return Result(false, "empty engine response", null)
        return try {
            val json = JSONObject(raw)
            Result(
                ok = json.optBoolean("ok", false),
                message = json.optString("message", ""),
                data = json.optJSONArray("data"),
            )
        } catch (t: Throwable) {
            Result(false, "bad engine json: ${t.message}", null)
        }
    }

    fun logsSince(index: Int): Pair<Int, List<LogLine>> {
        val mod = module ?: return index to emptyList()
        return try {
            val py = mod.callAttr("get_logs", index)
            val json = JSONObject(py.toString())
            val next = json.optInt("index", index)
            val arr = json.optJSONArray("lines") ?: JSONArray()
            val lines = ArrayList<LogLine>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                lines.add(
                    LogLine(
                        i = o.optInt("i"),
                        lvl = o.optString("lvl", "info"),
                        msg = o.optString("msg", ""),
                        ts = o.optString("ts", ""),
                    )
                )
            }
            next to lines
        } catch (t: Throwable) {
            index to emptyList()
        }
    }

    fun copyToCache(context: Context, uri: Uri): String? {
        return try {
            val resolver = context.contentResolver
            var name = "import_${System.currentTimeMillis()}"
            resolver.query(uri, null, null, null, null)?.use { cursor ->
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && cursor.moveToFirst()) {
                    cursor.getString(idx)?.let { if (it.isNotBlank()) name = it }
                }
            }
            val dir = File(context.cacheDir, "imports").apply { mkdirs() }
            val out = File(dir, name)
            resolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            out.absolutePath
        } catch (t: Throwable) {
            null
        }
    }
}

data class LogLine(val i: Int, val lvl: String, val msg: String, val ts: String)

data class FileEntry(
    val name: String,
    val size: Long,
    val sizeH: String,
    val isDir: Boolean,
    val mtime: String,
) {
    companion object {
        fun from(json: JSONObject): FileEntry = FileEntry(
            name = json.optString("name", "?"),
            size = json.optLong("size", 0L),
            sizeH = json.optString("size_h", "0 B"),
            isDir = json.optBoolean("is_dir", false),
            mtime = json.optString("mtime", ""),
        )
    }
}

data class Health(
    val engineOk: Boolean = false,
    val importError: String = "",
    val version: String = "",
    val pakCore: Boolean = false,
    val luaText: Boolean = false,
    val luaCompile: Boolean = false,
    val deps: Map<String, Boolean> = emptyMap(),
    val workspace: String = "",
    val luacPath: String = "",
    val javaPath: String = "",
    val unluacPath: String = "",
) {
    companion object {
        fun from(r: PythonBridge.Result): Health {
            val d = r.data?.optJSONObject(0) ?: return Health(engineOk = false, importError = r.message)
            val depsJson = d.optJSONObject("deps")
            val deps = mutableMapOf<String, Boolean>()
            if (depsJson != null) {
                val keys = depsJson.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    deps[k] = depsJson.optBoolean(k, false)
                }
            }
            return Health(
                engineOk = d.optBoolean("engine_ok", false),
                importError = d.optString("import_error", ""),
                version = d.optString("version", "v3.0"),
                pakCore = d.optBoolean("pak_core", false),
                luaText = d.optBoolean("lua_text_decompile", false),
                luaCompile = d.optBoolean("lua_compile", false),
                deps = deps,
                workspace = d.optString("workspace", ""),
                luacPath = d.optString("luac_path", ""),
                javaPath = d.optString("java_path", ""),
                unluacPath = d.optString("unluac_path", ""),
            )
        }
    }
}
