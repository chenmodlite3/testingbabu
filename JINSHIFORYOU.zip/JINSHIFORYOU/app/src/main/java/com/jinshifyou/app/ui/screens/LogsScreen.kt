package com.jinshifyou.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.LogLine
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.GhostButton
import com.jinshifyou.app.ui.components.LogPanel
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.Muted
import kotlinx.coroutines.delay

@Composable
fun LogsScreen() {
    var lines by remember { mutableStateOf<List<LogLine>>(emptyList()) }
    var cursor by remember { mutableIntStateOf(0) }
    var paused by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }

    LaunchedEffect(tick, paused) {
        while (true) {
            if (!paused && PythonBridge.isReady) {
                val (next, newLines) = PythonBridge.logsSince(cursor)
                cursor = next
                if (newLines.isNotEmpty()) {
                    lines = (lines + newLines).takeLast(400)
                }
            }
            delay(700)
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(16.dp),
    ) {
        ScreenHeader("◈ LOGS", "live python engine output")

        LogPanel(lines)

        Spacer(Modifier.height(10.dp))
        GhostButton(if (paused) "RESUME STREAM" else "PAUSE STREAM") { paused = !paused }
        Spacer(Modifier.height(8.dp))
        GhostButton("CLEAR LOGS") {
            lines = emptyList()
            PythonBridge.call("clear_logs") { cursor = 0 }
            tick++
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "python stdout also lands in logcat (tags: python.stdout / python.stderr)",
            color = Muted,
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
