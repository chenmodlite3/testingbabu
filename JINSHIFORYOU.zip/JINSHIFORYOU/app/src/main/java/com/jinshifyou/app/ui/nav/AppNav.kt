package com.jinshifyou.app.ui.nav

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.jinshifyou.app.ui.screens.BuildPakScreen
import com.jinshifyou.app.ui.screens.DashboardScreen
import com.jinshifyou.app.ui.screens.FileManagerScreen
import com.jinshifyou.app.ui.screens.InjectScreen
import com.jinshifyou.app.ui.screens.LogsScreen
import com.jinshifyou.app.ui.screens.LuaEngineScreen
import com.jinshifyou.app.ui.screens.SettingsScreen
import com.jinshifyou.app.ui.screens.SplashScreen
import com.jinshifyou.app.ui.screens.UnpackScreen
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.BgPanel
import com.jinshifyou.app.ui.theme.Muted
import com.jinshifyou.app.ui.theme.NeonPurple

@Composable
fun AppNav(onExit: () -> Unit) {
    var current by rememberSaveable { mutableStateOf(Screen.Splash.key) }

    fun go(key: String) {
        current = key
    }

    BackHandler(enabled = current != Screen.Dashboard.key) {
        go(Screen.Dashboard.key)
    }

    Scaffold(
        containerColor = BgDeep,
        bottomBar = {
            if (bottomTabs.any { it.key == current }) {
                NavigationBar(containerColor = BgPanel) {
                    bottomTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = current == tab.key,
                            onClick = { go(tab.key) },
                            icon = { Icon(tab.icon, contentDescription = tab.title) },
                            label = { Text(tab.title, style = MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = NeonPurple,
                                selectedTextColor = NeonPurple,
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted,
                                indicatorColor = NeonPurple.copy(alpha = 0.16f),
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            AnimatedContent(
                targetState = current,
                transitionSpec = {
                    (fadeIn(tween(220)) + slideInHorizontally { it / 12 })
                        .togetherWith(fadeOut(tween(160)) + slideOutHorizontally { -it / 12 })
                },
                label = "screen",
            ) { route ->
                when (route) {
                    Screen.Splash.key -> SplashScreen(onReady = { go(Screen.Dashboard.key) })
                    Screen.Unpack.key -> UnpackScreen(onBack = { go(Screen.Dashboard.key) })
                    Screen.LuaEngine.key -> LuaEngineScreen(onBack = { go(Screen.Dashboard.key) })
                    Screen.Inject.key -> InjectScreen(onBack = { go(Screen.Dashboard.key) })
                    Screen.BuildPak.key -> BuildPakScreen(onBack = { go(Screen.Dashboard.key) })
                    Screen.FileManager.key -> FileManagerScreen()
                    Screen.Logs.key -> LogsScreen()
                    Screen.Settings.key -> SettingsScreen(onExit = onExit)
                    else -> DashboardScreen(onOpen = { go(it) })
                }
            }
        }
    }
}
