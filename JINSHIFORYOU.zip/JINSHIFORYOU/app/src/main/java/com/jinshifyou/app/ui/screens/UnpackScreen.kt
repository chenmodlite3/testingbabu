package com.jinshifyou.app.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.FileEntry
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.BusyOverlay
import com.jinshifyou.app.ui.components.FileList
import com.jinshifyou.app.ui.components.GhostButton
import com.jinshifyou.app.ui.components.JinsButton
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.components.SectionTitle
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.TextSecondary

fun importViaSaf(
    context: Context,
    uri: Uri,
    kind: String,
    onDone: (String) -> Unit,
) {
    val cachePath = PythonBridge.copyToCache(context, uri)
    if (cachePath == null) {
        onDone("could not read selected file")
        return
    }
    PythonBridge.call("import_file", kind, cachePath) { r ->
        onDone(if (r.ok) r.message else "import failed: ${r.message}")
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnpackScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    var files by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }

    fun refresh() {
        PythonBridge.call("list_files", "pak") { r ->
            files = r.objects().map { FileEntry.from(it) }
            selected = emptySet()
        }
    }

    LaunchedEffect(reload) { refresh() }

    val pickPak = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            importViaSaf(context, uri, "pak") { msg ->
                status = msg
                busy = false
                reload++
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "back", tint = IceCyan)
            }
            ScreenHeader("UNPACK PAK", "PAK_ORIGINAL → PAK_UNPACK")
        }

        SectionTitle("SOURCE PAK FILES")
        FileList(
            files = files,
            selected = selected,
            onToggle = { name ->
                selected = if (name in selected) selected - name else selected + name
            },
            emptyText = "PAK_ORIGINAL is empty — import a .pak first",
        )

        Spacer(Modifier.height(12.dp))
        GhostButton("IMPORT .PAK FROM DEVICE") { pickPak.launch(arrayOf("*/*")) }
        Spacer(Modifier.height(8.dp))
        GhostButton("REFRESH LIST") { reload++ }
        Spacer(Modifier.height(14.dp))

        JinsButton(
            text = "UNPACK SELECTED (${selected.size})",
            enabled = selected.isNotEmpty() && !busy,
            loading = busy,
        ) {
            busy = true
            status = "unpacking…"
            val arr = org.json.JSONArray()
            selected.forEach { arr.put(it) }
            PythonBridge.call("unpack_pak", arr.toString()) { r ->
                status = if (r.ok) r.message else "ERROR: ${r.message}"
                busy = false
                reload++
            }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(
                status,
                color = if (status.startsWith("ERROR")) ErrRed else NeonGreen,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        BusyOverlay(busy, "working — see Logs for live output")
        Spacer(Modifier.height(20.dp))
        Text(
            "output lands in PAK_UNPACK/<pak stem>/  ·  browse it in File Manager",
            color = TextSecondary,
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
