package com.jinshifyou.app.ui.theme

import androidx.compose.ui.graphics.Color

val NeonPurple = Color(0xFFBF5FFF)
val RoyalPurple = Color(0xFF9D4EDD)
val DeepPurple = Color(0xFF6A0DAD)
val IceCyan = Color(0xFF7DF9FF)
val HotPink = Color(0xFFFF6EC7)
val NeonGreen = Color(0xFF39FF14)
val WarnOrange = Color(0xFFFFB347)
val ErrRed = Color(0xFFFF3366)
val Muted = Color(0xFF7A7A9A)
val GoldSoft = Color(0xFFC8A2C8)
val Ember = Color(0xFFFF6B35)

val BgDeep = Color(0xFF0A0A14)
val BgPanel = Color(0xFF12121F)
val BgPanelLight = Color(0xFF1A1A2E)
val BgCard = Color(0xFF16162A)

val TextPrimary = Color(0xFFF0F0FF)
val TextSecondary = Color(0xFFB8B8D0)
