package com.jinshifyou.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.List
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.Health
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.GradientCard
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.components.StatusDot
import com.jinshifyou.app.ui.components.ToolCard
import com.jinshifyou.app.ui.nav.Screen
import com.jinshifyou.app.ui.theme.BgPanelLight
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.Muted
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.NeonPurple
import com.jinshifyou.app.ui.theme.TextPrimary
import com.jinshifyou.app.ui.theme.WarnOrange

private fun iconFor(key: String) = when (key) {
    Screen.Unpack.key -> Icons.Default.Launch
    Screen.LuaEngine.key -> Icons.Default.Code
    Screen.Inject.key -> Icons.Default.Build
    else -> Icons.Default.List
}

private fun subtitleFor(key: String, h: Health?): String = when (key) {
    Screen.Unpack.key -> "extract every entry from a .pak"
    Screen.LuaEngine.key -> if (h?.luaCompile == true) "decompile & recompile .luac" else "bytecode convert · compile blocked"
    Screen.Inject.key -> "inject files into a target path"
    Screen.BuildPak.key -> "build new PAK from template"
    else -> ""
}

private fun statusFor(key: String, h: Health?): Pair<String, Boolean>? = when (key) {
    Screen.Unpack.key ->
        if (h?.pakCore == true) "CORE ONLINE" to true else "CORE OFFLINE" to false
    Screen.LuaEngine.key ->
        when {
            h?.luaCompile == true && h.luaText -> "FULL ONLINE" to true
            h?.pakCore == true -> "PARTIAL" to true
            else -> "BLOCKED" to false
        }
    Screen.Inject.key ->
        if (h?.pakCore == true) "CORE ONLINE" to true else "CORE OFFLINE" to false
    Screen.BuildPak.key ->
        if (h?.pakCore == true) "CORE ONLINE" to true else "CORE OFFLINE" to false
    else -> null
}

@Composable
fun DashboardScreen(onOpen: (String) -> Unit) {
    var health by remember { mutableStateOf<Health?>(null) }

    LaunchedEffect(Unit) {
        val r = PythonBridge.callSync("health")
        health = Health.from(r)
    }

    val h = health

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        ScreenHeader("◈ DASHBOARD", "@JINSHIFORYOU · v3.0 PREMIUM")

        GradientCard {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ENGINE STATUS", style = MaterialTheme.typography.titleMedium, color = TextPrimary)
                    Spacer(Modifier.width(10.dp))
                    StatusDot(
                        label = when {
                            h == null -> "PROBING…"
                            h.engineOk -> "ONLINE"
                            else -> "OFFLINE"
                        },
                        ok = h?.engineOk == true,
                    )
                }
                Spacer(Modifier.height(8.dp))
                StatusDot("PAK CORE (unpack/repack/inject/build)", h?.pakCore == true)
                Spacer(Modifier.height(4.dp))
                StatusDot(
                    when {
                        h?.luaCompile == true && h.luaText -> "LUA ENGINE FULL (decompile+compile)"
                        h?.pakCore == true -> "LUA BYTECODE ONLY (text decompile needs luac+java)"
                        else -> "LUA ENGINE BLOCKED"
                    },
                    h?.pakCore == true,
                )
                Spacer(Modifier.height(4.dp))
                StatusDot("PY DEPS (gmalg/zstd/crypto)", h?.deps?.values?.all { it } == true)
            }
        }

        Spacer(Modifier.height(14.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.height(230.dp),
            userScrollEnabled = false,
        ) {
            items(dashboardCards, key = { it.key }) { card ->
                val st = statusFor(card.key, h)
                ToolCard(
                    icon = iconFor(card.key),
                    title = card.title,
                    subtitle = subtitleFor(card.key, h),
                    status = st?.first,
                    statusOk = st?.second,
                    onClick = { onOpen(card.key) },
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        GradientCard(onClick = { onOpen(Screen.FileManager.key) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FILE MANAGER", style = MaterialTheme.typography.titleLarge, color = TextPrimary)
                    Text("browse workspace · import PAK/LUA", style = MaterialTheme.typography.bodyMedium, color = Muted)
                }
                StatusDot(h?.workspace?.substringAfterLast('/') ?: "…", true)
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            GradientCard(onClick = { onOpen(Screen.Logs.key) }, modifier = Modifier.weight(1f)) {
                Text("◈ LOGS", style = MaterialTheme.typography.titleMedium, color = IceCyan)
            }
            GradientCard(onClick = { onOpen(Screen.Settings.key) }, modifier = Modifier.weight(1f)) {
                Text("◈ SETTINGS", style = MaterialTheme.typography.titleMedium, color = NeonPurple)
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "workspace: ${h?.workspace ?: "/storage/emulated/0/Documents/JINSHIFORYOU"}",
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
        )
    }
}
