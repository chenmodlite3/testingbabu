package com.jinshifyou.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.FileEntry
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.components.BusyOverlay
import com.jinshifyou.app.ui.components.FileList
import com.jinshifyou.app.ui.components.GhostButton
import com.jinshifyou.app.ui.components.JinsButton
import com.jinshifyou.app.ui.components.ScreenHeader
import com.jinshifyou.app.ui.components.SectionTitle
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.BgPanelLight
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.TextSecondary

@Composable
fun InjectScreen(onBack: () -> Unit) {
    var paks by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var compiled by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var selectedPak by remember { mutableStateOf("") }
    var targetPath by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var reload by remember { mutableIntStateOf(0) }

    fun refresh() {
        PythonBridge.call("list_files", "pak") { r ->
            val list = r.objects().map { FileEntry.from(it) }
            paks = list
            if (selectedPak.isEmpty()) selectedPak = list.firstOrNull { it.name.endsWith(".pak") }?.name ?: ""
        }
        PythonBridge.call("list_files", "compiled") { r ->
            compiled = r.objects().map { FileEntry.from(it) }
        }
    }

    LaunchedEffect(reload) { refresh() }

    Column(
        Modifier
            .fillMaxSize()
            .background(BgDeep)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "back", tint = IceCyan)
            }
            ScreenHeader("REPACK / INJECT", "COMPILED → PAK_RESULT · no firewall")
        }

        SectionTitle("1 · SELECT TARGET PAK (PAK_ORIGINAL)")
        if (paks.isEmpty()) {
            Text("no .pak in PAK_ORIGINAL — import one in File Manager", color = TextSecondary,
                style = MaterialTheme.typography.bodyMedium)
        } else {
            FileList(
                files = paks,
                selected = if (selectedPak.isEmpty()) emptySet() else setOf(selectedPak),
                onToggle = { selectedPak = it },
                emptyText = "empty",
            )
        }

        Spacer(Modifier.height(12.dp))
        SectionTitle("2 · FILES TO INJECT (COMPILED)")
        Text(
            "${compiled.size} file(s) ready in COMPILED",
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium,
        )

        Spacer(Modifier.height(12.dp))
        SectionTitle("3 · INTERNAL TARGET PATH (optional)")
        OutlinedTextField(
            value = targetPath,
            onValueChange = { targetPath = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("e.g. ShadowTrackerExtra/Content/...") },
            placeholder = { Text("empty = pak root") },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = IceCyan,
                unfocusedBorderColor = BgPanelLight,
                focusedTextColor = MaterialTheme.colorScheme.onBackground,
                unfocusedTextColor = TextSecondary,
                cursorColor = IceCyan,
                focusedLabelColor = IceCyan,
                unfocusedLabelColor = TextSecondary,
            ),
        )

        Spacer(Modifier.height(16.dp))
        JinsButton(
            text = "INJECT LUA (NO FIREWALL)",
            enabled = selectedPak.isNotEmpty() && compiled.isNotEmpty() && !busy,
            loading = busy,
        ) {
            busy = true
            status = "injecting…"
            PythonBridge.call("inject_lua", targetPath.trim(), selectedPak) { r ->
                status = if (r.ok) r.message else "ERROR: ${r.message}"
                busy = false
            }
        }

        Spacer(Modifier.height(8.dp))
        GhostButton("RECOMPILE ALL LUA_EDIT → COMPILED") {
            busy = true
            PythonBridge.call("recompile_all") { r ->
                status = if (r.ok) r.message else "ERROR: ${r.message}"
                busy = false
                reload++
            }
        }

        if (status.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(
                status,
                color = if (status.startsWith("ERROR")) ErrRed else NeonGreen,
                style = MaterialTheme.typography.bodyMedium,
            )
        }

        BusyOverlay(busy, "working — original PAK always backed up to BACKUP/")
        Spacer(Modifier.height(20.dp))
        Text(
            "output: PAK_RESULT/<pak>_MODIFIED.pak",
            color = NeonGreen,
            style = MaterialTheme.typography.labelSmall,
        )
    }
}
