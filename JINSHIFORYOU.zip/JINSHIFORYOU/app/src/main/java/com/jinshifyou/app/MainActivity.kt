package com.jinshifyou.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.jinshifyou.app.engine.PythonBridge
import com.jinshifyou.app.ui.nav.AppNav
import com.jinshifyou.app.ui.theme.BgDeep
import com.jinshifyou.app.ui.theme.JinsifyouTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        try {
            PythonBridge.ensureStarted(applicationContext)
        } catch (_: Throwable) {
        }
        setContent {
            JinsifyouTheme {
                Surface(
                    modifier = Modifier.fillMaxSize().background(BgDeep),
                    color = BgDeep,
                ) {
                    AppNav(onExit = { finishAffinity() })
                }
            }
        }
    }
}
