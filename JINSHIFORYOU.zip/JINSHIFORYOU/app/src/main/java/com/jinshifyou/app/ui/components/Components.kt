package com.jinshifyou.app.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.jinshifyou.app.engine.FileEntry
import com.jinshifyou.app.engine.LogLine
import com.jinshifyou.app.ui.theme.BgCard
import com.jinshifyou.app.ui.theme.BgPanelLight
import com.jinshifyou.app.ui.theme.ErrRed
import com.jinshifyou.app.ui.theme.IceCyan
import com.jinshifyou.app.ui.theme.Muted
import com.jinshifyou.app.ui.theme.NeonGreen
import com.jinshifyou.app.ui.theme.NeonPurple
import com.jinshifyou.app.ui.theme.RoyalPurple
import com.jinshifyou.app.ui.theme.TextPrimary
import com.jinshifyou.app.ui.theme.TextSecondary
import com.jinshifyou.app.ui.theme.WarnOrange

@Composable
fun GradientCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    colors = listOf(BgCard, BgPanelLight),
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(NeonPurple.copy(alpha = 0.55f), IceCyan.copy(alpha = 0.25f)),
                ),
                shape = shape,
            )
            .padding(14.dp)
            .animateContentSize(),
    ) {
        content()
    }
}

@Composable
fun ToolCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    status: String? = null,
    statusOk: Boolean? = null,
    onClick: () -> Unit,
) {
    GradientCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(RoyalPurple, NeonPurple))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, contentDescription = title, tint = TextPrimary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimary,
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                )
                if (status != null) {
                    Spacer(Modifier.height(4.dp))
                    StatusDot(label = status, ok = statusOk ?: true)
                }
            }
        }
    }
}

@Composable
fun StatusDot(label: String, ok: Boolean) {
    val color = when {
        ok -> NeonGreen
        label.equals("PARTIAL", ignoreCase = true) -> WarnOrange
        else -> ErrRed
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(Modifier.width(6.dp))
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            fontFamily = FontFamily.Monospace,
        )
    }
}

@Composable
fun JinsButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    primary: Boolean = true,
) {
    val bg = Brush.horizontalGradient(
        if (primary) listOf(RoyalPurple, NeonPurple) else listOf(BgPanelLight, BgCard)
    )
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            contentColor = TextPrimary,
            disabledContainerColor = Color.Transparent,
            disabledContentColor = Muted,
        ),
    ) {
        Box(
            Modifier
                .matchParentSize()
                .background(
                    if (enabled) bg
                    else Brush.horizontalGradient(listOf(BgCard, BgCard))
                )
        )
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                color = IceCyan,
                strokeWidth = 2.dp,
            )
        } else {
            Text(
                text,
                style = MaterialTheme.typography.labelLarge,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}

@Composable
fun GhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(46.dp),
        shape = RoundedCornerShape(14.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge, fontFamily = FontFamily.Monospace)
    }
}

@Composable
fun ScreenHeader(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, color = TextPrimary)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = Muted)
        }
    }
}

@Composable
fun FileList(
    files: List<FileEntry>,
    selected: Set<String>,
    onToggle: (String) -> Unit,
    emptyText: String,
) {
    if (files.isEmpty()) {
        Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(emptyText, color = Muted, style = MaterialTheme.typography.bodyMedium)
        }
        return
    }
    LazyColumn(
        modifier = Modifier.fillMaxWidth().height(260.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(files, key = { it.name }) { f ->
            val isSelected = f.name in selected
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isSelected) NeonPurple.copy(alpha = 0.18f) else BgCard)
                    .border(
                        1.dp,
                        if (isSelected) NeonPurple else BgPanelLight,
                        RoundedCornerShape(10.dp),
                    )
                    .clickable { onToggle(f.name) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        f.name,
                        color = TextPrimary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                    )
                    Text(
                        "${f.sizeH}  ·  ${f.mtime}",
                        color = Muted,
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
                Box(
                    Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) NeonGreen else Color.Transparent)
                        .border(1.dp, if (isSelected) NeonGreen else Muted, CircleShape)
                )
            }
        }
    }
}

@Composable
fun LogPanel(lines: List<LogLine>) {
    val colorFor: (String) -> Color = { lvl ->
        when (lvl) {
            "ok" -> NeonGreen
            "err" -> ErrRed
            "warn" -> WarnOrange
            else -> IceCyan
        }
    }
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .height(320.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF07070F))
            .border(1.dp, BgPanelLight, RoundedCornerShape(14.dp))
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        if (lines.isEmpty()) {
            item {
                Text("· no logs yet ·", color = Muted, fontFamily = FontFamily.Monospace)
            }
        }
        items(lines, key = { it.i }) { line ->
            Text(
                "[${line.ts}] ${line.msg}",
                color = colorFor(line.lvl),
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
            )
        }
    }
}

@Composable
fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Muted, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun BusyOverlay(visible: Boolean, text: String) {
    if (!visible) return
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(BgPanelLight),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CircularProgressIndicator(Modifier.size(18.dp), color = IceCyan, strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
            Text(text, color = TextPrimary, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = IceCyan,
        modifier = Modifier.padding(vertical = 8.dp),
        fontFamily = FontFamily.Monospace,
    )
}
