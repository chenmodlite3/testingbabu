"""JINSHIFORYOU mobile engine adapter.

Non-interactive bridge between the Android UI and the original
JINSHIABBU.py algorithms. Every operation returns a JSON string:
    {"ok": bool, "message": str, "data": [...]?}

The original terminal prompts (safe_input / Rich panels / interactive
file selectors) are replaced by explicit parameters coming from the
Kotlin screens. All binary PAK/Lua algorithms are untouched originals.
"""

import json
import os
import shutil
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

WORKSPACE = Path("/storage/emulated/0/Documents/JINSHIFORYOU")
SOURCE_DIR = WORKSPACE / "SOURCE"
REAL_DIR = WORKSPACE / "LUA_ORIGINAL"
EDIT_DIR = WORKSPACE / "COMPILED"
UNPACK_DIR = WORKSPACE / "LUA_EDIT"
PAK_DIR = WORKSPACE / "PAK_ORIGINAL"
PAK_UNPACK_DIR = WORKSPACE / "PAK_UNPACK"
RESULT_DIR = WORKSPACE / "PAK_RESULT"
BACKUP_DIR = WORKSPACE / "BACKUP"

KIND_DIRS = {
    "pak": PAK_DIR,
    "lua_original": REAL_DIR,
    "lua_edit": UNPACK_DIR,
    "compiled": EDIT_DIR,
    "unpacked": PAK_UNPACK_DIR,
    "result": RESULT_DIR,
    "source": SOURCE_DIR,
    "backup": BACKUP_DIR,
}

_IMPORT_ERROR = None
J = None

try:
    os.makedirs(str(WORKSPACE), exist_ok=True)
except Exception:
    pass

try:
    import JINSHIABBU as J
    J.setup_directories()
except Exception as _e:
    _IMPORT_ERROR = f"{type(_e).__name__}: {_e}"

_LOG_LOCK = threading.Lock()
_LOGS = []
_LOG_SEQ = 0
_MAX_LOGS = 800


def _log(msg, lvl="info"):
    global _LOG_SEQ
    with _LOG_LOCK:
        _LOG_SEQ += 1
        _LOGS.append({
            "i": _LOG_SEQ,
            "lvl": lvl,
            "msg": str(msg)[:2000],
            "ts": datetime.now().strftime("%H:%M:%S"),
        })
        if len(_LOGS) > _MAX_LOGS:
            del _LOGS[: len(_LOGS) - _MAX_LOGS]
    return msg


def _ok(message="", data=None):
    out = {"ok": True, "message": message}
    if data is not None:
        out["data"] = data
    return json.dumps(out)


def _err(message, tb=False):
    if tb:
        message = f"{message}\n{traceback.format_exc()[-1200:]}"
    _log(message, "err")
    return json.dumps({"ok": False, "message": str(message)[:1500]})


def _need_j():
    if J is None:
        return _IMPORT_ERROR or "python engine failed to import"
    return None


def _human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024.0 or unit == "GB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{int(n)} B"
        n /= 1024.0


def _entry(p: Path):
    try:
        st = p.stat()
        return {
            "name": p.name,
            "size": st.st_size,
            "size_h": _human(st.st_size),
            "is_dir": p.is_dir(),
            "mtime": datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"),
        }
    except Exception:
        return None


def _list_dir(path: Path):
    entries = []
    if path.exists() and path.is_dir():
        for p in sorted(path.iterdir(), key=lambda x: (x.is_file(), x.name.lower())):
            e = _entry(p)
            if e:
                entries.append(e)
    return entries


# ---------------------------------------------------------------- status

def health():
    deps = {}
    if J is not None:
        deps["gmalg"] = getattr(J, "PAK_MODE_AVAILABLE", False) and hasattr(J, "gmalg")
        try:
            import gmalg  # noqa: F401
            deps["gmalg"] = True
        except Exception:
            deps["gmalg"] = False
        try:
            from Crypto.Cipher import AES  # noqa: F401
            deps["pycryptodome"] = True
        except Exception:
            deps["pycryptodome"] = False
        try:
            from zstandard import ZstdDecompressor  # noqa: F401
            deps["zstandard"] = True
        except Exception:
            deps["zstandard"] = False
        try:
            import rich  # noqa: F401
            deps["rich"] = True
        except Exception:
            deps["rich"] = False
    else:
        deps = {"gmalg": False, "pycryptodome": False, "zstandard": False, "rich": False}

    luac = None
    java = None
    unluac = None
    if J is not None:
        try:
            luac = J.LUAC_PATH
            found_luac = bool(shutil.which("luac5.3") or shutil.which("luac53"))
            luac_ok = found_luac or (Path(luac).exists() if luac else False)
        except Exception:
            luac_ok = False
        try:
            java = J.JAVA_CMD
            java_ok = bool(shutil.which("java")) and shutil.which("java") is not None
            if java and Path(str(java)).exists():
                java_ok = True
        except Exception:
            java_ok = False
        try:
            unluac = str(J.UNLUAC_JAR)
            unluac_ok = Path(unluac).exists()
        except Exception:
            unluac_ok = False
    else:
        luac_ok = java_ok = unluac_ok = False

    pak_core = bool(J is not None and deps.get("gmalg") and deps.get("pycryptodome") and deps.get("zstandard"))
    lua_text = bool(pak_core and luac_ok and java_ok and unluac_ok)

    data = {
        "tool": getattr(J, "TOOL_NAME", "JINSHIFORYOU") if J else "JINSHIFORYOU",
        "version": getattr(J, "TOOL_VERSION", "v3.0") if J else "v3.0",
        "engine_ok": J is not None,
        "import_error": _IMPORT_ERROR or "",
        "deps": deps,
        "pak_core": pak_core,
        "lua_bytecode": pak_core,
        "lua_text_decompile": lua_text,
        "lua_compile": luac_ok,
        "workspace": str(WORKSPACE),
        "workspace_exists": WORKSPACE.exists(),
        "luac_path": luac or "",
        "java_path": java or "",
        "unluac_path": unluac or "",
    }
    return _ok("engine ready" if J is not None else "engine import failed", [data])


def workspace_info():
    broken = _need_j()
    if broken:
        return _err(broken)
    try:
        info = {}
        for kind, d in KIND_DIRS.items():
            files = [p for p in d.iterdir() if p.is_file()] if d.exists() else []
            size = sum(p.stat().st_size for p in files if p.is_file())
            info[kind] = {"count": len(files), "size": size, "size_h": _human(size)}
        return _ok("workspace ok", [info])
    except Exception as e:
        return _err(e, tb=True)


def get_logs(since=0):
    try:
        since = int(since)
    except Exception:
        since = 0
    with _LOG_LOCK:
        lines = [l for l in _LOGS if l["i"] > since]
        nxt = _LOG_SEQ
    return json.dumps({"ok": True, "message": "", "index": nxt, "lines": lines})


def clear_logs():
    global _LOG_SEQ
    with _LOG_LOCK:
        _LOGS.clear()
    return _ok("logs cleared")


def set_language(code):
    broken = _need_j()
    if broken:
        return _err(broken)
    try:
        if code in ("en", "ru", "ar", "zh"):
            J.LANG_CODE = code
            return _ok(f"language set to {code}")
        return _err(f"unsupported language: {code}")
    except Exception as e:
        return _err(e, tb=True)


# ---------------------------------------------------------------- files

def list_files(kind):
    d = KIND_DIRS.get(kind)
    if d is None:
        return _err(f"unknown kind: {kind}")
    try:
        return _ok(f"{kind}: {len(_list_dir(d))} entries", _list_dir(d))
    except Exception as e:
        return _err(e, tb=True)


def list_dir(rel_path="."):
    try:
        p = (WORKSPACE / str(rel_path)).resolve()
        if WORKSPACE.resolve() not in p.parents and p != WORKSPACE.resolve():
            return _err("path escapes workspace")
        return _ok(str(p), _list_dir(p))
    except Exception as e:
        return _err(e, tb=True)


def import_file(kind, src_path):
    d = KIND_DIRS.get(kind)
    if d is None:
        return _err(f"unknown kind: {kind}")
    broken = _need_j()
    if broken:
        return _err(broken)
    try:
        src = Path(src_path)
        if not src.exists():
            return _err(f"source not found: {src_path}")
        d.mkdir(parents=True, exist_ok=True)
        target = d / src.name
        if target.exists():
            target = d / f"{src.stem}_{int(time.time())}{src.suffix}"
        shutil.copy2(str(src), str(target))
        _log(f"imported {target.name} -> {kind}", "ok")
        return _ok(f"imported {target.name}", [_entry(target)])
    except Exception as e:
        return _err(e, tb=True)


def delete_entry(rel_path):
    try:
        p = (WORKSPACE / str(rel_path)).resolve()
        if WORKSPACE.resolve() not in p.parents:
            return _err("path escapes workspace")
        if not p.exists():
            return _err("not found")
        if p.is_dir():
            shutil.rmtree(str(p))
        else:
            p.unlink()
        _log(f"deleted {rel_path}", "warn")
        return _ok(f"deleted {p.name}")
    except Exception as e:
        return _err(e, tb=True)


# ---------------------------------------------------------------- ops

def unpack_pak(pak_names):
    broken = _need_j()
    if broken:
        return _err(broken)
    names = _parse_names(pak_names)
    if not names:
        return _err("no pak selected")
    results = []
    done = 0
    for pak_name in names:
        try:
            pak_file = PAK_DIR / pak_name
            if not pak_file.exists():
                _log(f"PAK not found: {pak_name}", "err")
                continue
            out_dir = PAK_UNPACK_DIR / pak_file.stem
            _log(f"unpacking {pak_name} ...")
            extracted = False
            last = ""
            try:
                from pathlib import PurePath
                pak = J.TencentPakFile(PurePath(str(pak_file)))
                pak.dump(out_dir)
                extracted = True
                _log("tencent pak parse ok", "ok")
            except Exception as e_t:
                last = str(e_t)
                _log(f"tencent parse failed: {e_t} — raw extraction", "warn")
                try:
                    J._raw_unpack_pak(pak_file, out_dir)
                    extracted = True
                    _log("raw extraction ok", "ok")
                except Exception as e_r:
                    last = f"{last} | raw: {e_r}"
            if extracted:
                count = sum(1 for p in out_dir.rglob("*") if p.is_file()) if out_dir.exists() else 0
                msg = f"extracted {count} files -> PAK_UNPACK/{pak_file.stem}"
                _log(msg, "ok")
                results.append({"name": pak_file.stem, "count": count})
                done += 1
            else:
                _log(f"unpack failed {pak_name}: {last}", "err")
        except Exception as e:
            _log(f"unpack error {pak_name}: {e}", "err")
    if done == 0:
        return _err("unpack failed for all selected paks")
    return _ok(f"unpacked {done}/{len(names)} pak(s)", results)


def _parse_names(names_json):
    try:
        names = json.loads(names_json) if isinstance(names_json, str) else list(names_json)
        return [str(n) for n in names]
    except Exception:
        return [str(names_json)]


def decompile_selected(names_json):
    broken = _need_j()
    if broken:
        return _err(broken)
    names = _parse_names(names_json)
    if not names:
        return _err("no files selected")
    UNPACK_DIR.mkdir(parents=True, exist_ok=True)
    ok_n = 0
    failed = []
    for idx, name in enumerate(names, 1):
        inp = REAL_DIR / name
        _log(f"[{idx}/{len(names)}] decompiling {name}")
        if not inp.exists():
            failed.append(name)
            continue
        try:
            import tempfile
            with tempfile.TemporaryDirectory(prefix="js_dec_") as tmp:
                ok, result, _ = J.robust_decompile(str(inp), str(UNPACK_DIR), tmp)
            if ok:
                ok_n += 1
                _log(f"decompiled {Path(result).name}", "ok")
            else:
                _log(f"decompile failed {name}: {result}", "warn")
                fb = UNPACK_DIR / (Path(name).stem + ".luac")
                ok2, _ = J.convert_file(str(inp), str(fb))
                if ok2:
                    ok_n += 1
                    _log(f"saved raw bytecode {fb.name}", "warn")
                else:
                    failed.append(name)
        except Exception as e:
            _log(f"error {name}: {e}", "err")
            failed.append(name)
    msg = f"decompiled {ok_n}/{len(names)}"
    if failed:
        msg += f" · failed: {', '.join(failed[:5])}"
    _log(msg, "ok" if ok_n else "err")
    return _ok(msg, [{"success": ok_n, "failed": failed}])


def recompile_selected(names_json):
    broken = _need_j()
    if broken:
        return _err(broken)
    names = _parse_names(names_json)
    if not names:
        return _err("no files selected")
    EDIT_DIR.mkdir(parents=True, exist_ok=True)
    _log(f"recompiling {len(names)} file(s)")
    ok_n, failed = J.recompile_lua_files(names, quiet=True)
    msg = f"compiled {ok_n}/{len(names)}"
    if failed:
        msg += f" · failed: {', '.join(failed[:5])}"
    _log(msg, "ok" if ok_n else "err")
    return _ok(msg, [{"success": ok_n, "failed": failed}])


def recompile_all():
    files = [f for f in os.listdir(str(UNPACK_DIR)) if f.endswith(".lua")] if UNPACK_DIR.exists() else []
    return recompile_selected(json.dumps(files))


def build_new_pak(template_name, target_path=""):
    broken = _need_j()
    if broken:
        return _err(broken)
    try:
        template = PAK_DIR / template_name
        if not template.exists():
            return _err(f"template not found: {template_name}")
        if not EDIT_DIR.exists() or not any(EDIT_DIR.iterdir()):
            return _err("COMPILED folder is empty — recompile or add files first")
        RESULT_DIR.mkdir(parents=True, exist_ok=True)
        out = RESULT_DIR / template_name
        tp = str(target_path or "").replace("\\", "/").strip("/")
        _log(f"building new pak from {template_name} (target='{tp}')")
        count = J.build_new_pak_from_template(template, EDIT_DIR, out, tp or None)
        if count and count > 0:
            msg = f"built {template_name} · {count} files injected -> PAK_RESULT"
            _log(msg, "ok")
            return _ok(msg, [{"count": int(count), "output": str(out)}])
        return _err("build produced 0 files — check COMPILED contents")
    except Exception as e:
        return _err(e, tb=True)


def inject_lua(target_path="", pak_name=""):
    broken = _need_j()
    if broken:
        return _err(broken)
    try:
        files_in_edit = [
            f for f in EDIT_DIR.rglob("*")
            if f.is_file() and f.name not in ("pak_manifest.json", ".DS_Store")
        ] if EDIT_DIR.exists() else []
        if not files_in_edit:
            return _err("COMPILED folder is empty — put files there first")

        if pak_name:
            pak_path = PAK_DIR / pak_name
            if not pak_path.exists():
                return _err(f"PAK not found: {pak_name}")
        else:
            paks = [p for p in PAK_DIR.iterdir() if p.name.lower().endswith(".pak")] if PAK_DIR.exists() else []
            if not paks:
                return _err("no .pak in PAK_ORIGINAL")
            pak_path = paks[0]
            if len(paks) > 1:
                _log(f"multiple paks found — using {pak_path.name}", "warn")

        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        backup = BACKUP_DIR / f"{pak_path.stem}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pak"
        shutil.copy2(str(pak_path), str(backup))
        _log(f"backup created: {backup.name}", "ok")

        base = str(target_path or "").replace("\\", "/").strip("/")
        if base and not base.endswith("/"):
            base += "/"

        RESULT_DIR.mkdir(parents=True, exist_ok=True)
        _log(f"loading {pak_path.name}")
        pak = J.TencentPakFile(__import__("pathlib").PurePath(str(pak_path)))
        dominant = pak.detect_dominant_style()
        _log(
            f"dominant style comp={dominant['comp_method']} enc={dominant['enc_method']} "
            f"encrypted={dominant['encrypted']} block={dominant['block_size']}"
        )

        plan = []
        for f in files_in_edit:
            internal = base + f.name if base else f.name
            plan.append({
                "src_path": f,
                "internal_path": internal,
                "comp_method": dominant["comp_method"],
                "enc_method": dominant["enc_method"],
                "encrypted": dominant["encrypted"],
                "block_size": dominant["block_size"],
            })

        out_name = f"{pak_path.stem}_MODIFIED.pak"
        output_pak = RESULT_DIR / out_name
        _log(f"injecting {len(plan)} file(s)")
        pak.inject_files(plan, output_pak)
        msg = f"injected {len(plan)} files -> PAK_RESULT/{out_name}"
        _log(msg, "ok")
        return _ok(msg, [{"count": len(plan), "output": str(output_pak)}])
    except Exception as e:
        return _err(e, tb=True)


def clean_all():
    broken = _need_j()
    if broken:
        return _err(broken)
    try:
        removed = 0
        xva = WORKSPACE / "xvaLuex"
        if xva.exists():
            shutil.rmtree(str(xva))
            removed += 1
            _log("removed xvaLuex", "warn")
        for f in WORKSPACE.glob("*.temp.std.luac"):
            try:
                f.unlink()
                removed += 1
            except Exception:
                pass
        for c in WORKSPACE.rglob("__pycache__"):
            shutil.rmtree(str(c), ignore_errors=True)
            removed += 1
        msg = f"cleanup done — {removed} item(s) removed"
        _log(msg, "ok")
        return _ok(msg)
    except Exception as e:
        return _err(e, tb=True)
