
#!/usr/bin/env python3
import os
import sys
import struct
import glob
import shutil
import subprocess
import time
import re
import tempfile
import colorsys
import math
import zlib
import base64
import itertools as it
import traceback
import random
import hashlib
import platform
import json
import uuid
import threading
from typing import Tuple, List, Optional, Dict, Any
from dataclasses import dataclass
from functools import lru_cache
from pathlib import PurePath, Path
from datetime import datetime
from collections import Counter

CREDIT = "@JINSHIFORYOU"
TOOL_NAME = "JINSHIFORYOU"
TOOL_VERSION = "v3.0 PREMIUM"

R = "\033[0m"
BOLD = "\033[1m"
GRY = "\033[90m"
AC = "\033[36m"
TL = "\033[93m"
WH = "\033[37m"
DK = "\033[94m"
BD = "\033[91m"

LANG_CODE = 'en'

STRINGS = {
    'en': {
        'choose_language': 'Choose your language',
        'select_language': 'SELECT LANGUAGE',
        'lang_hint': 'Select 1-4',
        'invalid_lang': 'Please enter 1, 2, 3 or 4',
        'banner_unlimited': 'UNLIMITED EDITION',
        'banner_dev': 'DEVELOPER',
        'banner_credit': 'CREDIT',
        'banner_access': '🔓 FULL ACCESS  ·  NO RESTRICTIONS',
        'banner_devices': '📱 DEVICES : UNLIMITED',
        'banner_expiry': '⏰ EXPIRY  : ♾ LIFETIME',
        'banner_power': '⚡ PREMIUM BUILD  ·  JINSHIFORYOU POWER ⚡',
        'no_login': '◆ No login required — Straight to the tool! ◆',
        'powered_by': '◆ Powered & Credited by {credit} ◆',
        'alert_success': 'SUCCESS',
        'alert_error': 'ERROR',
        'alert_warning': 'WARNING',
        'alert_info': 'INFO',
        'alert_premium': 'PREMIUM',
        'menu_title': 'MAIN MENU',
        'lua_make_title': 'LUA_MAKE',
        'menu_1_name': 'UNPACK_PAK',
        'menu_1_desc': 'extract every entry from a .pak',
        'menu_2_name': 'LUA_MAKE',
        'menu_2_desc': 'decompile & recompile .luac',
        'menu_3_name': 'REPACK_LUA_PAK',
        'menu_3_desc': 'add new files a target path',
        'menu_4_name': 'BUILD_NEW_PAK',
        'menu_4_desc': 'build new PAK from template',
        'menu_5_name': 'INJECT_LUA',
        'menu_5_desc': 'inject Lua without firewall',
        'menu_6_name': 'CLEAN_ALL',
        'menu_6_desc': 'remove a xvaLuex directory',
        'menu_7_name': 'CLOSE_TERMUX',
        'menu_7_desc': 'close the tool',
        'enter_choice': 'Enter your choice',
        'invalid_choice': 'Invalid choice',
        'press_enter': 'Press Enter...',
        'press_enter_exit': 'Press Enter to exit...',
        'select_files_title': 'SELECT FILES TO {action}',
        'only_1_file': 'Only 1 file found:',
        'process_this_file': 'Process this file? (Y/n)',
        'col_file': 'File',
        'col_size': 'Size',
        'all_files': 'ALL FILES',
        'cancel': 'Cancel',
        'your_choice': 'Your choice',
        'invalid_selection': 'Invalid selection!',
        'lua_orig_empty': 'LUA_ORIGINAL folder is empty!',
        'lua_edit_empty': 'LUA_EDIT folder is empty!',
        'decompiling': 'Decompiling...',
        'compiling': 'Compiling...',
        'converting': 'Converting {name}...',
        'decompiled': 'Decompiled:',
        'failed_label': 'Failed:',
        'saved_raw': 'Saved raw bytecode:',
        'unpack_complete': 'Unpack Complete! {success}/{total} files decompiled.',
        'repack_complete': 'Repack Complete! {success}/{total} successful.',
        'recompile_failed': 'Recompile failed:',
        'compilation_failed': 'Compilation failed:',
        'compilation_timeout': 'Compilation timed out:',
        'original_not_found': 'Original not found:',
        'compiled': 'Compiled:',
        'fast_compile': '🚀 FAST COMPILE MODE',
        'launching_compile': 'Launching high-speed compilation...',
        'compile': 'Compile',
        'decompile': 'Decompile',
        'repack': 'Repack',
        'back': 'Back',
        'recompile_option': 'RECOMPILE',
        'recompile_desc': 'LUA_EDIT → COMPILED',
        'decompile_option': 'DECOMPILE',
        'decompile_desc': 'LUA_ORIGINAL → LUA_EDIT',
        'back_option': 'BACK',
        'back_desc': 'return to main menu',
        'select_option': 'Select option',
        'invalid_option': 'Invalid option',
        'pak_not_found': 'PAK folder not found at {path}',
        'select_unpack': 'Available .pak files to UNPACK',
        'select_repack': 'Available .pak files to REPACK TO PATH',
        'select_template': 'Select TEMPLATE PAK',
        'select_file_prompt': 'Select file (1-{n})',
        'invalid_number': 'Please enter a valid number',
        'unpacking': 'Unpacking {name}',
        'extracted_to': 'Extracted to {path}',
        'no_pak_files': 'No {pattern} files found in {path}',
        'no_files_compiled': 'No files in COMPILED folder. Place files to add in COMPILED first.',
        'target_path_title': 'Target path inside the PAK where files should be added.',
        'target_path_example': 'e.g. Content/Lua/GameLua/Mod/BRMod/Gameplay/Core',
        'press_enter_default': 'Press Enter to use default: Content/Lua/',
        'path_prompt': 'Path',
        'using_default': 'Using default path: {path}',
        'using_custom': 'Using custom path: {path}',
        'invalid_target_path': 'Invalid target path',
        'auto_proceeding': '▶ Auto-proceeding with repack...',
        'processed_files': 'Processed {count} files to {path} → {output}\nPAK is game ready',
        'no_files_processed': 'No files were processed',
        'repack_failed': 'Repack failed: {err}',
        'building_new_pak': 'Building NEW PAK using template: {name}',
        'new_pak_built': 'New PAK built with {count} files!',
        'output': 'Output: {path}',
        'build_failed': 'Build failed: {err}',
        'build_no_files': 'Build failed - no files processed',
        'new_pak_title': 'Target path inside PAK (or blank for relative).',
        'new_pak_files_info': 'Files will be added to this path inside the new PAK.',
        'new_pak_enter_root': 'Press Enter directly for no path (files at root)',
        'target_path_enter_root': 'Target path (press Enter for no path)',
        'no_path_root': 'No path set - files will be at root',
        'inject_title': 'INJECT LUA · REPACK TO PAK',
        'inject_desc': 'Inject Lua files directly into PAK',
        'created_empty_folder': 'Created empty folder: {path}',
        'add_lua_first': 'Please add your LUA files there first!',
        'compiled_empty': 'COMPILED folder is empty!',
        'put_lua_in': 'Please put LUA files in: {path}',
        'files_found': 'FILES FOUND',
        'enter_target_path': 'Enter the target path inside the PAK:',
        'path_example_2': 'Example: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/',
        'path_default_hint': 'Press Enter to use default: filename only',
        'no_base_path': 'No base path - files will be at root',
        'files_will_inject': '{count} files will be injected',
        'and_more': '... and {count} more files',
        'auto_proceeding_inject': '▶ Auto-proceeding with injection...',
        'searching_pak': 'Searching for PAK files in PAK_ORIGINAL...',
        'no_pak_found': 'No PAK file found in PAK_ORIGINAL folder!',
        'put_pak_in': 'Please put PAK file in: {path}',
        'found_pak': 'Found PAK: {name}',
        'multiple_pak': 'Multiple PAK files found:',
        'enter_number_select': 'Enter number to select',
        'selected': 'Selected: {name}',
        'invalid_input': 'Invalid input!',
        'backup_created': 'Backup created: {path}',
        'loading_pak': 'Loading PAK file...',
        'repacking_pak': 'Repacking PAK...',
        'dominant_style': 'Dominant style: comp={comp}, enc={enc}, encrypted={encrypted}, block={block}',
        'plan_files': 'Plan: {count} files with custom locations.',
        'repack_complete_msg': 'Repack complete! Output: {path}',
        'processed_with_locations': 'Processed {count} files with custom locations.',
        'error_label': 'Error: {err}',
        'cleanup_found': 'Found xvaLuex directory, removing...',
        'cleanup_removed': 'xvaLuex directory removed successfully!',
        'cleanup_none': 'No xvaLuex directory found.',
        'cleanup_temp': 'Removed {count} temporary files.',
        'cleanup_cache': 'Removed {path}',
        'cleanup_done': 'Cleanup complete!',
        'cleanup_error': 'Error during cleanup: {err}',
        'thanks': 'Thank you for using!',
        'developer_label': 'DEVELOPER',
        'credit_label': 'CREDIT',
        'version_label': 'VERSION',
        'force_closing': 'Force closing...',
        'interrupted': 'Interrupted. Exiting...',
        'fatal': 'FATAL: {err}',
        'inject_engine': 'INJECTION ENGINE',
        'source_pak': 'Source PAK',
        'output_label': 'Output',
        'injecting_label': 'Injecting',
        'credit_field': 'Credit',
        'step_loading': 'STEP 1/5 · LOADING INJECT FILES',
        'step_encoding': 'STEP 2/5 · ENCODING INJECT FILES',
        'loaded_files': 'Loaded {n} file(s)',
        'encoded_files': 'Encoded {n} file(s)',
        'inject_complete': 'INJECT COMPLETE',
        'success_label': 'SUCCESS',
        'processing_assets': 'Processing Assets...',
        'all_processed': 'All {n} assets processed.',
        'files_processed': 'Files Processed',
        'path_in_pak': 'Path in PAK',
        'original_size': 'Original Size',
        'stored_size': 'Stored Size',
        'col_num': '#',
        'add_files': 'Adding files...',
        'extract_files': 'Extracting files...',
        'new_pak_files': 'Files Added to New PAK',
        'files_included': 'Files included: {count}',
        'new_pak_written': 'New PAK written: {path}',
        'no_file_in_template': 'No file found in the Template PAK to copy settings from!',
        'no_file_in_edit': 'No file found in the EDIT folder!',
        'edit_empty_short': 'No files in EDIT folder.',
        'skipped_no_entry': '~ Skipped (no entry in PAK): {name}',
        'cannot_read_file': 'Cannot read {path}: {err} — skipping',
        'no_src_path': 'Inject item {i} has no src_path or plain_bytes — skipping',
        'empty_internal': 'Empty internal_path for item {i} — skipping',
        'no_valid_inject': 'No valid inject items after loading',
        'no_files_to_repack': 'No files to repack!',
        'verified_failed': 'VERIFICATION FAILED',
        'verified_failed_hash': 'VERIFICATION FAILED (index hash mismatch)',
        'stem_hash_mismatch': 'Stem hash mismatch (file may be renamed)',
        'secure_vip': 'SECURE VIP CONNECTION',
        'index_decrypt_failed': 'Index decryption failed, trying raw',
        'index_hash_mismatch': 'Index hash mismatch (PAK modified?)',
        'unsupported_version': 'Unsupported version: {v}',
        'skip_file': 'Skipped {name}: {err}',
        'created_workspace': 'Created workspace: {path}',
        'error_creating': 'Error creating {path}: {err}',
    },
    'ru': {
        'choose_language': 'Выберите язык',
        'select_language': 'ВЫБОР ЯЗЫКА',
        'lang_hint': 'Выберите 1-4',
        'invalid_lang': 'Пожалуйста, введите 1, 2, 3 или 4',
        'banner_unlimited': 'БЕЗЛИМИТНАЯ ВЕРСИЯ',
        'banner_dev': 'РАЗРАБОТЧИК',
        'banner_credit': 'АВТОР',
        'banner_access': '🔓 ПОЛНЫЙ ДОСТУП  ·  БЕЗ ОГРАНИЧЕНИЙ',
        'banner_devices': '📱 УСТРОЙСТВА : БЕЗЛИМИТ',
        'banner_expiry': '⏰ СРОК : ♾ ПОЖИЗНЕННО',
        'banner_power': '⚡ PREMIUM СБОРКА  ·  МОЩЬ JINSHIFORYOU ⚡',
        'no_login': '◆ Вход не требуется — сразу к работе! ◆',
        'powered_by': '◆ Работает на {credit} ◆',
        'alert_success': 'УСПЕХ',
        'alert_error': 'ОШИБКА',
        'alert_warning': 'ВНИМАНИЕ',
        'alert_info': 'ИНФО',
        'alert_premium': 'ПРЕМИУМ',
        'menu_title': 'ГЛАВНОЕ МЕНЮ',
        'lua_make_title': 'LUA_КОМПИЛЯЦИЯ',
        'menu_1_name': 'РАСПАКОВАТЬ_PAK',
        'menu_1_desc': 'извлечь все файлы из .pak',
        'menu_2_name': 'LUA_КОМПИЛЯЦИЯ',
        'menu_2_desc': 'декомпиляция и компиляция .luac',
        'menu_3_name': 'ПЕРЕПАКОВАТЬ_PAK',
        'menu_3_desc': 'добавить новые файлы по пути',
        'menu_4_name': 'СОЗДАТЬ_НОВЫЙ_PAK',
        'menu_4_desc': 'создать новый PAK из шаблона',
        'menu_5_name': 'ВНЕДРИТЬ_LUA',
        'menu_5_desc': 'внедрить Lua без фаервола',
        'menu_6_name': 'ОЧИСТИТЬ_ВСЁ',
        'menu_6_desc': 'удалить папку xvaLuex',
        'menu_7_name': 'ЗАКРЫТЬ_TERMUX',
        'menu_7_desc': 'закрыть инструмент',
        'enter_choice': 'Введите ваш выбор',
        'invalid_choice': 'Неверный выбор',
        'press_enter': 'Нажмите Enter...',
        'press_enter_exit': 'Нажмите Enter для выхода...',
        'select_files_title': 'ВЫБЕРИТЕ ФАЙЛЫ ДЛЯ {action}',
        'only_1_file': 'Найден только 1 файл:',
        'process_this_file': 'Обработать этот файл? (Д/н)',
        'col_file': 'Файл',
        'col_size': 'Размер',
        'all_files': 'ВСЕ ФАЙЛЫ',
        'cancel': 'Отмена',
        'your_choice': 'Ваш выбор',
        'invalid_selection': 'Неверный выбор!',
        'lua_orig_empty': 'Папка LUA_ORIGINAL пуста!',
        'lua_edit_empty': 'Папка LUA_EDIT пуста!',
        'decompiling': 'Декомпиляция...',
        'compiling': 'Компиляция...',
        'converting': 'Конвертация {name}...',
        'decompiled': 'Декомпилировано:',
        'failed_label': 'Ошибка:',
        'saved_raw': 'Сохранён сырой байткод:',
        'unpack_complete': 'Распаковка завершена! {success}/{total} файлов декомпилировано.',
        'repack_complete': 'Перепаковка завершена! {success}/{total} успешно.',
        'recompile_failed': 'Ошибка перекомпиляции:',
        'compilation_failed': 'Ошибка компиляции:',
        'compilation_timeout': 'Превышено время компиляции:',
        'original_not_found': 'Оригинал не найден:',
        'compiled': 'Скомпилировано:',
        'fast_compile': '🚀 РЕЖИМ БЫСТРОЙ КОМПИЛЯЦИИ',
        'launching_compile': 'Запуск высокоскоростной компиляции...',
        'compile': 'Компилировать',
        'decompile': 'Декомпилировать',
        'repack': 'Перепаковать',
        'back': 'Назад',
        'recompile_option': 'ПЕРЕКОМПИЛИРОВАТЬ',
        'recompile_desc': 'LUA_EDIT → COMPILED',
        'decompile_option': 'ДЕКОМПИЛИРОВАТЬ',
        'decompile_desc': 'LUA_ORIGINAL → LUA_EDIT',
        'back_option': 'НАЗАД',
        'back_desc': 'вернуться в главное меню',
        'select_option': 'Выберите опцию',
        'invalid_option': 'Неверная опция',
        'pak_not_found': 'Папка PAK не найдена в {path}',
        'select_unpack': 'Доступные .pak файлы для РАСПАКОВКИ',
        'select_repack': 'Доступные .pak файлы для ПЕРЕПАКОВКИ',
        'select_template': 'Выберите ШАБЛОННЫЙ PAK',
        'select_file_prompt': 'Выберите файл (1-{n})',
        'invalid_number': 'Пожалуйста, введите корректное число',
        'unpacking': 'Распаковка {name}',
        'extracted_to': 'Извлечено в {path}',
        'no_pak_files': 'Не найдено {pattern} файлов в {path}',
        'no_files_compiled': 'Нет файлов в папке COMPILED. Сначала положите файлы в COMPILED.',
        'target_path_title': 'Целевой путь внутри PAK, куда будут добавлены файлы.',
        'target_path_example': 'например Content/Lua/GameLua/Mod/BRMod/Gameplay/Core',
        'press_enter_default': 'Нажмите Enter для значения по умолчанию: Content/Lua/',
        'path_prompt': 'Путь',
        'using_default': 'Используется путь по умолчанию: {path}',
        'using_custom': 'Используется свой путь: {path}',
        'invalid_target_path': 'Неверный целевой путь',
        'auto_proceeding': '▶ Автопродолжение перепаковки...',
        'processed_files': 'Обработано {count} файлов в {path} → {output}\nPAK готов для игры',
        'no_files_processed': 'Не обработано ни одного файла',
        'repack_failed': 'Ошибка перепаковки: {err}',
        'building_new_pak': 'Создание НОВОГО PAK по шаблону: {name}',
        'new_pak_built': 'Новый PAK создан с {count} файлами!',
        'output': 'Выход: {path}',
        'build_failed': 'Ошибка сборки: {err}',
        'build_no_files': 'Сборка не удалась - файлы не обработаны',
        'new_pak_title': 'Целевой путь внутри PAK (или пусто для относительного).',
        'new_pak_files_info': 'Файлы будут добавлены по этому пути в новом PAK.',
        'new_pak_enter_root': 'Нажмите Enter без пути (файлы в корне)',
        'target_path_enter_root': 'Целевой путь (Enter для отсутствия пути)',
        'no_path_root': 'Путь не задан - файлы будут в корне',
        'inject_title': 'ВНЕДРИТЬ LUA · ПЕРЕПАКОВАТЬ В PAK',
        'inject_desc': 'Внедрить файлы Lua прямо в PAK',
        'created_empty_folder': 'Создана пустая папка: {path}',
        'add_lua_first': 'Пожалуйста, сначала добавьте ваши LUA файлы туда!',
        'compiled_empty': 'Папка COMPILED пуста!',
        'put_lua_in': 'Пожалуйста, положите LUA файлы в: {path}',
        'files_found': 'НАЙДЕННЫЕ ФАЙЛЫ',
        'enter_target_path': 'Введите целевой путь внутри PAK:',
        'path_example_2': 'Пример: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/',
        'path_default_hint': 'Нажмите Enter для значения по умолчанию: только имя файла',
        'no_base_path': 'Базовый путь не задан - файлы будут в корне',
        'files_will_inject': '{count} файлов будет внедрено',
        'and_more': '... и ещё {count} файлов',
        'auto_proceeding_inject': '▶ Автопродолжение внедрения...',
        'searching_pak': 'Поиск PAK файлов в PAK_ORIGINAL...',
        'no_pak_found': 'PAK файл не найден в папке PAK_ORIGINAL!',
        'put_pak_in': 'Пожалуйста, положите PAK файл в: {path}',
        'found_pak': 'Найден PAK: {name}',
        'multiple_pak': 'Найдено несколько PAK файлов:',
        'enter_number_select': 'Введите номер для выбора',
        'selected': 'Выбрано: {name}',
        'invalid_input': 'Неверный ввод!',
        'backup_created': 'Создана резервная копия: {path}',
        'loading_pak': 'Загрузка PAK файла...',
        'repacking_pak': 'Перепаковка PAK...',
        'dominant_style': 'Доминирующий стиль: comp={comp}, enc={enc}, encrypted={encrypted}, block={block}',
        'plan_files': 'План: {count} файлов со своими путями.',
        'repack_complete_msg': 'Перепаковка завершена! Выход: {path}',
        'processed_with_locations': 'Обработано {count} файлов со своими путями.',
        'error_label': 'Ошибка: {err}',
        'cleanup_found': 'Найдена папка xvaLuex, удаление...',
        'cleanup_removed': 'Папка xvaLuex успешно удалена!',
        'cleanup_none': 'Папка xvaLuex не найдена.',
        'cleanup_temp': 'Удалено {count} временных файлов.',
        'cleanup_cache': 'Удалено {path}',
        'cleanup_done': 'Очистка завершена!',
        'cleanup_error': 'Ошибка при очистке: {err}',
        'thanks': 'Спасибо за использование!',
        'developer_label': 'РАЗРАБОТЧИК',
        'credit_label': 'АВТОР',
        'version_label': 'ВЕРСИЯ',
        'force_closing': 'Принудительное закрытие...',
        'interrupted': 'Прервано. Выход...',
        'fatal': 'ФАТАЛЬНАЯ ОШИБКА: {err}',
        'inject_engine': 'ДВИЖОК ВНЕДРЕНИЯ',
        'source_pak': 'Исходный PAK',
        'output_label': 'Выход',
        'injecting_label': 'Внедрение',
        'credit_field': 'Автор',
        'step_loading': 'ШАГ 1/5 · ЗАГРУЗКА ФАЙЛОВ ВНЕДРЕНИЯ',
        'step_encoding': 'ШАГ 2/5 · КОДИРОВАНИЕ ФАЙЛОВ ВНЕДРЕНИЯ',
        'loaded_files': 'Загружено {n} файл(ов)',
        'encoded_files': 'Закодировано {n} файл(ов)',
        'inject_complete': 'ВНЕДРЕНИЕ ЗАВЕРШЕНО',
        'success_label': 'УСПЕХ',
        'processing_assets': 'Обработка ресурсов...',
        'all_processed': 'Все {n} ресурсов обработаны.',
        'files_processed': 'Обработанные файлы',
        'path_in_pak': 'Путь в PAK',
        'original_size': 'Исходный размер',
        'stored_size': 'Хранимый размер',
        'col_num': '#',
        'add_files': 'Добавление файлов...',
        'extract_files': 'Извлечение файлов...',
        'new_pak_files': 'Файлы добавлены в новый PAK',
        'files_included': 'Файлов включено: {count}',
        'new_pak_written': 'Новый PAK записан: {path}',
        'no_file_in_template': 'Не найдено ни одного файла в шаблонном PAK для копирования настроек!',
        'no_file_in_edit': 'Не найдено файлов в папке EDIT!',
        'edit_empty_short': 'Нет файлов в папке EDIT.',
        'skipped_no_entry': '~ Пропущено (нет записи в PAK): {name}',
        'cannot_read_file': 'Не удаётся прочитать {path}: {err} — пропуск',
        'no_src_path': 'Элемент внедрения {i} не имеет src_path или plain_bytes — пропуск',
        'empty_internal': 'Пустой internal_path для элемента {i} — пропуск',
        'no_valid_inject': 'Нет корректных элементов для внедрения после загрузки',
        'no_files_to_repack': 'Нет файлов для перепаковки!',
        'verified_failed': 'ПРОВЕРКА НЕ ПРОЙДЕНА',
        'verified_failed_hash': 'ПРОВЕРКА НЕ ПРОЙДЕНА (несовпадение хеша индекса)',
        'stem_hash_mismatch': 'Несовпадение хеша имени (файл мог быть переименован)',
        'secure_vip': 'БЕЗОПАСНОЕ VIP СОЕДИНЕНИЕ',
        'index_decrypt_failed': 'Не удалось расшифровать индекс, попытка сырых данных',
        'index_hash_mismatch': 'Несовпадение хеша индекса (PAK изменён?)',
        'unsupported_version': 'Неподдерживаемая версия: {v}',
        'skip_file': 'Пропущено {name}: {err}',
        'created_workspace': 'Создано рабочее пространство: {path}',
        'error_creating': 'Ошибка создания {path}: {err}',
    },
    'ar': {
        'choose_language': 'اختر لغتك',
        'select_language': 'اختر اللغة',
        'lang_hint': 'اختر من 1 إلى 4',
        'invalid_lang': 'الرجاء إدخال 1 أو 2 أو 3 أو 4',
        'banner_unlimited': 'الإصدار غير المحدود',
        'banner_dev': 'المطور',
        'banner_credit': 'الحقوق',
        'banner_access': '🔓 وصول كامل · بدون قيود',
        'banner_devices': '📱 الأجهزة : غير محدودة',
        'banner_expiry': '⏰ الانتهاء : ♾ مدى الحياة',
        'banner_power': '⚡ إصدار بريميوم · قوة JINSHIFORYOU ⚡',
        'no_login': '◆ لا يلزم تسجيل دخول — مباشرة إلى الأداة! ◆',
        'powered_by': '◆ مدعوم ومقدم من {credit} ◆',
        'alert_success': 'نجاح',
        'alert_error': 'خطأ',
        'alert_warning': 'تحذير',
        'alert_info': 'معلومة',
        'alert_premium': 'بريميوم',
        'menu_title': 'القائمة الرئيسية',
        'lua_make_title': 'LUA_الترجمة',
        'menu_1_name': 'فك_PAK',
        'menu_1_desc': 'استخراج كل مدخل من .pak',
        'menu_2_name': 'ترجمة_LUA',
        'menu_2_desc': 'فك وترجمة .luac',
        'menu_3_name': 'إعادة_حزم_PAK',
        'menu_3_desc': 'إضافة ملفات جديدة بمسار محدد',
        'menu_4_name': 'بناء_PAK_جديد',
        'menu_4_desc': 'بناء PAK جديد من قالب',
        'menu_5_name': 'حقن_LUA',
        'menu_5_desc': 'حقن Lua بدون جدار حماية',
        'menu_6_name': 'تنظيف_الكل',
        'menu_6_desc': 'إزالة مجلد xvaLuex',
        'menu_7_name': 'إغلاق_TERMUX',
        'menu_7_desc': 'إغلاق الأداة',
        'enter_choice': 'أدخل اختيارك',
        'invalid_choice': 'اختيار غير صالح',
        'press_enter': 'اضغط Enter...',
        'press_enter_exit': 'اضغط Enter للخروج...',
        'select_files_title': 'اختر الملفات لـ {action}',
        'only_1_file': 'تم العثور على ملف واحد فقط:',
        'process_this_file': 'معالجة هذا الملف؟ (ن/ي)',
        'col_file': 'الملف',
        'col_size': 'الحجم',
        'all_files': 'كل الملفات',
        'cancel': 'إلغاء',
        'your_choice': 'اختيارك',
        'invalid_selection': 'اختيار غير صالح!',
        'lua_orig_empty': 'مجلد LUA_ORIGINAL فارغ!',
        'lua_edit_empty': 'مجلد LUA_EDIT فارغ!',
        'decompiling': 'جاري فك الترجمة...',
        'compiling': 'جاري الترجمة...',
        'converting': 'تحويل {name}...',
        'decompiled': 'تم فك الترجمة:',
        'failed_label': 'فشل:',
        'saved_raw': 'تم حفظ البايت كود الخام:',
        'unpack_complete': 'اكتمل فك الحزم! تم فك ترجمة {success}/{total} ملف.',
        'repack_complete': 'اكتملت إعادة الحزم! {success}/{total} بنجاح.',
        'recompile_failed': 'فشلت إعادة الترجمة:',
        'compilation_failed': 'فشلت الترجمة:',
        'compilation_timeout': 'انتهت مدة الترجمة:',
        'original_not_found': 'الأصل غير موجود:',
        'compiled': 'تمت الترجمة:',
        'fast_compile': '🚀 وضع الترجمة السريعة',
        'launching_compile': 'بدء الترجمة عالية السرعة...',
        'compile': 'ترجمة',
        'decompile': 'فك ترجمة',
        'repack': 'إعادة حزم',
        'back': 'رجوع',
        'recompile_option': 'إعادة الترجمة',
        'recompile_desc': 'LUA_EDIT → COMPILED',
        'decompile_option': 'فك الترجمة',
        'decompile_desc': 'LUA_ORIGINAL → LUA_EDIT',
        'back_option': 'رجوع',
        'back_desc': 'العودة للقائمة الرئيسية',
        'select_option': 'اختر الخيار',
        'invalid_option': 'خيار غير صالح',
        'pak_not_found': 'مجلد PAK غير موجود في {path}',
        'select_unpack': 'ملفات .pak المتاحة لفك الحزم',
        'select_repack': 'ملفات .pak المتاحة لإعادة الحزم',
        'select_template': 'اختر PAK القالب',
        'select_file_prompt': 'اختر الملف (1-{n})',
        'invalid_number': 'الرجاء إدخال رقم صالح',
        'unpacking': 'فك حزم {name}',
        'extracted_to': 'تم الاستخراج إلى {path}',
        'no_pak_files': 'لم يتم العثور على ملفات {pattern} في {path}',
        'no_files_compiled': 'لا توجد ملفات في مجلد COMPILED. ضع الملفات المراد إضافتها في COMPILED أولاً.',
        'target_path_title': 'المسار المستهدف داخل PAK حيث يجب إضافة الملفات.',
        'target_path_example': 'مثال: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core',
        'press_enter_default': 'اضغط Enter لاستخدام الافتراضي: Content/Lua/',
        'path_prompt': 'المسار',
        'using_default': 'استخدام المسار الافتراضي: {path}',
        'using_custom': 'استخدام مسار مخصص: {path}',
        'invalid_target_path': 'مسار مستهدف غير صالح',
        'auto_proceeding': '▶ متابعة تلقائية لإعادة الحزم...',
        'processed_files': 'تمت معالجة {count} ملف إلى {path} → {output}\nPAK جاهز للعبة',
        'no_files_processed': 'لم تتم معالجة أي ملفات',
        'repack_failed': 'فشلت إعادة الحزم: {err}',
        'building_new_pak': 'بناء PAK جديد باستخدام القالب: {name}',
        'new_pak_built': 'تم بناء PAK جديد مع {count} ملف!',
        'output': 'الإخراج: {path}',
        'build_failed': 'فشل البناء: {err}',
        'build_no_files': 'فشل البناء - لم تتم معالجة ملفات',
        'new_pak_title': 'المسار المستهدف داخل PAK (أو فارغ للمسار النسبي).',
        'new_pak_files_info': 'ستضاف الملفات إلى هذا المسار داخل PAK الجديد.',
        'new_pak_enter_root': 'اضغط Enter مباشرة بدون مسار (الملفات في الجذر)',
        'target_path_enter_root': 'المسار المستهدف (اضغط Enter بدون مسار)',
        'no_path_root': 'لم يتم تعيين مسار - الملفات في الجذر',
        'inject_title': 'حقن LUA · إعادة الحزم إلى PAK',
        'inject_desc': 'حقن ملفات Lua مباشرة في PAK',
        'created_empty_folder': 'تم إنشاء مجلد فارغ: {path}',
        'add_lua_first': 'الرجاء إضافة ملفات LUA هناك أولاً!',
        'compiled_empty': 'مجلد COMPILED فارغ!',
        'put_lua_in': 'الرجاء وضع ملفات LUA في: {path}',
        'files_found': 'الملفات الموجودة',
        'enter_target_path': 'أدخل المسار المستهدف داخل PAK:',
        'path_example_2': 'مثال: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/',
        'path_default_hint': 'اضغط Enter للافتراضي: اسم الملف فقط',
        'no_base_path': 'لا يوجد مسار أساسي - الملفات في الجذر',
        'files_will_inject': 'سيتم حقن {count} ملف',
        'and_more': '... و {count} ملف آخر',
        'auto_proceeding_inject': '▶ متابعة تلقائية للحقن...',
        'searching_pak': 'البحث عن ملفات PAK في PAK_ORIGINAL...',
        'no_pak_found': 'لم يتم العثور على ملف PAK في مجلد PAK_ORIGINAL!',
        'put_pak_in': 'الرجاء وضع ملف PAK في: {path}',
        'found_pak': 'تم العثور على PAK: {name}',
        'multiple_pak': 'تم العثور على عدة ملفات PAK:',
        'enter_number_select': 'أدخل الرقم للاختيار',
        'selected': 'المختار: {name}',
        'invalid_input': 'إدخال غير صالح!',
        'backup_created': 'تم إنشاء نسخة احتياطية: {path}',
        'loading_pak': 'جاري تحميل ملف PAK...',
        'repacking_pak': 'جاري إعادة حزم PAK...',
        'dominant_style': 'النمط السائد: comp={comp}, enc={enc}, encrypted={encrypted}, block={block}',
        'plan_files': 'الخطة: {count} ملفات بمسارات مخصصة.',
        'repack_complete_msg': 'اكتملت إعادة الحزم! الإخراج: {path}',
        'processed_with_locations': 'تمت معالجة {count} ملف بمسارات مخصصة.',
        'error_label': 'خطأ: {err}',
        'cleanup_found': 'تم العثور على مجلد xvaLuex، جاري الإزالة...',
        'cleanup_removed': 'تم إزالة مجلد xvaLuex بنجاح!',
        'cleanup_none': 'لم يتم العثور على مجلد xvaLuex.',
        'cleanup_temp': 'تمت إزالة {count} ملف مؤقت.',
        'cleanup_cache': 'تمت إزالة {path}',
        'cleanup_done': 'اكتمل التنظيف!',
        'cleanup_error': 'خطأ أثناء التنظيف: {err}',
        'thanks': 'شكراً لاستخدامك!',
        'developer_label': 'المطور',
        'credit_label': 'الحقوق',
        'version_label': 'الإصدار',
        'force_closing': 'إغلاق قسري...',
        'interrupted': 'تم المقاطعة. خروج...',
        'fatal': 'خطأ قاتل: {err}',
        'inject_engine': 'محرك الحقن',
        'source_pak': 'PAK المصدر',
        'output_label': 'الإخراج',
        'injecting_label': 'حقن',
        'credit_field': 'الحقوق',
        'step_loading': 'الخطوة 1/5 · تحميل ملفات الحقن',
        'step_encoding': 'الخطوة 2/5 · ترميز ملفات الحقن',
        'loaded_files': 'تم تحميل {n} ملف',
        'encoded_files': 'تم ترميز {n} ملف',
        'inject_complete': 'اكتمل الحقن',
        'success_label': 'نجاح',
        'processing_assets': 'معالجة الأصول...',
        'all_processed': 'تمت معالجة كل {n} أصل.',
        'files_processed': 'الملفات المعالجة',
        'path_in_pak': 'المسار في PAK',
        'original_size': 'الحجم الأصلي',
        'stored_size': 'الحجم المخزن',
        'col_num': '#',
        'add_files': 'إضافة الملفات...',
        'extract_files': 'استخراج الملفات...',
        'new_pak_files': 'الملفات المضافة إلى PAK الجديد',
        'files_included': 'الملفات المضمنة: {count}',
        'new_pak_written': 'تم كتابة PAK الجديد: {path}',
        'no_file_in_template': 'لم يتم العثور على أي ملف في PAK القالب لنسخ الإعدادات منه!',
        'no_file_in_edit': 'لم يتم العثور على ملفات في مجلد EDIT!',
        'edit_empty_short': 'لا توجد ملفات في مجلد EDIT.',
        'skipped_no_entry': '~ تم التخطي (لا يوجد مدخل في PAK): {name}',
        'cannot_read_file': 'لا يمكن قراءة {path}: {err} — تخطي',
        'no_src_path': 'عنصر الحقن {i} ليس له src_path أو plain_bytes — تخطي',
        'empty_internal': 'internal_path فارغ للعنصر {i} — تخطي',
        'no_valid_inject': 'لا توجد عناصر حقن صالحة بعد التحميل',
        'no_files_to_repack': 'لا توجد ملفات لإعادة الحزم!',
        'verified_failed': 'فشل التحقق',
        'verified_failed_hash': 'فشل التحقق (عدم تطابق هاش الفهرس)',
        'stem_hash_mismatch': 'عدم تطابق هاش الاسم (قد يكون الملف مُعاد تسميته)',
        'secure_vip': 'اتصال VIP آمن',
        'index_decrypt_failed': 'فشل فك تشفير الفهرس، محاولة الخام',
        'index_hash_mismatch': 'عدم تطابق هاش الفهرس (تم تعديل PAK؟)',
        'unsupported_version': 'إصدار غير مدعوم: {v}',
        'skip_file': 'تم تخطي {name}: {err}',
        'created_workspace': 'تم إنشاء مساحة العمل: {path}',
        'error_creating': 'خطأ في إنشاء {path}: {err}',
    },
    'zh': {
        'choose_language': '选择您的语言',
        'select_language': '选择语言',
        'lang_hint': '选择 1-4',
        'invalid_lang': '请输入 1、2、3 或 4',
        'banner_unlimited': '无限版',
        'banner_dev': '开发者',
        'banner_credit': '鸣谢',
        'banner_access': '🔓 完全访问 · 无限制',
        'banner_devices': '📱 设备 : 无限',
        'banner_expiry': '⏰ 有效期 : ♾ 永久',
        'banner_power': '⚡ 高级版 · JINSHIFORYOU 力量 ⚡',
        'no_login': '◆ 无需登录 — 直接使用工具! ◆',
        'powered_by': '◆ 由 {credit} 提供支持 ◆',
        'alert_success': '成功',
        'alert_error': '错误',
        'alert_warning': '警告',
        'alert_info': '信息',
        'alert_premium': '高级',
        'menu_title': '主菜单',
        'lua_make_title': 'LUA_编译',
        'menu_1_name': '解包_PAK',
        'menu_1_desc': '从 .pak 提取每个条目',
        'menu_2_name': 'LUA_编译',
        'menu_2_desc': '反编译和编译 .luac',
        'menu_3_name': '重新打包_PAK',
        'menu_3_desc': '将新文件添加到目标路径',
        'menu_4_name': '构建新_PAK',
        'menu_4_desc': '从模板构建新 PAK',
        'menu_5_name': '注入_LUA',
        'menu_5_desc': '绕过防火墙注入 Lua',
        'menu_6_name': '全部清理',
        'menu_6_desc': '删除 xvaLuex 目录',
        'menu_7_name': '关闭_TERMUX',
        'menu_7_desc': '关闭工具',
        'enter_choice': '输入您的选择',
        'invalid_choice': '无效选择',
        'press_enter': '按 Enter...',
        'press_enter_exit': '按 Enter 退出...',
        'select_files_title': '选择要 {action} 的文件',
        'only_1_file': '只找到 1 个文件:',
        'process_this_file': '处理此文件? (Y/n)',
        'col_file': '文件',
        'col_size': '大小',
        'all_files': '所有文件',
        'cancel': '取消',
        'your_choice': '您的选择',
        'invalid_selection': '无效选择!',
        'lua_orig_empty': 'LUA_ORIGINAL 文件夹为空!',
        'lua_edit_empty': 'LUA_EDIT 文件夹为空!',
        'decompiling': '反编译中...',
        'compiling': '编译中...',
        'converting': '转换 {name}...',
        'decompiled': '已反编译:',
        'failed_label': '失败:',
        'saved_raw': '已保存原始字节码:',
        'unpack_complete': '解包完成! {success}/{total} 个文件已反编译。',
        'repack_complete': '重新打包完成! {success}/{total} 成功。',
        'recompile_failed': '重新编译失败:',
        'compilation_failed': '编译失败:',
        'compilation_timeout': '编译超时:',
        'original_not_found': '未找到原文件:',
        'compiled': '已编译:',
        'fast_compile': '🚀 快速编译模式',
        'launching_compile': '启动高速编译...',
        'compile': '编译',
        'decompile': '反编译',
        'repack': '重新打包',
        'back': '返回',
        'recompile_option': '重新编译',
        'recompile_desc': 'LUA_EDIT → COMPILED',
        'decompile_option': '反编译',
        'decompile_desc': 'LUA_ORIGINAL → LUA_EDIT',
        'back_option': '返回',
        'back_desc': '返回主菜单',
        'select_option': '选择选项',
        'invalid_option': '无效选项',
        'pak_not_found': 'PAK 文件夹未在 {path} 找到',
        'select_unpack': '可用于解包的 .pak 文件',
        'select_repack': '可用于重新打包的 .pak 文件',
        'select_template': '选择模板 PAK',
        'select_file_prompt': '选择文件 (1-{n})',
        'invalid_number': '请输入有效数字',
        'unpacking': '解包 {name}',
        'extracted_to': '已提取到 {path}',
        'no_pak_files': '在 {path} 中未找到 {pattern} 文件',
        'no_files_compiled': 'COMPILED 文件夹中没有文件。请先将文件放入 COMPILED。',
        'target_path_title': 'PAK 内应添加文件的目标路径。',
        'target_path_example': '例如 Content/Lua/GameLua/Mod/BRMod/Gameplay/Core',
        'press_enter_default': '按 Enter 使用默认值: Content/Lua/',
        'path_prompt': '路径',
        'using_default': '使用默认路径: {path}',
        'using_custom': '使用自定义路径: {path}',
        'invalid_target_path': '无效目标路径',
        'auto_proceeding': '▶ 自动继续重新打包...',
        'processed_files': '已处理 {count} 个文件到 {path} → {output}\nPAK 可用于游戏',
        'no_files_processed': '未处理任何文件',
        'repack_failed': '重新打包失败: {err}',
        'building_new_pak': '使用模板构建新 PAK: {name}',
        'new_pak_built': '新 PAK 已构建，包含 {count} 个文件!',
        'output': '输出: {path}',
        'build_failed': '构建失败: {err}',
        'build_no_files': '构建失败 - 未处理任何文件',
        'new_pak_title': 'PAK 内的目标路径 (空白表示相对路径)。',
        'new_pak_files_info': '文件将被添加到新 PAK 中的此路径。',
        'new_pak_enter_root': '直接按 Enter 表示无路径 (文件在根目录)',
        'target_path_enter_root': '目标路径 (按 Enter 表示无路径)',
        'no_path_root': '未设置路径 - 文件将在根目录',
        'inject_title': '注入 LUA · 重新打包到 PAK',
        'inject_desc': '将 Lua 文件直接注入 PAK',
        'created_empty_folder': '已创建空文件夹: {path}',
        'add_lua_first': '请先将您的 LUA 文件放在那里!',
        'compiled_empty': 'COMPILED 文件夹为空!',
        'put_lua_in': '请将 LUA 文件放入: {path}',
        'files_found': '找到的文件',
        'enter_target_path': '输入 PAK 内的目标路径:',
        'path_example_2': '示例: Content/Lua/GameLua/Mod/BRMod/Gameplay/Core/',
        'path_default_hint': '按 Enter 使用默认值: 仅文件名',
        'no_base_path': '无基本路径 - 文件将在根目录',
        'files_will_inject': '将注入 {count} 个文件',
        'and_more': '... 还有 {count} 个文件',
        'auto_proceeding_inject': '▶ 自动继续注入...',
        'searching_pak': '在 PAK_ORIGINAL 中搜索 PAK 文件...',
        'no_pak_found': '在 PAK_ORIGINAL 文件夹中未找到 PAK 文件!',
        'put_pak_in': '请将 PAK 文件放入: {path}',
        'found_pak': '找到 PAK: {name}',
        'multiple_pak': '找到多个 PAK 文件:',
        'enter_number_select': '输入编号选择',
        'selected': '已选择: {name}',
        'invalid_input': '无效输入!',
        'backup_created': '已创建备份: {path}',
        'loading_pak': '加载 PAK 文件...',
        'repacking_pak': '重新打包 PAK...',
        'dominant_style': '主要样式: comp={comp}, enc={enc}, encrypted={encrypted}, block={block}',
        'plan_files': '计划: {count} 个文件使用自定义位置。',
        'repack_complete_msg': '重新打包完成! 输出: {path}',
        'processed_with_locations': '已处理 {count} 个文件使用自定义位置。',
        'error_label': '错误: {err}',
        'cleanup_found': '找到 xvaLuex 目录，正在删除...',
        'cleanup_removed': 'xvaLuex 目录已成功删除!',
        'cleanup_none': '未找到 xvaLuex 目录。',
        'cleanup_temp': '已删除 {count} 个临时文件。',
        'cleanup_cache': '已删除 {path}',
        'cleanup_done': '清理完成!',
        'cleanup_error': '清理时出错: {err}',
        'thanks': '感谢使用!',
        'developer_label': '开发者',
        'credit_label': '鸣谢',
        'version_label': '版本',
        'force_closing': '强制关闭...',
        'interrupted': '已中断。退出...',
        'fatal': '致命错误: {err}',
        'inject_engine': '注入引擎',
        'source_pak': '源 PAK',
        'output_label': '输出',
        'injecting_label': '注入',
        'credit_field': '鸣谢',
        'step_loading': '步骤 1/5 · 加载注入文件',
        'step_encoding': '步骤 2/5 · 编码注入文件',
        'loaded_files': '已加载 {n} 个文件',
        'encoded_files': '已编码 {n} 个文件',
        'inject_complete': '注入完成',
        'success_label': '成功',
        'processing_assets': '处理资源...',
        'all_processed': '全部 {n} 个资源已处理。',
        'files_processed': '已处理文件',
        'path_in_pak': 'PAK 中的路径',
        'original_size': '原始大小',
        'stored_size': '存储大小',
        'col_num': '#',
        'add_files': '添加文件...',
        'extract_files': '提取文件...',
        'new_pak_files': '已添加到新 PAK 的文件',
        'files_included': '包含文件: {count}',
        'new_pak_written': '新 PAK 已写入: {path}',
        'no_file_in_template': '在模板 PAK 中未找到任何文件可复制设置!',
        'no_file_in_edit': '在 EDIT 文件夹中未找到文件!',
        'edit_empty_short': 'EDIT 文件夹中没有文件。',
        'skipped_no_entry': '~ 已跳过 (PAK 中无条目): {name}',
        'cannot_read_file': '无法读取 {path}: {err} — 跳过',
        'no_src_path': '注入项 {i} 没有 src_path 或 plain_bytes — 跳过',
        'empty_internal': '项 {i} 的 internal_path 为空 — 跳过',
        'no_valid_inject': '加载后没有有效的注入项',
        'no_files_to_repack': '没有文件需要重新打包!',
        'verified_failed': '验证失败',
        'verified_failed_hash': '验证失败 (索引哈希不匹配)',
        'stem_hash_mismatch': '名称哈希不匹配 (文件可能已被重命名)',
        'secure_vip': '安全 VIP 连接',
        'index_decrypt_failed': '索引解密失败，尝试原始数据',
        'index_hash_mismatch': '索引哈希不匹配 (PAK 已修改?)',
        'unsupported_version': '不支持的版本: {v}',
        'skip_file': '已跳过 {name}: {err}',
        'created_workspace': '已创建工作区: {path}',
        'error_creating': '创建 {path} 时出错: {err}',
    }
}

def t(key, **kw):
    lang = STRINGS.get(LANG_CODE, STRINGS['en'])
    s = lang.get(key)
    if s is None:
        s = STRINGS['en'].get(key, key)
    if kw:
        try:
            return s.format(**kw)
        except Exception:
            return s
    return s

def setup():
    os.system('cls' if os.name == 'nt' else 'clear')

if not hasattr(it, 'batched'):
    def batched(iterable, n):
        it_iter = iter(iterable)
        while True:
            chunk = list(it.islice(it_iter, n))
            if not chunk:
                break
            yield chunk
    it.batched = batched

PAK_MODE_AVAILABLE = True
try:
    import gmalg
except ImportError:
    try:
        import subprocess as _sp
        _sp.run([sys.executable, '-m', 'pip', 'install', 'gmalg', '--break-system-packages', '-q'],
                capture_output=True)
        import gmalg
    except Exception:
        pass

try:
    import gmalg
    try:
        from gmalg.base import BlockCipher
        from gmalg.errors import IncorrectLengthError
        from gmalg.utils import ROL32
    except ImportError:
        class BlockCipher: pass
        class IncorrectLengthError(Exception):
            def __init__(self, name, expected, actual):
                super().__init__(f"Incorrect length for {name}: expected {expected}, got {actual}")
        def ROL32(x, n): return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))
except ImportError:
    PAK_MODE_AVAILABLE = False
    class BlockCipher: pass
    class IncorrectLengthError(Exception):
        def __init__(self, name, expected, actual):
            super().__init__(f"Incorrect length for {name}: expected {expected}, got {actual}")
    def ROL32(x, n): return ((x << n) & 0xFFFFFFFF) | (x >> (32 - n))

try:
    from Crypto.Cipher import AES
    from Crypto.Cipher.AES import MODE_CBC
    from Crypto.Hash import SHA1
    from Crypto.Util.Padding import pad, unpad
except ImportError:
    try:
        import subprocess as _sp
        _sp.run([sys.executable, '-m', 'pip', 'install', 'pycryptodome', '--break-system-packages', '-q'],
                capture_output=True)
        from Crypto.Cipher import AES
        from Crypto.Cipher.AES import MODE_CBC
        from Crypto.Hash import SHA1
        from Crypto.Util.Padding import pad, unpad
    except Exception:
        PAK_MODE_AVAILABLE = False
        # Fallback SHA1 using hashlib so PAK hash checks don't NameError
        class _SHA1Wrapper:
            digest_size = 20
            def __init__(self, data=b''):
                import hashlib as _hl
                self._h = _hl.sha1(data)
            @staticmethod
            def new(data=b''):
                return _SHA1Wrapper(data)
            def digest(self):
                return self._h.digest()
            def update(self, data):
                self._h.update(data)
        SHA1 = _SHA1Wrapper

try:
    from zstandard import ZstdDecompressor, ZstdCompressor, ZstdCompressionDict, DICT_TYPE_AUTO
except ImportError:
    PAK_MODE_AVAILABLE = False

RED = "#FF3366"
GREEN = "#39FF14"
BLUE = "#00BFFF"
GOLD = "#C8A2C8"        # soft lilac-gold for JINSHIFORYOU
NEON = "#BF5FFF"        # vivid purple — primary brand accent
ACCENT = "#FF6EC7"      # hot pink
MUTED = "#7A7A9A"
WARN = "#FFB347"
SUCCESS = "#39FF14"
ERR = "#FF3366"
WHITE = "#F0F0FF"
CYAN = "#00F5FF"
MAGENTA = "#DA70D6"
PURPLE = "#9D4EDD"
DEEP = "#0D0D1A"
ROYAL = "#6A0DAD"
ICE = "#7DF9FF"
EMBER = "#FF6B35"

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.box import ROUNDED, HEAVY, DOUBLE, SQUARE, MINIMAL, SIMPLE_HEAVY
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn, TimeElapsedColumn
from rich.prompt import Prompt, Confirm
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.text import Text
from rich.align import Align
from rich.layout import Layout
from rich.live import Live
from rich.columns import Columns
from rich.rule import Rule
from rich import print as rprint

console = Console()

def safe_input(prompt: str = "") -> str:
    try:
        return input(prompt)
    except (KeyboardInterrupt, EOFError):
        return ""

def escape(text: str) -> str:
    return text.replace("[", "\\[").replace("]", "\\]")

class AnimatedBorder:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._start_time = time.time()
        return cls._instance

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            cls()
        return cls._instance

    def get_rainbow_color(self, offset=0, speed=1.0):
        t_val = time.time() * speed + offset
        r = int(abs(math.sin(t_val)) * 255)
        g = int(abs(math.sin(t_val + 2.094)) * 255)
        b = int(abs(math.sin(t_val + 4.188)) * 255)
        return f"#{r:02x}{g:02x}{b:02x}"

    def get_moving_border_style(self, position=0, speed=0.8):
        colors = [RED, WARN, SUCCESS, BLUE, PURPLE, MAGENTA, ACCENT, GOLD, ROYAL, ICE, EMBER, NEON]
        t_val = time.time() * speed
        idx = int((t_val + position) % len(colors))
        return colors[idx]

def get_rainbow_color(offset=0, speed=1.0):
    return AnimatedBorder.get_instance().get_rainbow_color(offset, speed)

def get_border_style(position=0, speed=0.8):
    return AnimatedBorder.get_instance().get_moving_border_style(position, speed)

def hexa_alert(message: str, kind: str = "info") -> None:
    tags = {
        "success": ("✔", SUCCESS, t('alert_success')),
        "error":   ("✘", ERR,     t('alert_error')),
        "warning": ("⚠", WARN,    t('alert_warning')),
        "info":    ("◈", ICE,     t('alert_info')),
        "premium": ("★", NEON,    t('alert_premium')),
    }
    tag, color, label = tags.get(kind, tags["info"])
    console.print()
    console.print(f"  [{color}]{tag}  [{color} bold]{label}[/{color} bold][/{color}]  [white]{message}[/white]  [dim]· {CREDIT}[/dim]")
    console.print()

def hexa_section(title: str) -> None:
    ab = AnimatedBorder.get_instance()
    c = ab.get_moving_border_style(0, 0.4)
    bar = "─" * (len(title) + 6)
    console.print()
    console.print(f"  [{c}]┌{bar}┐[/{c}]")
    console.print(f"  [{c}]│[/{c}]  [bold {ICE}]◈  {title}[/bold {ICE}]  [dim]· {CREDIT}[/dim]  [{c}]│[/{c}]")
    console.print(f"  [{c}]└{bar}┘[/{c}]")
    console.print()

def hexa_prompt(label: str) -> str:
    console.print(f"  [bold {ICE}]▸ {label}[/bold {ICE}]  [dim]· {CREDIT}[/dim]")
    return safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip()

def print_credit():
    t_obj = Text()
    t_obj.append("  ┌─── ", style=f"bold {NEON}")
    t_obj.append("R E N N Z O H H", style=f"bold {ICE}")
    t_obj.append(" ───┐  ", style=f"bold {NEON}")
    console.print(t_obj)
    t2 = Text()
    t2.append("  │  ", style=f"bold {NEON}")
    t2.append(t('credit_label'), style=f"bold {MAGENTA}")
    t2.append("  ⟶  ", style="dim")
    t2.append(CREDIT, style=f"bold {ICE}")
    t2.append("  │  ", style=f"bold {NEON}")
    console.print(t2)
    console.print(f"  └{'─' * 22}┘  ", style=f"bold {NEON}")

def format_time(seconds: int) -> str:
    if seconds < 0: return "Unlimited"
    if seconds == 0: return "Expired"
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    if days > 0: return f"{days}d {hours}h {minutes}m {secs}s"
    elif hours > 0: return f"{hours}h {minutes}m {secs}s"
    else: return f"{minutes}m {secs}s"

def print_main_banner(title="", key_info=None):
    os.system('cls' if os.name == 'nt' else 'clear')
    ab = AnimatedBorder.get_instance()
    c1 = ab.get_moving_border_style(0, 0.5)
    c2 = ab.get_moving_border_style(4, 0.5)

    logo = [
        " ██████╗ ███████╗███╗  ██╗███╗  ██╗███████╗ ██████╗ ██╗  ██╗██╗  ██╗",
        " ██╔══██╗██╔════╝████╗ ██║████╗ ██║╚══███╔╝██╔═══██╗██║  ██║██║  ██║",
        " ██████╔╝█████╗  ██╔██╗██║██╔██╗██║  ███╔╝ ██║   ██║███████║███████║",
        " ██╔══██╗██╔══╝  ██║╚████║██║╚████║ ███╔╝  ██║   ██║██╔══██║██╔══██║",
        " ██║  ██║███████╗██║ ╚███║██║ ╚███║███████╗╚██████╔╝██║  ██║██║  ██║",
        " ╚═╝  ╚═╝╚══════╝╚═╝  ╚══╝╚═╝  ╚══╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝",
    ]
    logo_colors = [NEON, NEON, ICE, ICE, MAGENTA, PURPLE]
    console.print()
    for line, color in zip(logo, logo_colors):
        console.print(f"[bold {color}]{line}[/bold {color}]")
    console.print()

    W = 70
    def cline(text, color):
        import re as _re
        clean = _re.sub(r'\[.*?\]', '', text)
        pt = W - 2 - len(clean)
        lp = pt // 2; rp = pt - lp
        console.print(f"[{c1}]║[/{c1}][bold {color}]{' '*lp}{text}{' '*rp}[/bold {color}][{c1}]║[/{c1}]")

    console.print(f"[{c1}]╔{'═'*(W-2)}╗[/{c1}]")
    cline(f"⚡  {TOOL_VERSION}  ·  PAK · LUA ENGINE  ⚡", NEON)
    console.print(f"[{c1}]╠{'═'*(W-2)}╣[/{c1}]")
    cline(f"DEV : @JINSHIFORYOU          CREDIT : {CREDIT}", MAGENTA)
    console.print(f"[{c1}]╠{'─'*(W-2)}╣[/{c1}]")
    cline("✔  FULL ACCESS  ·  LIFETIME  ·  NO RESTRICTIONS", SUCCESS)
    console.print(f"[{c1}]╚{'═'*(W-2)}╝[/{c1}]")
    console.print()

    if title:
        bar = "═" * (len(title) + 4)
        console.print(f"  [{c2}]╔{bar}╗[/{c2}]")
        console.print(f"  [{c2}]║[/{c2}]  [bold {ICE}]{title}[/bold {ICE}]  [{c2}]║[/{c2}]")
        console.print(f"  [{c2}]╚{bar}╝[/{c2}]")
        console.print()

def human_size(size: int) -> str:
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            return f'{size:.2f} {unit}'
        size /= 1024.0
    return f'{size:.2f} PB'

def get_lua_pak_root() -> Path:
    docs_path = Path("/storage/emulated/0/Documents/JINSHIFORYOU")
    if not docs_path.exists():
        docs_path.mkdir(parents=True, exist_ok=True)
        console.print(f"[{SUCCESS}]✓ {t('created_workspace', path=docs_path)}  [dim]· {CREDIT}[/dim][/{SUCCESS}]")
    return docs_path

LUA_PAK_ROOT = get_lua_pak_root()
SOURCE_DIR = LUA_PAK_ROOT / "SOURCE"
REAL_DIR   = LUA_PAK_ROOT / "LUA_ORIGINAL"
EDIT_DIR   = LUA_PAK_ROOT / "COMPILED"
UNPACK_DIR = LUA_PAK_ROOT / "LUA_EDIT"
PAK_DIR    = LUA_PAK_ROOT / "PAK_ORIGINAL"
PAK_UNPACK_DIR = LUA_PAK_ROOT / "PAK_UNPACK"
RESULT_DIR = LUA_PAK_ROOT / "PAK_RESULT"
CONFIG_FILE_PATH = LUA_PAK_ROOT / "config.json"

FORCE_COMPILE = True
SKIP_ALL_FIXES = True
SKIP_AUTO_FIX = True

def load_config():
    config = {}
    if CONFIG_FILE_PATH.exists():
        try:
            with open(CONFIG_FILE_PATH, 'r') as f:
                config = json.load(f)
        except Exception:
            pass
    return config

def save_config(config):
    try:
        with open(CONFIG_FILE_PATH, 'w') as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass

def hexa_prompt_with_default(label: str, default: str = "") -> str:
    console.print(f"  [bold {ICE}]▸ {label}[/bold {ICE}]  [dim]· {CREDIT}[/dim]")
    if default:
        console.print(f"  [{SUCCESS}]└─▶[/{SUCCESS}] [bold {GOLD}]{default}[/bold {GOLD}]")
        console.print(f"  [dim](Press Enter for default)[/dim]")
        result = safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip()
        return result if result else default
    else:
        return safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip()

def setup_directories():
    for d in [REAL_DIR, UNPACK_DIR, EDIT_DIR, PAK_DIR, PAK_UNPACK_DIR, RESULT_DIR, SOURCE_DIR]:
        try: d.mkdir(parents=True, exist_ok=True)
        except OSError as e: console.print(f"[{ERR}]{t('error_creating', path=d, err=e)}[/{ERR}]")

def get_real_files():
    return [f for f in os.listdir(REAL_DIR) if f.lower().endswith((".lua",".luac",".slua"))] if REAL_DIR.exists() else []

def get_unpack_files():
    return [f for f in os.listdir(UNPACK_DIR) if f.endswith(".lua")] if UNPACK_DIR.exists() else []

def _load_xor_key() -> bytes:
    env_key = os.environ.get('BGMI_XOR_KEY')
    if env_key:
        try:
            key_bytes = bytes.fromhex(env_key.replace(' ', '').replace(':', '').replace('-', ''))
            if len(key_bytes) == 32: return key_bytes
        except ValueError: pass
    return bytes([0x11, 0x21, 0x36, 0x47, 0x46, 0x57, 0xA7, 0x8D, 0x9D, 0x84, 0x90, 0xD8, 0xAB, 0x00, 0x8C, 0x35, 0x26, 0x1A, 0xF7, 0xE4, 0x58, 0x05, 0xB8, 0xB3, 0x15, 0x07, 0xD0, 0x2C, 0x1E, 0x8F, 0xF6, 0xC8])

STRING_XOR_KEY = _load_xor_key()

_BGMI_TO_STD = [13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,0,1,2,3,4,5,6,7,8,9,10,11,12,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46]
BGMI_TO_STD = _BGMI_TO_STD + [i for i in range(len(_BGMI_TO_STD), 64)]
STD_TO_BGMI = {v: k for k, v in enumerate(BGMI_TO_STD) if k < len(BGMI_TO_STD)}
STD_FMT = [0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,2,2,0,2,0,1,0,3]
iABC, iABx, iAsBx, iAx = 0, 1, 2, 3
HEADER_SIZE = 33

class BinaryReader:
    def __init__(self, data: bytes, sizet: int = 4):
        self.data = bytearray(data); self.pos = 0; self.sizet = sizet
    def byte(self) -> int:
        if self.pos >= len(self.data): raise EOFError()
        v = self.data[self.pos]; self.pos += 1; return v
    def int32(self) -> int:
        if self.pos + 4 > len(self.data): raise EOFError()
        v = struct.unpack_from('<i', self.data, self.pos)[0]; self.pos += 4; return v
    def uint32(self) -> int:
        if self.pos + 4 > len(self.data): raise EOFError()
        v = struct.unpack_from('<I', self.data, self.pos)[0]; self.pos += 4; return v
    def double(self) -> float:
        if self.pos + 8 > len(self.data): raise EOFError()
        v = struct.unpack_from('<d', self.data, self.pos)[0]; self.pos += 8; return v
    def int64(self) -> int:
        if self.pos + 8 > len(self.data): raise EOFError()
        v = struct.unpack_from('<q', self.data, self.pos)[0]; self.pos += 8; return v
    def bytes(self, n: int) -> bytes:
        if self.pos + n > len(self.data): raise EOFError()
        v = self.data[self.pos:self.pos+n]; self.pos += n; return bytes(v)
    def pubg_string(self) -> Optional[str]:
        sz = self.byte()
        if sz == 0xFF: sz = self.uint32()
        if sz == 0: return None
        sz -= 1
        enc = self.bytes(sz)
        dec = bytes(enc[i] ^ STRING_XOR_KEY[i % 32] for i in range(len(enc)))
        try: return dec.decode('utf-8', errors='replace')
        except Exception: return dec.decode('latin-1')
    def std_string(self) -> Optional[str]:
        sz = self.byte()
        if sz == 0xFF:
            if self.sizet == 8:
                if self.pos + 8 > len(self.data): raise EOFError()
                sz = struct.unpack_from('<Q', self.data, self.pos)[0]; self.pos += 8
            else: sz = self.uint32()
        if sz == 0: return None
        sz -= 1
        raw = self.bytes(sz)
        try: return raw.decode('utf-8', errors='replace')
        except Exception: return raw.decode('latin-1')

class BinaryWriter:
    def __init__(self): self.buf = bytearray()
    def byte(self, v): self.buf.append(v & 0xFF)
    def int32(self, v): self.buf.extend(struct.pack('<i', v))
    def uint32(self, v): self.buf.extend(struct.pack('<I', v))
    def int64(self, v): self.buf.extend(struct.pack('<q', v))
    def double(self, v): self.buf.extend(struct.pack('<d', v))
    def raw(self, data): self.buf.extend(data)
    def lua_string(self, s: Optional[str], is_pubg: bool = False):
        if s is None: self.byte(0); return
        e = s.encode('utf-8') if isinstance(s, str) else s
        sz = len(e) + 1
        if sz < 0xFF: self.byte(sz)
        else: self.byte(0xFF); self.uint32(sz)
        if is_pubg:
            enc = bytes(e[i] ^ STRING_XOR_KEY[i % 32] for i in range(len(e)))
            self.raw(enc)
        else: self.raw(e)
    def lua_inst(self, op, A, B, C, Bx, sBx, Ax, fmt):
        op &= 0x3F
        if   fmt == iABC:  r = op | ((A & 0xFF)<<6) | ((C & 0x1FF)<<14) | ((B & 0x1FF)<<23)
        elif fmt == iABx:  r = op | ((A & 0xFF)<<6) | ((Bx & 0x3FFFF)<<14)
        elif fmt == iAsBx: r = op | ((A & 0xFF)<<6) | (((sBx+131071) & 0x3FFFF)<<14)
        elif fmt == iAx:   r = op | ((Ax & 0x3FFFFFF)<<6)
        else: r = 0
        self.uint32(r)
    def get_data(self) -> bytes: return bytes(self.buf)

def _convert_function(reader: BinaryReader, writer: BinaryWriter, to_std: bool = True):
    src = reader.pubg_string() if to_std else reader.std_string()
    writer.lua_string(src, is_pubg=(not to_std))
    linedefined = reader.int32(); writer.int32(linedefined)
    writer.int32(reader.int32())
    writer.byte(reader.byte()); writer.byte(reader.byte()); writer.byte(reader.byte())
    csz = reader.uint32(); writer.uint32(csz)
    opmap = BGMI_TO_STD if to_std else STD_TO_BGMI
    for _ in range(csz):
        raw = reader.uint32()
        bop = raw & 0x3F; A = (raw >> 6) & 0xFF; B = (raw >> 23) & 0x1FF; C = (raw >> 14) & 0x1FF
        Bx = (raw >> 14) & 0x3FFFF; sBx = Bx - 131071; Ax = (raw >> 6) & 0x3FFFFFF
        sop = opmap[bop] if bop < len(opmap) else bop
        fmt = STD_FMT[sop] if sop < len(STD_FMT) else iABC
        writer.lua_inst(sop, A, B, C, Bx, sBx, Ax, fmt)
    nk = reader.uint32(); writer.uint32(nk)
    for _ in range(nk):
        ty = reader.byte(); writer.byte(ty)
        if ty == 0: pass
        elif ty == 1: writer.byte(reader.byte())
        elif ty == 3: writer.double(reader.double())
        elif ty == 19: writer.int64(reader.int64())
        elif ty in (4, 20):
            s = reader.pubg_string() if to_std else reader.std_string()
            writer.lua_string(s, is_pubg=(not to_std))
        else: raise ValueError(f"Unknown constant type 0x{ty:02X}")
    nups = reader.uint32(); writer.uint32(nups)
    for _ in range(nups): writer.byte(reader.byte()); writer.byte(reader.byte())
    npts = reader.uint32(); writer.uint32(npts)
    for _ in range(npts): _convert_function(reader, writer, to_std)
    nln = reader.uint32()
    if to_std:
        lines = []; cur = linedefined
        for _ in range(nln):
            d = reader.byte()
            cur += d if d <= 127 else d - 256
            lines.append(cur)
        writer.uint32(len(lines))
        for ln in lines: writer.int32(ln)
        nab = reader.uint32()
        for _ in range(nab): reader.uint32(); reader.uint32()
    else:
        lines = [reader.int32() for _ in range(nln)]
        writer.uint32(len(lines))
        prev = linedefined
        for ln in lines:
            delta = ln - prev
            if -128 <= delta <= 127: writer.byte(delta & 0xFF)
            else: writer.byte(0x00); writer.int32(delta)
            prev = ln
        writer.uint32(0)
    nloc = reader.uint32(); writer.uint32(nloc)
    for _ in range(nloc):
        s = reader.pubg_string() if to_std else reader.std_string()
        writer.lua_string(s, is_pubg=(not to_std))
        writer.int32(reader.int32()); writer.int32(reader.int32())
    nupn = reader.uint32(); writer.uint32(nupn)
    for _ in range(nupn):
        s = reader.pubg_string() if to_std else reader.std_string()
        writer.lua_string(s, is_pubg=(not to_std))

def bgmi_to_std(data: bytes) -> bytes:
    if data[:4] != b'\x1bLua': raise ValueError("Not a valid Lua bytecode file")
    reader = BinaryReader(data, sizet=4); writer = BinaryWriter()
    hdr = bytearray(data[:HEADER_SIZE]); hdr[13] = 4
    writer.raw(hdr); reader.pos = HEADER_SIZE
    nibble_flag = reader.byte(); writer.byte(nibble_flag)
    _convert_function(reader, writer, to_std=True)
    return writer.get_data()

def std_to_bgmi(data: bytes) -> bytes:
    if data[:4] != b'\x1bLua': raise ValueError("Not a valid Lua bytecode file")
    sizet = data[13] if data[13] in (4, 8) else 4
    reader = BinaryReader(data, sizet=sizet); writer = BinaryWriter()
    hdr = bytearray(data[:HEADER_SIZE]); hdr[13] = 4
    writer.raw(hdr); reader.pos = HEADER_SIZE
    nibble_flag = reader.byte(); writer.byte(nibble_flag)
    _convert_function(reader, writer, to_std=False)
    return writer.get_data()

def convert_file(inp: str, outp: str = None) -> Tuple[bool, str]:
    if not outp: outp = os.path.splitext(inp)[0] + '.std.luac'
    try:
        with open(inp, 'rb') as f: data = f.read()
    except Exception as e: return False, f"Cannot read input file: {e}"
    if len(data) < 34 or data[:4] != b'\x1bLua':
        try: shutil.copy2(inp, outp); return True, outp
        except: return False, "Failed to copy non-Lua file"
    nibble_flag = data[33]
    if nibble_flag > 2: nibble_flag = 0; data = bytearray(data); data[33] = 0; data = bytes(data)
    if nibble_flag > 1:
        fixed = bytearray(data[:34])
        for i in range(34, len(data)):
            b = data[i]; fixed.append(((b << 4) & 0xF0) | ((b >> 4) & 0x0F))
        data = bytes(fixed)
    try:
        std_data = bgmi_to_std(data)
        with open(outp, 'wb') as f: f.write(std_data)
        return True, outp
    except Exception:
        try: shutil.copy2(inp, outp); return True, outp
        except: return False, "Conversion failed"

def repack_to_pubg(std_luac_path: str, original_pubg_path: str, outp: str = None, pad_to_size: int = None) -> Tuple[bool, str]:
    if not outp: outp = os.path.splitext(std_luac_path)[0] + '.pubg.luac'
    try:
        with open(original_pubg_path, 'rb') as f: orig_data = f.read()
    except Exception as e: return False, f"Cannot read original: {e}"
    if len(orig_data) < 34 or orig_data[:4] != b'\x1bLua': return False, "Original not valid Lua bytecode"
    header = orig_data[:33]; nibble_flag = orig_data[33]
    if nibble_flag > 2: nibble_flag = 0
    try:
        with open(std_luac_path, 'rb') as f: std_data = f.read()
    except Exception as e: return False, f"Cannot read std luac: {e}"
    try:
        bgmi_data = std_to_bgmi(std_data)
        bgmi_data = header + bytes([nibble_flag]) + bgmi_data[34:]
        if nibble_flag > 1:
            data_list = bytearray(bgmi_data[:34])
            for i in range(34, len(bgmi_data)):
                b = bgmi_data[i]; data_list.append(((b << 4) & 0xF0) | ((b >> 4) & 0x0F))
            bgmi_data = bytes(data_list)
        if pad_to_size is not None and len(bgmi_data) < pad_to_size:
            bgmi_data += b'\x00' * (pad_to_size - len(bgmi_data))
        with open(outp, 'wb') as f: f.write(bgmi_data)
        return True, outp
    except Exception as e: return False, f"Repack failed: {e}"

UNLUAC_JAR_PATH = SOURCE_DIR / "unluac_patched.jar"
UNLUAC_JAR = str(UNLUAC_JAR_PATH)
JAVA_CMD = "java"
BUNDLED_JDK_CANDIDATES = list(SOURCE_DIR.glob("jdk*/bin/java.exe")) + list(SOURCE_DIR.glob("jdk*/bin/java"))
if BUNDLED_JDK_CANDIDATES: JAVA_CMD = str(BUNDLED_JDK_CANDIDATES[0])

def get_luac_cmd() -> str:
    for name in ["luac5.3", "luac53", "luac5.3.exe", "luac53.exe"]:
        p = SOURCE_DIR / name
        if p.exists(): return str(p)
    for name in ["luac5.3", "luac53.exe"]:
        w = shutil.which(name)
        if w: return w
    return "luac5.3"

LUAC_PATH = get_luac_cmd()
STRIP_DEBUG = True

def decrypt_decompile_file(file_path: str, output_dir: str, progress_callback=None) -> bool:
    try:
        filename = os.path.basename(file_path)
        base_name = os.path.splitext(filename)[0]
        if base_name.lower().endswith('.lua'): base_name = os.path.splitext(base_name)[0]
        output_file = os.path.join(output_dir, base_name + ".lua")
        temp_std = file_path + ".temp.std.luac"
        if progress_callback: progress_callback(t('converting', name=filename))
        success, msg = convert_file(file_path, temp_std)
        if not success:
            if progress_callback: progress_callback(f"{t('failed_label')} {msg}")
            shutil.copy2(file_path, os.path.join(output_dir, base_name + ".luac"))
            return False
        if not os.path.exists(UNLUAC_JAR):
            if progress_callback: progress_callback("unluac.jar missing, saving raw bytecode")
            shutil.copy2(temp_std, os.path.join(output_dir, base_name + ".luac"))
            os.remove(temp_std); return False
        try:
            cmd = [JAVA_CMD, "-jar", UNLUAC_JAR, temp_std]
            with open(output_file, "w", encoding="utf-8") as out:
                subprocess.check_call(cmd, stdout=out, stderr=subprocess.PIPE, timeout=30)
            if progress_callback: progress_callback(f"{t('decompiled')} {filename}")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
            if progress_callback: progress_callback(f"{t('failed_label')} {e}")
            shutil.copy2(temp_std, os.path.join(output_dir, base_name + ".luac"))
            return False
        finally:
            if os.path.exists(temp_std): os.remove(temp_std)
        return True
    except Exception as e:
        if progress_callback: progress_callback(f"{t('error_label', err=e)}")
        return False

def robust_decompile(encrypted_path: str, output_dir: str, tmp_dir: str) -> Tuple[bool, str, List[str]]:
    name = os.path.basename(encrypted_path); base = os.path.splitext(name)[0]
    out_path = os.path.join(output_dir, base + ".lua")
    temp_std = os.path.join(tmp_dir, base + ".std.luac")
    ok, msg = convert_file(encrypted_path, temp_std)
    if not ok: return False, msg, []
    if not os.path.exists(UNLUAC_JAR): return False, "unluac_patched.jar not found", []
    try:
        cmd = [JAVA_CMD, "-jar", UNLUAC_JAR, temp_std]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode == 0 and result.stdout:
            with open(out_path, 'w', encoding='utf-8') as f: f.write(result.stdout)
            return True, out_path, []
        else: return False, f"Decompilation failed: {(result.stderr or 'unknown error').strip()[:200]}", []
    except subprocess.TimeoutExpired: return False, "Decompilation timed out", []
    except Exception as e: return False, str(e), []

def select_files_interactive(files: List[str], source_dir: str, action_name: str) -> List[str]:
    if not files: return []
    if len(files) == 1:
        console.print(f"[{ICE}]{t('only_1_file')}[/{ICE}] [bold {GOLD}]{files[0]}[/bold {GOLD}]  [dim]· {CREDIT}[/dim]")
        confirm = hexa_prompt(t('process_this_file')).strip().lower()
        return files if confirm != 'n' else []
    console.print()
    console.print(Rule(f"[bold {GOLD}]◈ {t('select_files_title', action=action_name)} ◈[/bold {GOLD}]", style=GOLD))
    console.print()
    tbl = Table(box=ROUNDED, border_style=ICE, show_header=True, padding=(0, 1))
    tbl.add_column(t('col_num'), justify="right", style=f"bold {GOLD}", width=4)
    tbl.add_column(t('col_file'), style=f"bold {NEON}")
    tbl.add_column(t('col_size'), justify="right", style=MUTED)
    for idx, f in enumerate(files, 1):
        sz = os.path.getsize(os.path.join(source_dir, f))
        tbl.add_row(f"[{idx}]", f, human_size(sz))
    console.print(tbl)
    console.print(f"  [bold {GOLD}][A][/bold {GOLD}] [white]{t('all_files')}[/white]")
    console.print(f"  [bold {ERR}][0][/bold {ERR}] [white]{t('cancel')}[/white]")
    console.print()
    while True:
        choice = hexa_prompt(t('your_choice')).strip().upper()
        if choice == 'A': return files
        if choice == '0': return []
        if choice.isdigit():
            idx = int(choice)
            if 1 <= idx <= len(files): return [files[idx-1]]
        hexa_alert(t('invalid_selection'), "error")

def action_unpack():
    files = get_real_files()
    if not files: hexa_alert(t('lua_orig_empty'), "error"); safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]'); return
    selected = select_files_interactive(files, str(REAL_DIR), t('decompile').upper())
    if not selected: return
    success = 0
    console.print()
    with tempfile.TemporaryDirectory(prefix='bgmi_dec_') as tmp_dir:
        with Progress(
            SpinnerColumn(style=NEON),
            TextColumn(f"[bold {ICE}]{{task.description}}[/bold {ICE}]"),
            BarColumn(style=GOLD, complete_style=SUCCESS),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            task = progress.add_task(t('decompiling'), total=len(selected))
            for idx, f in enumerate(selected, 1):
                progress.update(task, description=f"[{idx}/{len(selected)}] {f[:30]}")
                inp = REAL_DIR / f
                ok, result, _ = robust_decompile(str(inp), str(UNPACK_DIR), tmp_dir)
                if ok:
                    progress.console.print(f"  [{SUCCESS}]◆[/{SUCCESS}] {t('decompiled')} [bold {GOLD}]{os.path.basename(result)}[/bold {GOLD}]")
                    success += 1
                else:
                    progress.console.print(f"  [{ERR}]◆[/{ERR}] {t('failed_label')} {result}")
                    fallback_path = UNPACK_DIR / (os.path.splitext(f)[0] + ".luac")
                    ok2, _ = convert_file(str(inp), str(fallback_path))
                    if ok2: progress.console.print(f"  [{WARN}]◆[/{WARN}] {t('saved_raw')} {fallback_path.name}")
                progress.update(task, advance=1)
    hexa_alert(t('unpack_complete', success=success, total=len(selected)), "success")
    safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')

def recompile_lua_files(selected: List[str], quiet: bool = False) -> Tuple[int, List[str]]:
    success = 0; failed = []
    with Progress(
        SpinnerColumn(style=NEON),
        TextColumn(f"[bold {ICE}]{{task.description}}[/bold {ICE}]"),
        BarColumn(style=GOLD, complete_style=SUCCESS),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console
    ) as progress:
        task = progress.add_task(t('compiling'), total=len(selected))
        for idx, f in enumerate(selected, 1):
            name = os.path.splitext(f)[0]
            inp = UNPACK_DIR / f
            out = EDIT_DIR / (name + ".lua")
            progress.update(task, description=f"[{idx}/{len(selected)}] {f[:30]}")

            temp_std = str(LUA_PAK_ROOT / f"{name}_temp_std.luac")
            cmd = [LUAC_PATH, "-s", "-o", temp_std, str(inp)] if STRIP_DEBUG else [LUAC_PATH, "-o", temp_std, str(inp)]
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            except subprocess.TimeoutExpired:
                progress.console.print(f"  [{ERR}]◆[/{ERR}] {t('compilation_timeout')} {f}")
                failed.append(f)
                progress.update(task, advance=1)
                continue

            if res.returncode == 0 and os.path.exists(temp_std):
                orig = None
                for ext in ['.luac', '.slua', '.lua']:
                    p = REAL_DIR / (name + ext)
                    if p.exists():
                        orig = str(p)
                        break
                if not orig:
                    progress.console.print(f"  [{ERR}]◆[/{ERR}] {t('original_not_found')} {f}")
                    failed.append(f)
                else:
                    ok2, msg = repack_to_pubg(temp_std, orig, str(out), pad_to_size=os.path.getsize(orig))
                    if ok2:
                        progress.console.print(f"  [{SUCCESS}]◆[/{SUCCESS}] {t('compiled')} [bold {GOLD}]{out.name}[/bold {GOLD}] ({human_size(out.stat().st_size)})")
                        success += 1
                    else:
                        progress.console.print(f"  [{ERR}]◆[/{ERR}] {t('recompile_failed')} {msg}")
                        failed.append(f)
                if os.path.exists(temp_std):
                    os.remove(temp_std)
            else:
                progress.console.print(f"  [{ERR}]◆[/{ERR}] {t('compilation_failed')} {f}")
                failed.append(f)
            progress.update(task, advance=1)
    return success, failed

def action_repack_unpack():
    files = get_unpack_files()
    if not files: hexa_alert(t('lua_edit_empty'), "error"); safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]'); return
    selected = select_files_interactive(files, str(UNPACK_DIR), t('repack').upper())
    if not selected: return

    if FORCE_COMPILE and SKIP_ALL_FIXES:
        console.print()
        console.print(Panel(
            f"[bold {NEON}]{t('fast_compile')}[/bold {NEON}]\n"
            f"[white]{t('launching_compile')}[/white]\n"
            f"[dim]{t('credit_field')} : {CREDIT}[/dim]",
            border_style=GOLD, box=HEAVY, padding=(1, 2)
        ))
    success, failed = recompile_lua_files(selected)
    hexa_alert(t('repack_complete', success=success, total=len(selected)), "success")
    if failed: hexa_alert(f"{t('failed_label')} {', '.join(failed)}", "error")
    safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')

ZUC_KEY = bytes.fromhex('01010101010101010101010101010101')
ZUC_IV = bytes.fromhex('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')

RSA_MOD_1 = bytes.fromhex('CBE8B9F2504050EF9831B719E9A6249A6D238505ADE909BDE78C180DED6072A0C3347B8AF4780E1F212D952D82D4BF7F233C1ECA499E1F9D9A85B4FAD759F54BABC1666C5DE411EA9E4B2374425DD6C6F54333BBC8F2610FE6063E4D0D6C21A671A8F7C3740555E5DC06D4E1691C456DB4116C0C012BF7B206E8311AAAEC689952BF804EF638F09D5822B4117B114208F14DEB459E80CB770E5B0D7978E21F5E6CED4999D3583108221A7AB28B960277ADB5690A332784019D9C195BE4EA9EA0A09459010F236465DE0D59C3EF7324E954E1118D93EE19F299760C2CDB963CE87973EA5ECC9BBE81C27D4C7C8572AC07E9BCEAC9BD72AB7A56A3C0AD736ABCE4')
RSA_MOD_2 = bytes.fromhex('7F58E8A39A4DA4E87357DDD650EAA16D3B5CE95B213D1030A662566444796A78A84AE9AC3DBFFDE7F41094896696835DAF13B89E6EC2B84963B1B1BAF7151DA245C3FBFAE2A6AE18B2684D03F9229DE2C91440F2A3A3BCDE1E5680C16722A88039C73560D5D43F4B6562C2EEA5B1D926D86B51108A2643C70FB74D6442CE3A08339B8FD8F660AE88129B7AB8C46F2FA58124485CCCB1E987B05A6DA65A01858ED3F89905449AE42BB07290FCB9994BF22E26610BCABB9804783A3B9587917F3D97316EDDA15C5E13F79066407B55A93B291B68A4AC42A98D6E35FED84B14A792D154E62028DDAD20FC301951E5924BE9AD62FB719DD94CC30CAB871BEC4377A8')

SIMPLE1_DECRYPT_KEY = 121
SIMPLE2_DECRYPT_KEY = bytes.fromhex('E55B4ED1')
SIMPLE2_BLOCK_SIZE = 16

SM4_SECRET_4 = 'eb691efea914241317a8'
SM4_SECRET_2 = 'Q0hVTKey$as*1ZFlQCiA'
SM4_SECRET_NEW = [
    "xG2qW5lP7lV2iN5fN5pG", "xT1cJ6dL5wC0kK1rB4dK", "qC4jS5bZ6fL5xE6nD4zA",
    "gD4jQ2aL3bS3lC3xT0iW", "xU1yQ8wE9zY3gZ3bT5aE", "uQ3cO2dX7xY4xU7gH7iS",
    "gW1fR0jK6wQ4oN0oK1kZ", "aJ4pV7iZ7pU4wP2aC2cZ", "cX6jT3cM2oT3vK0kJ1qN",
    "iT2vS0cS6yT6cZ1sE1lO", "hM1pH9iY8wM9hT4lN5uJ", "kG6bC8jK0fL0dE4sH4mL",
    "dB6lB3vE0eZ8wM8rI0aC", "tP7sP7nI9rA2vQ4cV5yQ", "aT0cL1yN4pT3sZ7eM2vY",
    "uV6fU8fC9zN3mP5dH8mN", "rT6aQ6oZ1yM0gO5tO1aN", "jU5bH7lQ0fM9hK2kI0o",
    "iQ0eM0mJ7uT0kV6kL5pY"
]

EM_SIMPLE1 = 1
EM_SIMPLE2 = 16
EM_SM4_2 = 2
EM_SM4_4 = 4
EM_SM4_NEW_BASE = 31
EM_SM4_NEW_MASK = ~EM_SM4_NEW_BASE

CM_NONE = 0
CM_ZLIB = 1
CM_ZSTD = 6
CM_ZSTD_DICT = 8
CM_MASK = 15

class SM4:
    _S_BOX = bytes([
        52, 102, 37, 116, 137, 120, 228, 169, 90, 65, 188, 122, 214, 22, 33, 35,
        77, 97, 218, 148, 155, 223, 19, 60, 105, 58, 49, 10, 95, 215, 153, 149,
        241, 174, 114, 61, 7, 96, 36, 182, 152, 238, 196, 162, 45, 136, 221, 141,
        4, 234, 187, 17, 202, 62, 93, 161, 246, 63, 176, 151, 128, 71, 43, 166,
        230, 247, 217, 177, 89, 192, 124, 190, 84, 40, 183, 126, 79, 248, 67, 110,
        160, 80, 14, 245, 144, 184, 251, 163, 123, 98, 25, 70, 3, 42, 185, 143,
        159, 119, 180, 91, 131, 135, 8, 235, 226, 30, 66, 240, 15, 232, 113, 106,
        117, 173, 85, 31, 181, 171, 51, 250, 127, 21, 189, 133, 216, 6, 104, 179,
        82, 48, 72, 11, 0, 237, 239, 178, 87, 142, 231, 108, 213, 229, 46, 83,
        130, 5, 249, 129, 244, 86, 191, 140, 75, 227, 219, 74, 145, 76, 44, 211,
        64, 41, 78, 32, 20, 54, 121, 9, 111, 209, 55, 224, 57, 12, 138, 146,
        56, 18, 53, 109, 225, 253, 147, 154, 23, 212, 201, 156, 107, 132, 38, 157,
        175, 118, 193, 158, 208, 150, 197, 203, 233, 115, 73, 210, 205, 100, 195, 199,
        1, 125, 243, 172, 252, 222, 164, 68, 50, 27, 194, 186, 28, 2, 198, 39,
        69, 139, 242, 24, 167, 16, 81, 29, 200, 207, 99, 255, 47, 13, 88, 206,
        101, 165, 220, 26, 59, 134, 254, 34, 92, 168, 94, 103, 170, 236, 112, 204
    ])
    _FK = [1184304796, 1270900830, 1493524870, 3164752158]
    _CK = [964907, 973793155, 2654690407, 2916866751, 2071233739, 1226140771, 3348805095, 2045549823, 388349611, 800627875, 612403927, 3721562911, 1195432523, 3150178931, 612053223, 2445162591, 67183755, 1174197155, 1393249511, 3331183455, 3822152747, 1332317203, 1804781383, 1990130463, 1282653851, 3376591251, 2910902311, 925872959, 332098219, 735840931, 396665415, 3588844719]

    @staticmethod
    def ROL32(x, n):
        return (x << n) & 0xFFFFFFFF | (x >> (32 - n))

    @staticmethod
    def _BS(X):
        return (SM4._S_BOX[X >> 24 & 255] << 24 |
                SM4._S_BOX[X >> 16 & 255] << 16 |
                SM4._S_BOX[X >> 8 & 255] << 8 |
                SM4._S_BOX[X & 255])

    @staticmethod
    def _T0(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 2) ^ SM4.ROL32(X, 10) ^ SM4.ROL32(X, 18) ^ SM4.ROL32(X, 24)

    @staticmethod
    def _T1(X):
        X = SM4._BS(X)
        return X ^ SM4.ROL32(X, 13) ^ SM4.ROL32(X, 23)

    @staticmethod
    def _key_expand(key: bytes, rkey: list):
        K0 = int.from_bytes(key[0:4], 'big') ^ SM4._FK[0]
        K1 = int.from_bytes(key[4:8], 'big') ^ SM4._FK[1]
        K2 = int.from_bytes(key[8:12], 'big') ^ SM4._FK[2]
        K3 = int.from_bytes(key[12:16], 'big') ^ SM4._FK[3]
        for i in range(0, 32, 4):
            K0 = K0 ^ SM4._T1(K1 ^ K2 ^ K3 ^ SM4._CK[i])
            rkey[i] = K0
            K1 = K1 ^ SM4._T1(K2 ^ K3 ^ K0 ^ SM4._CK[i + 1])
            rkey[i + 1] = K1
            K2 = K2 ^ SM4._T1(K3 ^ K0 ^ K1 ^ SM4._CK[i + 2])
            rkey[i + 2] = K2
            K3 = K3 ^ SM4._T1(K0 ^ K1 ^ K2 ^ SM4._CK[i + 3])
            rkey[i + 3] = K3

    @classmethod
    def key_length(cls):
        return 16

    @classmethod
    def block_length(cls):
        return 16

    def __init__(self, key: bytes):
        if len(key) != self.key_length():
            raise ValueError(f'Key must be {self.key_length()} bytes')
        else:
            self._key = key
            self._rkey = [0] * 32
            SM4._key_expand(self._key, self._rkey)
            self._block_buffer = bytearray()

    def encrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[i + 1])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[i + 2])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[i + 3])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)

    def decrypt(self, block: bytes) -> bytes:
        if len(block) != self.block_length():
            raise ValueError(f'Block must be {self.block_length()} bytes')
        else:
            RK = self._rkey
            X0 = int.from_bytes(block[0:4], 'big')
            X1 = int.from_bytes(block[4:8], 'big')
            X2 = int.from_bytes(block[8:12], 'big')
            X3 = int.from_bytes(block[12:16], 'big')
            for i in range(0, 32, 4):
                X0 = X0 ^ SM4._T0(X1 ^ X2 ^ X3 ^ RK[31 - i])
                X1 = X1 ^ SM4._T0(X2 ^ X3 ^ X0 ^ RK[30 - i])
                X2 = X2 ^ SM4._T0(X3 ^ X0 ^ X1 ^ RK[29 - i])
                X3 = X3 ^ SM4._T0(X0 ^ X1 ^ X2 ^ RK[28 - i])
            BUFFER = self._block_buffer
            BUFFER.clear()
            BUFFER.extend(X3.to_bytes(4, 'big'))
            BUFFER.extend(X2.to_bytes(4, 'big'))
            BUFFER.extend(X1.to_bytes(4, 'big'))
            BUFFER.extend(X0.to_bytes(4, 'big'))
            return bytes(BUFFER)

class Misc:
    @staticmethod
    def pad_to_n(data: bytes, n: int) -> bytes:
        assert n > 0
        padding = n - len(data) % n
        if padding == n:
            return data
        else:
            return data + b'\x00' * padding

    @staticmethod
    def align_up(x: int, n: int) -> int:
        return (x + n - 1) // n * n

class Reader:
    def __init__(self, buffer, cursor=0):
        self._buffer = buffer
        self._cursor = cursor
    def u1(self, move_cursor=True) -> int:
        return self.unpack('B', move_cursor=move_cursor)[0]
    def u4(self, move_cursor=True) -> int:
        return self.unpack('<I', move_cursor=move_cursor)[0]
    def u8(self, move_cursor=True) -> int:
        return self.unpack('<Q', move_cursor=move_cursor)[0]
    def i1(self, move_cursor=True) -> int:
        return self.unpack('b', move_cursor=move_cursor)[0]
    def i4(self, move_cursor=True) -> int:
        return self.unpack('<i', move_cursor=move_cursor)[0]
    def i8(self, move_cursor=True) -> int:
        return self.unpack('<q', move_cursor=move_cursor)[0]
    def s(self, n: int, move_cursor=True) -> bytes:
        return self.unpack(f'{n}s', move_cursor=move_cursor)[0]
    def unpack(self, f: str, offset=0, move_cursor=True):
        x = struct.unpack_from(f, self._buffer, self._cursor + offset)
        if move_cursor:
            self._cursor += struct.calcsize(f)
        return x
    def string(self, move_cursor=True) -> str:
        length = self.i4(move_cursor=move_cursor)
        if length == 0:
            return str()
        else:
            assert length > 0
            offset = 0 if move_cursor else 4
            raw = self.unpack(f'{length}s', offset=offset, move_cursor=move_cursor)[0].rstrip(b'\x00')
            return raw.replace(b'\x00', b'').decode('utf-8', errors='replace')

class PakInfo:
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_index_encrypted(x: int) -> int:
            MASK_8 = 255
            return (x ^ keystream[3]) & MASK_8
        def decrypt_magic(x: int) -> int:
            return x ^ keystream[2]
        def decrypt_index_hash(x: bytes) -> bytes:
            key = struct.pack('<5I', *keystream[4:][:5])
            assert len(x) == len(key)
            return bytes((a ^ b for a, b in zip(x, key)))
        def decrypt_index_size(x: int) -> int:
            return x ^ (keystream[10] << 32 | keystream[11])
        def decrypt_index_offset(x: int) -> int:
            return x ^ (keystream[0] << 32 | keystream[1])
        reader = Reader(buffer[-PakInfo._mem_size((-1)):])
        self.index_encrypted = decrypt_index_encrypted(reader.u1()) == 1
        self.magic = decrypt_magic(reader.u4())
        self.version = reader.u4()
        self.index_hash = decrypt_index_hash(reader.s(20)) if self.version >= 6 else bytes()
        self.index_size = decrypt_index_size(reader.u8())
        self.index_offset = decrypt_index_offset(reader.u8())
        if self.version <= 3:
            self.index_encrypted = False
    @staticmethod
    def _mem_size(_: int) -> int:
        return 45

class TencentPakInfo(PakInfo):
    def __init__(self, buffer, keystream: List[int]):
        def decrypt_unk(x: bytes) -> bytes:
            key = struct.pack('<8I', *keystream[7:][:8])
            assert len(x) == len(key)
            return bytes((a ^ b for a, b in zip(x, key)))
        def decrypt_stem_hash(x: int) -> int:
            return x ^ keystream[8]
        def decrypt_unk_hash(x: int) -> int:
            return x ^ keystream[9]
        super().__init__(buffer, keystream)
        reader = Reader(buffer[-TencentPakInfo._mem_size(self.version):])
        self.unk1 = decrypt_unk(reader.s(32)) if self.version >= 7 else bytes()
        self.packed_key = reader.s(256) if self.version >= 8 else bytes()
        self.packed_iv = reader.s(256) if self.version >= 8 else bytes()
        self.packed_index_hash = reader.s(256) if self.version >= 8 else bytes()
        self.stem_hash = decrypt_stem_hash(reader.u4()) if self.version >= 9 else 0
        self.unk2 = decrypt_unk_hash(reader.u4()) if self.version >= 9 else 0
        self.content_org_hash = reader.s(20) if self.version >= 12 else bytes()
    @staticmethod
    def _mem_size(version: int) -> int:
        size_for_7 = 32 if version >= 7 else 0
        size_for_8 = 768 if version >= 8 else 0
        size_for_9 = 8 if version >= 9 else 0
        size_for_12 = 20 if version >= 12 else 0
        return PakInfo._mem_size(version) + size_for_7 + size_for_8 + size_for_9 + size_for_12

class PakCompressedBlock:
    def __init__(self, reader: Reader):
        self.start = reader.u8()
        self.end = reader.u8()

@dataclass
class TencentPakEntry:
    def __init__(self, reader: Reader, version: int):
        self.content_hash = reader.s(20)
        if version <= 1:
            _ = reader.u8()
        self.offset = reader.u8()
        self.uncompressed_size = reader.u8()
        self.compression_method = reader.u4() & CM_MASK
        self.size = reader.u8()
        self.unk1 = reader.u1() if version >= 5 else 0
        self.unk2 = reader.s(20) if version >= 5 else bytes()
        if self.compression_method != 0 and version >= 3:
            self.compressed_blocks = [PakCompressedBlock(reader) for _ in range(reader.u4())]
        else:
            self.compressed_blocks = []
        self.compression_block_size = reader.u4() if version >= 4 else 0
        self.encrypted = reader.u1() == 1 if version >= 4 else False
        self.encryption_method = reader.u4() if version >= 12 else 0
        self.index_new_sep = reader.u4() if version >= 12 else 0

class PakCrypto:
    class _LCG:
        def __init__(self, seed: int):
            self.state = seed
        def next(self) -> int:
            MASK_32 = 4294967295
            MSB_1 = 2147483648
            def wrap(x: int) -> int:
                x &= MASK_32
                if not x & MSB_1:
                    return x
                else:
                    return (x + MSB_1 & MASK_32) - MSB_1
            x1 = wrap(1103515245 * self.state)
            self.state = wrap(x1 + 12345)
            x2 = wrap(x1 + 77880) if self.state < 0 else self.state
            return (x2 >> 16 & MASK_32) % 32767
    @staticmethod
    def zuc_keystream() -> List[int]:
        try:
            zuc = gmalg.ZUC(ZUC_KEY, ZUC_IV)
            return [struct.unpack('>I', zuc.generate())[0] for _ in range(16)]
        except:
            return [0x9E3779B9, 0x3C6EF372, 0xDA7A5E2B, 0x7895C8E4, 0x16B1339D, 0xB4CC9E56, 0x52E8090F, 0xF10373C8, 0x8F1EDE81, 0x2D3A493A, 0xCB55B3F3, 0x69711EAC, 0x078C8965, 0xA5A7F41E, 0x43C35ED7, 0xE1DEC990]
    @staticmethod
    def _xorxor(buffer, x) -> bytes:
        return bytes((buffer[i] ^ x[i % len(x)] for i in range(len(buffer))))
    @staticmethod
    def _hashhash(buffer, n: int) -> bytes:
        result = bytes()
        for _ in range(math.ceil(n / SHA1.digest_size)):
            result += SHA1.new(buffer).digest()
        if len(result) >= n:
            result = result[:n]
            return result
        else:
            result += b'\x00' * (n - len(result))
            return result
    @staticmethod
    def _meowmeow(buffer) -> bytes:
        def unpad(x):
            skip = 1 + next((i for i in range(len(x)) if x[i]!= 0))
            return x[skip:]
        if len(buffer) < 43:
            return bytes()
        else:
            x1 = buffer[1:][:SHA1.digest_size]
            x2 = buffer[SHA1.digest_size + 1:]
            x1 = PakCrypto._xorxor(x1, PakCrypto._hashhash(x2, len(x1)))
            x2 = PakCrypto._xorxor(x2, PakCrypto._hashhash(x1, len(x2)))
            part1, m = (x2[:SHA1.digest_size], x2[SHA1.digest_size:])
            if part1!= SHA1.new(b'\x00' * SHA1.digest_size).digest():
                return bytes()
            else:
                return unpad(m)
    @staticmethod
    def rsa_extract(signature: bytes, modulus: bytes) -> bytes:
        c = int.from_bytes(signature, 'little')
        n = int.from_bytes(modulus, 'little')
        e = 65537
        m = pow(c, e, n).to_bytes(256, 'little').rstrip(b'\x00')
        return PakCrypto._meowmeow(Misc.pad_to_n(m, 4))
    @staticmethod
    def _decrypt_simple1(ciphertext) -> bytes:
        return bytes((x ^ SIMPLE1_DECRYPT_KEY for x in ciphertext))
    @staticmethod
    def _decrypt_simple2(ciphertext) -> bytes:
        class RollingKey:
            def __init__(self, initial_value: int):
                self._value = initial_value
            def update(self, x: int) -> int:
                self._value ^= x
                return self._value
        assert len(ciphertext) % SIMPLE2_BLOCK_SIZE == 0
        initial_key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
        rolling_key = RollingKey(initial_key)
        plaintext = (struct.pack('<I', rolling_key.update(x)) for x in struct.unpack(f'<{len(ciphertext) // 4}I', ciphertext))
        return bytes(it.chain.from_iterable(plaintext))
    @staticmethod
    @lru_cache(maxsize=1)
    def _derive_sm4_key(file_path: PurePath, encryption_method: int) -> bytes:
        part1 = file_path.stem.lower()
        if encryption_method == EM_SM4_2:
            secret = SM4_SECRET_2
        else:
            if encryption_method == EM_SM4_4:
                secret = SM4_SECRET_4
            else:
                index = (encryption_method - EM_SM4_NEW_BASE) % len(SM4_SECRET_NEW)
                secret = f'{SM4_SECRET_NEW[index]}{encryption_method}'
        return SHA1.new(str(part1 + secret).encode()).digest()[:SM4.key_length()]
    @staticmethod
    @lru_cache(maxsize=1)
    def _sm4_context_for_key(key: bytes) -> SM4:
        return SM4(key)
    @staticmethod
    def _decrypt_sm4(ciphertext, file_path: PurePath, encryption_method: int) -> bytes:
        assert len(ciphertext) % SM4.block_length() == 0
        key = PakCrypto._derive_sm4_key(file_path, encryption_method)
        sm4 = PakCrypto._sm4_context_for_key(key)
        return bytes(it.chain.from_iterable((sm4.decrypt(x) for x in it.batched(ciphertext, SM4.block_length()))))
    @staticmethod
    def decrypt_index(ciphertext, pak_info: TencentPakInfo) -> bytes:
        ciphertext = bytes(ciphertext)  # ensure bytes, not memoryview
        if not ciphertext:
            return ciphertext
        if pak_info.version > 7:
            try:
                key = PakCrypto.rsa_extract(pak_info.packed_key, RSA_MOD_1)
                iv = PakCrypto.rsa_extract(pak_info.packed_iv, RSA_MOD_1)
                if key and iv and len(key) == 32 and len(iv) >= 16:
                    aes = AES.new(key, MODE_CBC, iv[:16])
                    decrypted = aes.decrypt(ciphertext)
                    try:
                        result = unpad(decrypted, AES.block_size)
                        if result:
                            return result
                    except ValueError:
                        if decrypted:
                            return decrypted
            except Exception:
                pass
            ks_bytes = struct.pack('<5I', *PakCrypto.zuc_keystream()[4:][:5])
            if len(ciphertext) < len(ks_bytes):
                ks_bytes = ks_bytes[:len(ciphertext)]
            else:
                ks_bytes = (ks_bytes * (len(ciphertext) // len(ks_bytes) + 1))[:len(ciphertext)]
            result = bytes(a ^ b for a, b in zip(ciphertext, ks_bytes))
            return result if result else ciphertext
        else:
            return bytes(PakCrypto._decrypt_simple1(ciphertext))
    @staticmethod
    def _is_simple1_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE1
    @staticmethod
    def _is_simple2_method(encryption_method: int) -> bool:
        return encryption_method == EM_SIMPLE2 or encryption_method == 17
    @staticmethod
    def _is_sm4_method(encryption_method: int) -> bool:
        return encryption_method == EM_SM4_2 or encryption_method == EM_SM4_4 or encryption_method & EM_SM4_NEW_MASK!= 0
    @staticmethod
    def align_encrypted_content_size(n: int, encryption_method: int) -> int:
        if PakCrypto._is_simple2_method(encryption_method):
            return Misc.align_up(n, SIMPLE2_BLOCK_SIZE)
        else:
            if PakCrypto._is_sm4_method(encryption_method):
                return Misc.align_up(n, SM4.block_length())
            else:
                return n
    @staticmethod
    def decrypt_block(ciphertext, file: PurePath, encryption_method: int) -> bytes:
        if PakCrypto._is_simple1_method(encryption_method):
            return PakCrypto._decrypt_simple1(ciphertext)
        else:
            if PakCrypto._is_simple2_method(encryption_method):
                return PakCrypto._decrypt_simple2(ciphertext)
            else:
                if PakCrypto._is_sm4_method(encryption_method):
                    return PakCrypto._decrypt_sm4(ciphertext, file, encryption_method)
                else:
                    return ciphertext
    @staticmethod
    @lru_cache(maxsize=33)
    def generate_block_indices(n: int, encryption_method: int) -> List[int]:
        if not PakCrypto._is_sm4_method(encryption_method):
            return list(range(n))
        else:
            permutation = []
            lcg = PakCrypto._LCG(n)
            while len(permutation)!= n:
                x = lcg.next() % n
                if x not in permutation:
                    permutation.append(x)
            inverse = [0] * len(permutation)
            for i, x in enumerate(permutation):
                inverse[x] = i
            return inverse

class PakCompression:
    @staticmethod
    @lru_cache(maxsize=33)
    def _zstd_decompressor(dict: ZstdCompressionDict) -> ZstdDecompressor:
        return ZstdDecompressor(dict)
    @staticmethod
    def zstd_dictionary(dict_data) -> ZstdCompressionDict:
        return ZstdCompressionDict(dict_data, DICT_TYPE_AUTO)
    @staticmethod
    def decompress_block(block, dict: Optional[ZstdCompressionDict], compression_method: int) -> bytes:
        if compression_method == CM_ZLIB:
            try:
                return zlib.decompress(block)
            except zlib.error:
                return block
        else:
            if compression_method == CM_ZSTD or compression_method == CM_ZSTD_DICT:
                if compression_method!= CM_ZSTD_DICT:
                    dict = None
                try:
                    return PakCompression._zstd_decompressor(dict).decompress(block)
                except:
                    return block
            else:
                return block

class TencentPakFile:
    def __init__(self, file_path: PurePath, is_od=False):
        self._file_path = file_path
        self._file_handle = open(file_path, 'rb')
        try:
            import mmap
            self._file_mmap = mmap.mmap(self._file_handle.fileno(), 0, access=mmap.ACCESS_READ)
            self._file_content = memoryview(self._file_mmap)
        except:
            self._file_content = memoryview(self._file_handle.read())
            self._file_mmap = None
        self._is_od = is_od
        self._mount_point = PurePath()
        self._is_zstd_with_dict = 'zsdic' in str(self._file_path)
        self._zstd_dict = None
        self._files = []
        self._index = {}
        self._pak_info = TencentPakInfo(self._file_content, PakCrypto.zuc_keystream())
        self._verify_stem_hash()
        self._tencent_load_index()

    def detect_dominant_style(self) -> dict:
        comp_counter = Counter()
        enc_counter = Counter()
        blk_counter = Counter()
        enc_flag_counter = Counter()
        total = len(self._files)
        if total == 0:
            return {'comp_method': CM_ZSTD, 'enc_method': 0, 'encrypted': False, 'block_size': 0x10000}
        for entry in self._files:
            comp_counter[entry.compression_method] += 1
            if entry.encrypted:
                enc_counter[entry.encryption_method] += 1
                enc_flag_counter['encrypted'] += 1
            else:
                enc_flag_counter['plain'] += 1
            if entry.compression_block_size:
                blk_counter[entry.compression_block_size] += 1
        non_none = [(m,c) for m,c in comp_counter.items() if m != CM_NONE]
        comp_method = max(non_none, key=lambda x: x[1])[0] if non_none else CM_NONE
        encrypted = enc_flag_counter.get('encrypted', 0) > enc_flag_counter.get('plain', 0)
        enc_method = enc_counter.most_common(1)[0][0] if encrypted and enc_counter else 0
        block_size = blk_counter.most_common(1)[0][0] if blk_counter else 0x10000
        return {'comp_method': comp_method, 'enc_method': enc_method, 'encrypted': encrypted, 'block_size': block_size}

    def inject_files(self, inject_plan: list, output_pak: Path, add_signature_marker: bool = True) -> None:
        if not inject_plan:
            raise ValueError('inject_plan is empty — nothing to inject')

        console.print()
        console.print(Panel(
            f"[bold {MAGENTA}]◆ {t('inject_engine')} ◆[/bold {MAGENTA}]\n\n"
            f"[white]{t('source_pak')}  :[/white] [{GOLD}]{self._file_path.name}[/{GOLD}]\n"
            f"[white]{t('output_label')}      :[/white] [{ICE}]{output_pak.name}[/{ICE}]\n"
            f"[white]{t('injecting_label')}   :[/white] [{SUCCESS}]{len(inject_plan)} {t('col_file').lower()}(s)[/{SUCCESS}]\n"
            f"[dim]{t('credit_field')}      : {CREDIT}[/dim]",
            title=f"[bold white]★ {t('inject_engine')} ★[/bold white]",
            border_style=MAGENTA, box=HEAVY, padding=(1, 2)
        ))

        console.print()
        console.print(Rule(f"[bold {GOLD}]◈ {t('step_loading')} ◈[/bold {GOLD}]", style=GOLD))
        work_items = []
        for i, item in enumerate(inject_plan):
            if item.get('plain_bytes') is not None:
                plain = item['plain_bytes']
            elif item.get('src_path') is not None:
                try:
                    plain = Path(item['src_path']).read_bytes()
                except Exception as e:
                    console.print(f"   [{ERR}]◆[/{ERR}] {t('cannot_read_file', path=item['src_path'], err=e)}")
                    continue
            else:
                console.print(f"   [{ERR}]◆[/{ERR}] {t('no_src_path', i=i)}")
                continue

            internal = item['internal_path'].replace('\\', '/').lstrip('/')
            if not internal:
                console.print(f"   [{ERR}]◆[/{ERR}] {t('empty_internal', i=i)}")
                continue

            parts = internal.rsplit('/', 1)
            if len(parts) == 2:
                dir_str, file_name = parts[0], parts[1]
            else:
                dir_str, file_name = '', parts[0]

            work_items.append({
                'dir_str':       dir_str,
                'file_name':     file_name,
                'internal_path': internal,
                'plain':         plain,
                'comp_method':   item['comp_method'],
                'enc_method':    item['enc_method'],
                'encrypted':     bool(item['encrypted']),
                'block_size':    item['block_size'],
                'comp_level':    item.get('comp_level', 19),
            })
            console.print(f"   [{SUCCESS}]◆[/{SUCCESS}] {internal} [dim]({human_size(len(plain))})[/dim]")

        if not work_items:
            raise RuntimeError(t('no_valid_inject'))
        console.print(f"[{SUCCESS}]◆ {t('loaded_files', n=len(work_items))}[/{SUCCESS}]")

        console.print()
        console.print(Rule(f"[bold {GOLD}]◈ {t('step_encoding')} ◈[/bold {GOLD}]", style=GOLD))
        keystream = PakCrypto.zuc_keystream()
        version = self._pak_info.version
        header_size = TencentPakInfo._mem_size(version)
        PAK_MAGIC = self._pak_info.magic

        orig_index_offset = self._pak_info.index_offset
        current_new_offset = orig_index_offset
        new_data_region = bytearray()
        new_injected_entries = []

        def _encrypt_plaintext_local(plaintext, pak_relative_path, encryption_method):
            if PakCrypto._is_simple1_method(encryption_method):
                return bytes(b ^ SIMPLE1_DECRYPT_KEY for b in plaintext)
            elif PakCrypto._is_simple2_method(encryption_method):
                pad_len = (-len(plaintext)) % SIMPLE2_BLOCK_SIZE
                plaintext += b"\x00" * pad_len
                key, = struct.unpack("<I", SIMPLE2_DECRYPT_KEY)
                rolling = key
                out = []
                for x, in struct.iter_unpack("<I", plaintext):
                    c = rolling ^ x
                    out.append(c)
                    rolling ^= c
                return struct.pack(f"<{len(out)}I", *out)
            elif PakCrypto._is_sm4_method(encryption_method):
                key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)
                sm4 = PakCrypto._sm4_context_for_key(key)
                pad_len = (-len(plaintext)) % 16
                if pad_len > 0:
                    plaintext = plaintext + b'\x00' * pad_len
                out = bytearray()
                for i in range(0, len(plaintext), 16):
                    block = plaintext[i:i+16]
                    if len(block) < 16:
                        block = block.ljust(16, b'\x00')
                    out.extend(sm4.encrypt(block))
                return bytes(out)
            return plaintext

        for item in work_items:
            plain = item['plain']
            comp_method = item['comp_method']
            enc_method = item['enc_method']
            encrypted = item['encrypted']
            block_size_val = item['block_size']
            file_path_for_crypto = PurePath(item['file_name'])

            if len(plain) == 0:
                new_injected_entries.append({
                    'content_hash': SHA1.new(b'').digest(),
                    'offset': current_new_offset,
                    'uncompressed_size': 0, 'size': 0,
                    'comp_method': CM_NONE, 'enc_method': 0, 'encrypted': False,
                    'block_size_val': 0, 'compressed_blocks': [],
                    'unk1': 0, 'unk2': b'\x00' * 20, 'index_new_sep': 0,
                    '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(),
                    '_file_name': item['file_name'],
                })
                continue

            if comp_method == CM_NONE:
                if encrypted:
                    aligned_size = PakCrypto.align_encrypted_content_size(len(plain), enc_method)
                    padded = plain + b'\x00' * (aligned_size - len(plain))
                    stored_data = _encrypt_plaintext_local(padded, file_path_for_crypto, enc_method)
                else:
                    stored_data = plain
                new_size = len(stored_data)
                new_compressed_blocks = []
            else:
                chunks = [plain[i:i+block_size_val] for i in range(0, len(plain), block_size_val)]
                if not chunks: chunks = [b'']
                compressed_chunks = []
                for chunk in chunks:
                    comp = None
                    if comp_method in (CM_ZSTD, CM_ZSTD_DICT):
                        zstd_dict = self._zstd_dict if comp_method == CM_ZSTD_DICT else None
                        for lvl in range(22, 0, -1):
                            try:
                                c = ZstdCompressor(level=lvl, dict_data=zstd_dict, threads=1)
                                comp = c.compress(chunk)
                                break
                            except: continue
                    elif comp_method == CM_ZLIB:
                        comp = zlib.compress(chunk, level=9)
                    if comp is None: comp = chunk
                    compressed_chunks.append(comp)

                encrypted_chunks = []
                for comp_data in compressed_chunks:
                    if encrypted:
                        comp_data = _encrypt_plaintext_local(comp_data, file_path_for_crypto, enc_method)
                    encrypted_chunks.append(comp_data)

                n_blocks = len(encrypted_chunks)
                indices = PakCrypto.generate_block_indices(n_blocks, enc_method)
                physical_blocks = [None] * n_blocks
                for j, chunk_data in enumerate(encrypted_chunks):
                    physical_blocks[indices[j]] = chunk_data

                physical_offsets = []
                block_cursor = current_new_offset
                for phys_block in physical_blocks:
                    physical_offsets.append((block_cursor, block_cursor + len(phys_block)))
                    block_cursor += len(phys_block)
                new_compressed_blocks = physical_offsets
                stored_data = b''.join(physical_blocks)
                new_size = len(stored_data)
                if encrypted:
                    aligned_total = PakCrypto.align_encrypted_content_size(new_size, enc_method)
                    if aligned_total > new_size:
                        stored_data = stored_data + b'\x00' * (aligned_total - new_size)
                        new_size = aligned_total

            new_content_hash = SHA1.new(stored_data).digest()
            new_data_region.extend(stored_data)

            new_injected_entries.append({
                'content_hash': new_content_hash,
                'offset': current_new_offset,
                'uncompressed_size': len(plain),
                'size': new_size,
                'comp_method': comp_method,
                'enc_method': enc_method if encrypted else 0,
                'encrypted': encrypted,
                'block_size_val': block_size_val,
                'compressed_blocks': new_compressed_blocks,
                'unk1': 0, 'unk2': b'\x00' * 20, 'index_new_sep': 0,
                '_dir_path': PurePath(item['dir_str']) if item['dir_str'] else PurePath(),
                '_file_name': item['file_name'],
            })
            current_new_offset += new_size

        console.print(f"[{SUCCESS}]◆ {t('encoded_files', n=len(new_injected_entries))}[/{SUCCESS}]")

        new_entries = []
        entry_to_path = {}
        for dir_path, files in self._index.items():
            for fname, entry in files.items():
                entry_to_path[id(entry)] = (dir_path, fname)
        for i, entry in enumerate(self._files):
            dir_path, fname = entry_to_path.get(id(entry), (PurePath(), f'unknown_{i}'))
            new_entries.append({
                'content_hash': entry.content_hash,
                'offset': entry.offset,
                'uncompressed_size': entry.uncompressed_size,
                'size': entry.size,
                'comp_method': entry.compression_method,
                'enc_method': entry.encryption_method if entry.encrypted else 0,
                'encrypted': entry.encrypted,
                'block_size_val': entry.compression_block_size,
                'compressed_blocks': [(b.start, b.end) for b in entry.compressed_blocks],
                'unk1': entry.unk1, 'unk2': entry.unk2,
                'index_new_sep': entry.index_new_sep,
            })
        new_entries.extend(new_injected_entries)

        if add_signature_marker:
            marker_already_present = False
            for dp, files_dict in self._index.items():
                if dp.name == 'HR_DHAMA' and 'PATCHED.txt' in files_dict:
                    marker_already_present = True
                    break
            if not marker_already_present:
                empty_hash = SHA1.new(b'').digest()
                new_entries.append({
                    'content_hash': empty_hash,
                    'offset': current_new_offset,
                    'uncompressed_size': 0,
                    'size': 0,
                    'comp_method': CM_NONE,
                    'enc_method': 0,
                    'encrypted': False,
                    'block_size_val': 0,
                    'compressed_blocks': [],
                    'unk1': 0,
                    'unk2': b'\x00' * 20,
                    'index_new_sep': 0,
                    '_dir_path': PurePath('xvaLuexxPUBG'),
                    '_file_name': 'PATCHED.txt',
                })

        index_data = bytearray()
        raw_orig_index = self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size]
        orig_index_decoded = PakCrypto.decrypt_index(bytes(raw_orig_index), self._pak_info)
        orig_reader = Reader(orig_index_decoded)
        orig_mount_len = orig_reader.i4()
        orig_mount_bytes = bytes(orig_reader.s(orig_mount_len))
        index_data.extend(struct.pack('<I', orig_mount_len))
        index_data.extend(orig_mount_bytes)
        index_data.extend(struct.pack('<I', len(new_entries)))

        for item in new_entries:
            index_data.extend(item['content_hash'])
            if version <= 1: index_data.extend(struct.pack('<Q', 0))
            index_data.extend(struct.pack('<Q', item['offset']))
            index_data.extend(struct.pack('<Q', item['uncompressed_size']))
            index_data.extend(struct.pack('<I', item['comp_method'] & CM_MASK))
            index_data.extend(struct.pack('<Q', item['size']))
            if version >= 5:
                index_data.extend(struct.pack('<B', item['unk1']))
                index_data.extend(item['unk2'] if item['unk2'] else b'\x00' * 20)
            if item['comp_method'] != CM_NONE and version >= 3:
                index_data.extend(struct.pack('<I', len(item['compressed_blocks'])))
                for (start, end) in item['compressed_blocks']:
                    index_data.extend(struct.pack('<Q', start))
                    index_data.extend(struct.pack('<Q', end))
            if version >= 4:
                index_data.extend(struct.pack('<I', item['block_size_val']))
                index_data.extend(struct.pack('<B', 1 if item['encrypted'] else 0))
            if version >= 12:
                index_data.extend(struct.pack('<I', item['enc_method']))
                index_data.extend(struct.pack('<I', item['index_new_sep']))

        file_to_dirname = {}
        for dir_path, files_dict in self._index.items():
            dir_str = dir_path.as_posix()
            for fname, entry in files_dict.items():
                for i, fe in enumerate(self._files):
                    if id(fe) == id(entry):
                        file_to_dirname[i] = (dir_str, fname)
                        break
        for i, item in enumerate(new_entries):
            if i not in file_to_dirname:
                if '_dir_path' in item:
                    file_to_dirname[i] = (item['_dir_path'].as_posix(), item['_file_name'])
                else:
                    file_to_dirname[i] = ('', f'file_{i}')

        all_dirs = []
        dir_to_files = {}
        for dir_path in self._index.keys():
            ds = dir_path.as_posix()
            all_dirs.append(ds)
            dir_to_files[ds] = []
        for i, item in enumerate(new_entries):
            ds, fn = file_to_dirname[i]
            if ds not in dir_to_files:
                dir_to_files[ds] = []
                all_dirs.append(ds)
            dir_to_files[ds].append((fn, i))

        index_data.extend(struct.pack('<Q', len(all_dirs)))
        for dir_str in all_dirs:
            files_list = dir_to_files[dir_str]
            if not dir_str or dir_str == '.':
                index_data.extend(struct.pack('<I', 0))
            else:
                if not dir_str.endswith('/'): dir_str_with_slash = dir_str + '/'
                else: dir_str_with_slash = dir_str
                dir_bytes = dir_str_with_slash.encode('utf-8') + b'\x00'
                index_data.extend(struct.pack('<I', len(dir_bytes)))
                index_data.extend(dir_bytes)
            index_data.extend(struct.pack('<Q', len(files_list)))
            for file_name, fi in files_list:
                name_bytes = file_name.encode('utf-8') + b'\x00'
                index_data.extend(struct.pack('<I', len(name_bytes)))
                index_data.extend(name_bytes)
                index_data.extend(struct.pack('<i', -fi - 1))
        index_data.extend(b'\x1d\x00\x00\x00\x2e\x2e')

        index_hash = SHA1.new(bytes(index_data)).digest()

        if version > 7 and self._pak_info.index_encrypted:
            key = PakCrypto.rsa_extract(self._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(self._pak_info.packed_iv, RSA_MOD_1)
            assert len(key) == 32 and len(iv) == 32
            padded = pad(bytes(index_data), AES.block_size)
            aes = AES.new(key, MODE_CBC, iv[:16])
            encrypted_index = aes.encrypt(padded)
        elif self._pak_info.index_encrypted:
            encrypted_index = bytes(b ^ SIMPLE1_DECRYPT_KEY for b in bytes(index_data))
        else:
            encrypted_index = bytes(index_data)

        index_size = len(encrypted_index)
        new_index_offset = orig_index_offset + len(new_data_region)

        encrypted_magic = PAK_MAGIC ^ keystream[2]
        key_stream_hash = struct.pack('<5I', *keystream[4:][:5])
        encrypted_index_hash = bytes(a ^ b for a, b in zip(index_hash, key_stream_hash))
        encrypted_index_size = index_size ^ ((keystream[10] << 32) | keystream[11])
        encrypted_index_offset = new_index_offset ^ ((keystream[0] << 32) | keystream[1])
        encrypted_flag_byte = (1 if self._pak_info.index_encrypted else 0) ^ (keystream[3] & 0xFF)

        orig_data_region = bytearray(self._file_content[0:orig_index_offset])
        output_pak.parent.mkdir(parents=True, exist_ok=True)
        with open(output_pak, 'wb') as f:
            f.write(bytes(orig_data_region))
            f.write(bytes(new_data_region))
            f.write(encrypted_index)
            if version >= 7:
                key_unk1 = struct.pack('<8I', *keystream[7:][:8])
                unk1_plain = self._pak_info.unk1 if self._pak_info.unk1 else b'\x00' * 32
                encrypted_unk1 = bytes(a ^ b for a, b in zip(unk1_plain, key_unk1))
                f.write(encrypted_unk1)
            if version >= 8:
                f.write(self._pak_info.packed_key if self._pak_info.packed_key else b'\x00' * 256)
                f.write(self._pak_info.packed_iv if self._pak_info.packed_iv else b'\x00' * 256)
                f.write(self._pak_info.packed_index_hash if self._pak_info.packed_index_hash else b'\x00' * 256)
            if version >= 9:
                f.write(struct.pack('<I', (self._pak_info.stem_hash or 0) ^ keystream[8]))
                f.write(struct.pack('<I', (self._pak_info.unk2 or 0) ^ keystream[9]))
            if version >= 12:
                f.write(self._pak_info.content_org_hash if self._pak_info.content_org_hash else b'\x00' * 20)
            f.write(struct.pack('<B', encrypted_flag_byte))
            f.write(struct.pack('<I', encrypted_magic))
            f.write(struct.pack('<I', version))
            if version >= 6:
                f.write(encrypted_index_hash)
            else:
                f.write(b'\x00' * 20)
            f.write(struct.pack('<Q', encrypted_index_size))
            f.write(struct.pack('<Q', encrypted_index_offset))

        console.print()
        console.print(Panel(
            f"[bold {SUCCESS}]★ {t('inject_complete')} ★[/bold {SUCCESS}]\n\n"
            f"[white]{t('output_label')}      :[/white] [{ICE}]{output_pak.name}[/{ICE}]\n"
            f"[white]{t('col_size')}        :[/white] [{GOLD}]{human_size(output_pak.stat().st_size)}[/{GOLD}]\n"
            f"[dim]{t('credit_field')}      : {CREDIT}[/dim]",
            title=f"[bold white]◆ {t('success_label')} ◆[/bold white]", border_style=SUCCESS, box=HEAVY, padding=(1, 2)
        ))

    def _get_method_str(self, method_int, is_encryption):
        if is_encryption:
            if PakCrypto._is_simple1_method(method_int): return "SIMPLE1"
            if PakCrypto._is_simple2_method(method_int): return "SIMPLE2"
            if PakCrypto._is_sm4_method(method_int): return f"SM4 (Type {method_int})"
            return "NONE" if method_int == 0 else "UNKNOWN"
        else:
            if method_int == CM_NONE: return "NONE"
            if method_int == CM_ZLIB: return "ZLIB"
            if method_int == CM_ZSTD: return "ZSTD"
            if method_int == CM_ZSTD_DICT: return "ZSTD_DICT"
            return "UNKNOWN"

    def _verify_stem_hash(self) -> None:
        if not self._is_od and self._pak_info.version >= 9:
            expected = zlib.crc32(self._file_path.stem.encode('utf-32le'))
            if self._pak_info.stem_hash != expected:
                console.print(f"[{WARN}]◆ {t('stem_hash_mismatch')}[/{WARN}]")
    def _tencent_load_index(self) -> None:
        index_data = bytes(self._file_content[self._pak_info.index_offset:][:self._pak_info.index_size])
        if self._pak_info.index_encrypted:
            try:
                decrypted = PakCrypto.decrypt_index(index_data, self._pak_info)
                if decrypted and len(decrypted) > 0:
                    index_data = decrypted
                else:
                    console.print(f"[{WARN}]◆ {t('index_decrypt_failed')}[/{WARN}]")
            except Exception:
                console.print(f"[{WARN}]◆ {t('index_decrypt_failed')}[/{WARN}]")
        if not index_data or len(index_data) == 0:
            raise ValueError("Index data is empty after decryption attempt — PAK may be corrupt or use an unsupported encryption key.")
        self._verify_index_hash(index_data)
        self._load_index(index_data)
    def _verify_index_hash(self, index_data) -> None:
        expected_hash = self._pak_info.index_hash
        if not self._is_od and self._pak_info.version >= 8:
            try:
                rsa_hash = PakCrypto.rsa_extract(self._pak_info.packed_index_hash, RSA_MOD_2)
                if expected_hash != rsa_hash:
                    console.print(f"[{WARN}]◆ {t('secure_vip')}  [dim]({CREDIT})[/dim][/{WARN}]")
            except:
                pass
        actual = SHA1.new(index_data).digest()
        if expected_hash != actual:
            console.print(f"[{WARN}]◆ {t('index_hash_mismatch')}[/{WARN}]")
    @staticmethod
    def _construct_mount_point(mount_point: str) -> PurePath:
        result = PurePath()
        for part in PurePath(mount_point).parts:
            if part!= '..':
                result /= part
        return result
    def _peek_content(self, offset: int, size: int, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(size, encryption_method)
        end = min(offset + size, len(self._file_content))
        return self._file_content[offset:end]
    def _peek_block_content(self, block: PakCompressedBlock, encryption_method: int) -> memoryview:
        size = PakCrypto.align_encrypted_content_size(block.end - block.start, encryption_method)
        end = min(block.start + size, len(self._file_content))
        return self._file_content[block.start:end]
    def _construct_zstd_dict(self, dict_entry: TencentPakEntry) -> None:
        assert not self._zstd_dict
        assert not dict_entry.encrypted
        assert dict_entry.compression_method == CM_NONE
        reader = Reader(self._peek_content(dict_entry.offset, dict_entry.size, 0))
        dict_size = reader.u8()
        _ = reader.u4()
        assert dict_size == reader.u4()
        dict_data = reader.s(dict_size)
        self._zstd_dict = PakCompression.zstd_dictionary(dict_data)
    def _load_index(self, index_data) -> None:
        if self._pak_info.version <= 10:
            raise ValueError(t('unsupported_version', v=self._pak_info.version))
        else:
            reader = Reader(index_data)
            self._mount_point = self._construct_mount_point(reader.string())
            num_files = reader.u4()
            self._files = []
            for _ in range(num_files):
                self._files.append(TencentPakEntry(reader, self._pak_info.version))
            num_dirs = reader.u8()
            for _ in range(num_dirs):
                dir_path = PurePath(reader.string())
                num_entries = reader.u8()
                dir_content = {}
                for _ in range(num_entries):
                    entry_name = reader.string()
                    idx = reader.i4()
                    if idx < 0:
                        entry_idx = ~idx
                        if 0 <= entry_idx < len(self._files):
                            dir_content[entry_name] = self._files[entry_idx]
                if self._is_zstd_with_dict and dir_path.name == 'zstddic':
                    if len(dir_content) == 1:
                        self._construct_zstd_dict(list(dir_content.values())[0])
                else:
                    if dir_content:
                        self._index[dir_path] = dir_content

    def _write_to_disk(self, file_path: Path, entry: TencentPakEntry) -> None:
        encryption_method = entry.encryption_method
        compression_method = entry.compression_method
        total_blocks = len(entry.compressed_blocks)

        if compression_method == CM_NONE:
            data = self._peek_content(entry.offset, entry.size, encryption_method)
            if entry.encrypted:
                data = PakCrypto.decrypt_block(data, file_path, encryption_method)
            with open(file_path, 'wb') as f:
                f.write(data)
            return

        with open(file_path, 'wb') as f:
            for idx in PakCrypto.generate_block_indices(total_blocks, encryption_method):
                if idx >= len(entry.compressed_blocks):
                    continue
                block = entry.compressed_blocks[idx]
                data = self._peek_block_content(block, encryption_method)
                if entry.encrypted:
                    try:
                        data = PakCrypto.decrypt_block(data, file_path, encryption_method)
                    except:
                        pass
                try:
                    decompressed = PakCompression.decompress_block(data, self._zstd_dict, compression_method)
                except:
                    decompressed = data
                f.write(decompressed)

    def dump(self, out_path: Path) -> None:
        mp_parts = [_sanitize_part(p) for p in self._mount_point.parts]
        out_path = out_path.joinpath(*mp_parts) if mp_parts else out_path
        out_path.mkdir(parents=True, exist_ok=True)
        total_files = sum(len(d) for d in self._index.values())

        with Progress(
            SpinnerColumn(style=NEON),
            TextColumn(f"[bold {ICE}]{{task.description}}[/bold {ICE}]"),
            BarColumn(style=GOLD, complete_style=SUCCESS),
            TaskProgressColumn(),
            TimeElapsedColumn(),
            console=console
        ) as progress:
            task = progress.add_task(t('extract_files'), total=total_files)
            for dir_path, dir_content in self._index.items():
                dp_parts = [_sanitize_part(p) for p in dir_path.parts]
                current_out_path = out_path.joinpath(*dp_parts) if dp_parts else out_path
                current_out_path.mkdir(parents=True, exist_ok=True)
                for file_name, entry in dir_content.items():
                    safe_name = _sanitize_part(file_name)
                    try:
                        self._write_to_disk(current_out_path / safe_name, entry)
                    except Exception as e:
                        console.print(f"[{WARN}]◆ {t('skip_file', name=safe_name, err=e)}[/{WARN}]")
                    progress.update(task, advance=1)

    def __del__(self):
        if hasattr(self, '_file_handle'):
            try:
                self._file_handle.close()
            except:
                pass

_INVALID_FN_CHARS = re.compile(r'[\x00-\x1f<>:"/\\|?*\x7f]')

def _sanitize_part(name) -> str:
    if name is None:
        return '_'
    s = str(name)
    s = s.replace('\x00', '')
    s = _INVALID_FN_CHARS.sub('', s)
    s = s.rstrip('. ')
    if not s or s in ('.', '..'):
        s = '_'
    return s

def _encrypt_plaintext(plaintext: bytes, pak_relative_path: PurePath, encryption_method: int) -> bytes:
    if PakCrypto._is_simple1_method(encryption_method):
        return bytes((b ^ SIMPLE1_DECRYPT_KEY for b in plaintext))
    else:
        if PakCrypto._is_simple2_method(encryption_method):
            pad = -len(plaintext) % SIMPLE2_BLOCK_SIZE
            plaintext += b'\x00' * pad
            key, = struct.unpack('<I', SIMPLE2_DECRYPT_KEY)
            rolling = key
            out = []
            for x, in struct.iter_unpack('<I', plaintext):
                c = rolling ^ x
                out.append(c)
                rolling ^= c
            return struct.pack(f'<{len(out)}I', *out)
        else:
            if PakCrypto._is_sm4_method(encryption_method):
                key = PakCrypto._derive_sm4_key(pak_relative_path, encryption_method)
                sm4 = PakCrypto._sm4_context_for_key(key)
                pad_len = -len(plaintext) % 16
                if pad_len > 0:
                    plaintext = plaintext + b'\x00' * pad_len
                out = bytearray()
                for i in range(0, len(plaintext), 16):
                    block = plaintext[i:i + 16]
                    if len(block) < 16:
                        block = block.ljust(16, b'\x00')
                    out.extend(sm4.encrypt(block))
                return bytes(out)
            else:
                return plaintext

def _best_compress(chunk, cm, zstd_dict=None):
    if cm == CM_ZLIB:
        return zlib.compress(chunk, 9)
    if cm in (CM_ZSTD, CM_ZSTD_DICT):
        zd = zstd_dict if cm == CM_ZSTD_DICT else None
        for lvl in [22, 19, 16, 13, 10, 7, 4, 1]:
            try:
                return ZstdCompressor(level=lvl, dict_data=zd, threads=1).compress(chunk)
            except Exception:
                continue
    return chunk

def _block_permutation(n_chunks: int, encryption_method: int):
    return PakCrypto.generate_block_indices(n_chunks, encryption_method)

def _pw_string(s):
    if not s: return struct.pack('<i', 0)
    b = s.encode('utf-8') + b'\x00'
    return struct.pack('<i', len(b)) + b

def _pw_entry(e, v):
    w = bytearray(e.content_hash)
    w += struct.pack('<Q', e.offset)
    w += struct.pack('<Q', e.uncompressed_size)
    w += struct.pack('<I', e.compression_method)
    w += struct.pack('<Q', e.size)
    if v >= 5:
        w += bytes([e.unk1])
        w += e.unk2
    if e.compression_method != CM_NONE and v >= 3:
        w += struct.pack('<I', len(e.compressed_blocks))
        for b in e.compressed_blocks:
            w += struct.pack('<QQ', b.start, b.end)
    if v >= 4:
        w += struct.pack('<I', e.compression_block_size)
        w += bytes([1 if e.encrypted else 0])
    if v >= 12:
        w += struct.pack('<II', e.encryption_method, e.index_new_sep)
    return bytes(w)

def _get_all_dirs_and_mp(pak_file):
    raw = bytes(pak_file._file_content[
        pak_file._pak_info.index_offset:][:pak_file._pak_info.index_size])
    if pak_file._pak_info.index_encrypted:
        try:
            raw = PakCrypto.decrypt_index(raw, pak_file._pak_info)
        except:
            pass
    r = Reader(raw)
    mp = r.string()
    num_files = r.u4()
    for _ in range(num_files):
        TencentPakEntry(r, pak_file._pak_info.version)
    dirs = {}
    for _ in range(r.u8()):
        dp = r.string()
        cnt = r.u8()
        d = {}
        for _ in range(cnt):
            fname = r.string()
            idx = ~r.i4()
            if 0 <= idx < len(pak_file._files):
                d[fname] = (idx, pak_file._files[idx])
        dirs[dp] = d
    return mp, dirs

def repack_pak_file_full(pak_file, edited_root, output_path, target_path=None, force_add=False, path_map=None):
    import copy as _cp
    edit_files = [p for p in Path(edited_root).rglob('*') if p.is_file()]
    if not edit_files:
        console.print(f"[{ERR}]{t('edit_empty_short')}  [dim]({CREDIT})[/dim][/{ERR}]")
        return 0
    version = pak_file._pak_info.version
    keystream = PakCrypto.zuc_keystream()
    orig_fc = pak_file._file_content
    mp_str, all_dirs = _get_all_dirs_and_mp(pak_file)

    def _norm_dir(tp):
        if not tp:
            return None
        tp = tp.replace('\\', '/')
        matched_dir = None
        for existing_dir in all_dirs.keys():
            if existing_dir.strip('/').lower() == tp.strip('/').lower():
                matched_dir = existing_dir
                break
        return matched_dir if matched_dir else (tp.strip('/') + '/')

    if target_path:
        target_path = _norm_dir(target_path)
    norm_path_map = {}
    if path_map:
        for _name, _tp in path_map.items():
            norm_path_map[_name] = _norm_dir(_tp)

    pak_name_map = {}
    for dp_str, dir_files in all_dirs.items():
        for name, (slot, entry) in dir_files.items():
            full_path = str(PurePath(dp_str) / name).replace('\\', '/')
            pak_name_map.setdefault(name.lower(), []).append((full_path, slot, entry))

    edited = {}
    for p in edit_files:
        fl = p.name.lower()
        found_match = False
        if path_map is not None:
            tp = norm_path_map.get(p.name)
        else:
            tp = target_path

        if not found_match:
            rel_path = p.relative_to(edited_root).as_posix()
            mp_norm = mp_str.strip('/')
            if mp_norm and rel_path.startswith(mp_norm + '/'):
                rel_path = rel_path[len(mp_norm) + 1:]
            for dp_str, dir_files in all_dirs.items():
                for name, (slot, entry) in dir_files.items():
                    full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                    if full_path == rel_path or full_path.endswith('/' + rel_path) or rel_path.endswith('/' + name):
                        edited[full_path] = (p, slot, entry, False)
                        found_match = True
                        break
                if found_match:
                    break

        if fl in pak_name_map:
            cands = pak_name_map[fl]
            if tp:
                target_cands = [(fp, s, e) for fp, s, e in cands if tp.strip('/') in fp]
                if target_cands:
                    sz = p.stat().st_size
                    sm = [(fp, s, e) for fp, s, e in target_cands if e.uncompressed_size == sz]
                    fp, s, e = sm[0] if sm else target_cands[0]
                    edited[fp] = (p, s, e, False)
                    found_match = True
            if not found_match:
                sz = p.stat().st_size
                sm = [(fp, s, e) for fp, s, e in cands if e.uncompressed_size == sz]
                if sm:
                    fp, s, e = sm[0]
                else:
                    fp, s, e = cands[0]
                if tp and force_add:
                    new_fp = f"{tp.rstrip('/')}/{p.name}"
                    edited[new_fp] = (p, s, e, True)
                else:
                    edited[fp] = (p, s, e, False)
                found_match = True

        if not found_match:
            stem = p.stem.lower()
            ext = p.suffix.lower()
            for dp_str, dir_files in all_dirs.items():
                for name, (slot, entry) in dir_files.items():
                    if Path(name).stem.lower() == stem and Path(name).suffix.lower() == ext:
                        full_path = str(PurePath(dp_str) / name).replace('\\', '/')
                        if tp and force_add:
                            new_fp = f"{tp.rstrip('/')}/{p.name}"
                            edited[new_fp] = (p, slot, entry, True)
                        else:
                            edited[full_path] = (p, slot, entry, False)
                        found_match = True
                        break
                if found_match:
                    break

        if not found_match and force_add:
            template_entry = None
            for dp_str, dir_files in all_dirs.items():
                for _n, (_s, e) in dir_files.items():
                    if Path(_n).suffix.lower() == p.suffix.lower():
                        template_entry = e
                        break
                if template_entry:
                    break
            if not template_entry:
                for dp_str, dir_files in all_dirs.items():
                    for _n, (_s, e) in dir_files.items():
                        template_entry = e
                        break
                    if template_entry:
                        break
            rel_path = p.relative_to(edited_root).as_posix()
            mp_norm = mp_str.strip('/')
            if mp_norm and rel_path.startswith(mp_norm + '/'):
                rel_path = rel_path[len(mp_norm) + 1:]
            if tp:
                new_fp = f"{tp.rstrip('/')}/{p.name}"
            else:
                new_fp = rel_path
            if template_entry:
                edited[new_fp] = (p, -1, template_entry, True)
                found_match = True
            else:
                console.print(f"[{WARN}]{t('skipped_no_entry', name=p.name)}  [dim]({CREDIT})[/dim][/{WARN}]")

    if not edited:
        console.print(f"[{ERR}]{t('no_files_to_repack')}  [dim]({CREDIT})[/dim][/{ERR}]")
        return 0

    slot_to_new = {}
    for i, e in enumerate(pak_file._files):
        ne = _cp.copy(e)
        ne.compressed_blocks = [_cp.copy(b) for b in e.compressed_blocks]
        slot_to_new[i] = ne

    import tempfile as _tmpfile
    _tmpfd, _tmppath = _tmpfile.mkstemp(suffix='.pak')
    _outf = open(_tmpfd, 'r+b')
    _pos = [0]

    file_rows = []
    new_added = []
    processed_count = 0
    total_to_process = sum(len(files) for files in all_dirs.values())

    def _out_append(data: bytes):
        start = _pos[0]
        _outf.write(data)
        _pos[0] += len(data)
        return start

    def _out_len() -> int:
        return _pos[0]

    for dp_str, dir_files in list(all_dirs.items()):
        for name, (slot, old_entry) in list(dir_files.items()):
            full_path = str(PurePath(dp_str) / name).replace('\\', '/')
            ne = slot_to_new[slot]
            em = old_entry.encryption_method
            cm = old_entry.compression_method

            if full_path in edited:
                p, _s, template, is_new = edited[full_path]
                new_raw = p.read_bytes()
                pak_rel = PurePath(full_path)

                ne.uncompressed_size = len(new_raw)
                ne.compression_method = cm
                ne.encryption_method = em
                ne.encrypted = old_entry.encrypted
                ne.unk1 = old_entry.unk1
                ne.index_new_sep = old_entry.index_new_sep

                if is_new and (target_path or path_map):
                    full_path_str = mp_str + full_path
                    ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
                else:
                    ne.unk2 = old_entry.unk2

                stored_start = _out_len()
                if cm == CM_NONE:
                    cipher = (_encrypt_plaintext(new_raw, pak_rel, em) if ne.encrypted else new_raw)
                    ne.offset = _out_len()
                    ne.size = len(new_raw)
                    _out_append(cipher)
                else:
                    cs = (old_entry.compression_block_size if old_entry.compression_block_size > 0 else 65536)
                    chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                    order = _block_permutation(len(chunks), em)
                    cipher_by_logical = []
                    for chunk in chunks:
                        compressed = _best_compress(chunk, cm, pak_file._zstd_dict)
                        cipher = (_encrypt_plaintext(compressed, pak_rel, em) if ne.encrypted else compressed)
                        cipher_by_logical.append(cipher)
                    inv = [0] * len(chunks)
                    for logical_i, phys_i in enumerate(order):
                        inv[phys_i] = logical_i
                    new_blks = [None] * len(chunks)
                    for phys_i in range(len(chunks)):
                        blk = PakCompressedBlock.__new__(PakCompressedBlock)
                        blk.start = _out_len()
                        _out_append(cipher_by_logical[inv[phys_i]])
                        blk.end = _out_len()
                        new_blks[phys_i] = blk
                    ne.compressed_blocks = new_blks
                    ne.offset = new_blks[0].start if new_blks else _out_len()
                    ne.size = sum(b.end - b.start for b in new_blks)

                _outf.seek(stored_start)
                stored_bytes = _outf.read(ne.size)
                _outf.seek(0, 2)
                ne.content_hash = SHA1.new(stored_bytes).digest()

                file_rows.append((full_path, len(new_raw), ne.size))
                processed_count += 1
                if processed_count % 5 == 0 or processed_count == total_to_process:
                    sys.stdout.write(f'\r[{ICE}]  {t("processing_assets")} [{processed_count}/{total_to_process}]  · {CREDIT}[/]')
                    sys.stdout.flush()
            else:
                if cm == CM_NONE:
                    read_sz = (PakCrypto.align_encrypted_content_size(old_entry.size, em)
                               if old_entry.encrypted else old_entry.size)
                    ne.offset = _out_len()
                    _out_append(bytes(orig_fc[old_entry.offset: old_entry.offset + read_sz]))
                elif old_entry.compressed_blocks:
                    new_blks = []
                    for ob in old_entry.compressed_blocks:
                        unc = ob.end - ob.start
                        enc = (PakCrypto.align_encrypted_content_size(unc, em)
                               if old_entry.encrypted else unc)
                        nb = PakCompressedBlock.__new__(PakCompressedBlock)
                        nb.start = _out_len()
                        _out_append(bytes(orig_fc[ob.start: ob.start + enc]))
                        nb.end = _out_len()
                        new_blks.append(nb)
                    ne.compressed_blocks = new_blks
                    ne.offset = new_blks[0].start if new_blks else _out_len()

    sys.stdout.write(f'\r  {t("all_processed", n=processed_count)}  · {CREDIT}          \n')
    sys.stdout.flush()

    if force_add:
        for fp, (p, slot, template, is_new) in edited.items():
            if not is_new or slot >= 0:
                continue
            already = False
            for dp_str, dir_files in all_dirs.items():
                for _n, (_s, _e) in dir_files.items():
                    if str(PurePath(dp_str) / _n).replace('\\', '/') == fp:
                        already = True
                        break
                if already:
                    break
            if already:
                continue

            ne = _cp.copy(template)
            new_raw = p.read_bytes()
            pak_rel = PurePath(fp)
            ne.uncompressed_size = len(new_raw)
            ne.compression_method = template.compression_method
            ne.compressed_blocks = []
            ne.compression_block_size = template.compression_block_size
            ne.encryption_method = template.encryption_method
            ne.encrypted = template.encrypted
            ne.unk1 = template.unk1
            full_path_str = mp_str + fp
            ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
            ne.index_new_sep = template.index_new_sep

            stored_start = _out_len()
            if ne.compression_method == CM_NONE:
                cipher = (_encrypt_plaintext(new_raw, pak_rel, ne.encryption_method) if ne.encrypted else new_raw)
                ne.offset = _out_len()
                ne.size = len(new_raw)
                _out_append(cipher)
            else:
                cs = template.compression_block_size if template.compression_block_size > 0 else 65536
                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                order = _block_permutation(len(chunks), ne.encryption_method)
                cipher_by_logical = []
                for chunk in chunks:
                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                    cipher = (_encrypt_plaintext(compressed, pak_rel, ne.encryption_method) if ne.encrypted else compressed)
                    cipher_by_logical.append(cipher)
                inv = [0] * len(chunks)
                for logical_i, phys_i in enumerate(order):
                    inv[phys_i] = logical_i
                new_blks = [None] * len(chunks)
                for phys_i in range(len(chunks)):
                    blk = PakCompressedBlock.__new__(PakCompressedBlock)
                    blk.start = _out_len()
                    _out_append(cipher_by_logical[inv[phys_i]])
                    blk.end = _out_len()
                    new_blks[phys_i] = blk
                ne.compressed_blocks = new_blks
                ne.offset = new_blks[0].start if new_blks else _out_len()
                ne.size = sum(b.end - b.start for b in new_blks)

            _outf.seek(stored_start)
            stored_bytes = _outf.read(ne.size)
            _outf.seek(0, 2)
            ne.content_hash = SHA1.new(stored_bytes).digest()

            if path_map is not None:
                _nk = norm_path_map.get(p.name)
                _dir_key = _nk if _nk else ''
            else:
                _dir_key = target_path
            new_slot = len(slot_to_new) + len(new_added)
            new_added.append((_dir_key, p.name, ne, new_slot))
            file_rows.append((fp, len(new_raw), ne.size))

    max_slot = max(slot_to_new.keys()) if slot_to_new else -1
    new_files = [slot_to_new[i] for i in range(max_slot + 1)]
    dir_to_added = {}
    for dir_key, name, ne, new_slot in new_added:
        new_files.append(ne)
        dir_to_added.setdefault(dir_key, []).append((name, ne, new_slot))

    for dir_key, items in dir_to_added.items():
        if dir_key not in all_dirs:
            all_dirs[dir_key] = {}
        for name, ne, new_slot in items:
            all_dirs[dir_key][name] = (new_slot, ne)

    idx = bytearray(_pw_string(mp_str))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files:
        idx += _pw_entry(ne, version)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, dir_files in all_dirs.items():
        idx += _pw_string(dp_str)
        idx += struct.pack('<Q', len(dir_files))
        for name, (slot, _old_e) in dir_files.items():
            idx += _pw_string(name)
            idx += struct.pack('<i', ~slot)

    index_plain = bytes(idx)
    new_sha1 = SHA1.new(index_plain).digest()

    if pak_file._pak_info.index_encrypted:
        try:
            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
            if key and iv and len(key) == 32 and len(iv) >= 16:
                aes = AES.new(key, MODE_CBC, iv[:16])
                pad = (-len(index_plain)) % AES.block_size or AES.block_size
                index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
            else:
                index_bytes = index_plain
        except:
            index_bytes = index_plain
    else:
        index_bytes = index_plain

    new_idx_offset = _out_len()
    new_idx_size = len(index_bytes)
    _out_append(index_bytes)

    footer_sz = TencentPakInfo._mem_size(version)
    new_footer = bytearray(orig_fc[-footer_sz:])
    h_key = struct.pack('<5I', *keystream[4:9])
    new_footer[-36:-16] = bytes(a ^ b for a, b in zip(new_sha1, h_key))
    new_footer[-16:-8] = ((new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little'))
    new_footer[-8:] = ((new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little'))
    _out_append(new_footer)

    _outf.flush()
    _outf.close()
    shutil.copy2(_tmppath, output_path)
    os.unlink(_tmppath)

    if file_rows:
        summary = Table(title=f"◆ {t('files_processed')} · {CREDIT}", box=ROUNDED, border_style=GOLD)
        summary.add_column(t('path_in_pak'), style=f"bold {NEON}")
        summary.add_column(t('original_size'), justify="right", style=MUTED)
        summary.add_column(t('stored_size'), justify="right", style=ICE)
        for fp, orig_sz, stored_sz in file_rows:
            summary.add_row(fp, human_size(orig_sz), human_size(stored_sz))
        console.print(summary)

    return len(edited)

def build_new_pak_from_template(template_pak_path: Path, edit_dir: Path, output_path: Path, target_path: str = None, path_map: dict = None):
    import copy as _cp
    console.print(f"[white]{t('building_new_pak', name=template_pak_path.name)}  [dim]· {CREDIT}[/dim][/white]")
    pak_file = TencentPakFile(template_pak_path, is_od=True)
    version = pak_file._pak_info.version
    keystream = PakCrypto.zuc_keystream()
    mp_str, _all_dirs_orig = _get_all_dirs_and_mp(pak_file)

    template_entry = None
    for _dir_path, files in pak_file._index.items():
        for _name, entry in files.items():
            template_entry = entry
            break
        if template_entry:
            break
    if template_entry is None:
        console.print(f"[{ERR}]{t('no_file_in_template')}  [dim]({CREDIT})[/dim][/{ERR}]")
        return 0

    edit_files = [p for p in Path(edit_dir).rglob('*') if p.is_file()]
    if not edit_files:
        console.print(f"[{ERR}]{t('no_file_in_edit')}  [dim]({CREDIT})[/dim][/{ERR}]")
        return 0

    out_buf = bytearray()
    new_files = []
    all_dirs = {}
    file_rows = []

    with Progress(
        SpinnerColumn(style=NEON),
        TextColumn(f"[bold {ICE}]{{task.description}}[/bold {ICE}]"),
        BarColumn(style=GOLD, complete_style=SUCCESS),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console
    ) as progress:
        task = progress.add_task(t('add_files'), total=len(edit_files))

        for p in edit_files:
            rel = p.relative_to(edit_dir).as_posix()
            if path_map is not None:
                tp_for_file = path_map.get(p.name)
                if tp_for_file is None:
                    tp_for_file = ''
                if tp_for_file == '':
                    parent = str(PurePath(rel).parent).replace('\\', '/')
                    dir_key = '' if parent == '.' else parent + '/'
                    fp = rel
                else:
                    dir_key = tp_for_file.rstrip('/') + '/'
                    fp = f"{tp_for_file.rstrip('/')}/{p.name}"
            elif target_path:
                fp = f"{target_path.rstrip('/')}/{p.name}"
                dir_key = target_path.rstrip('/') + '/'
            else:
                parent = str(PurePath(rel).parent).replace('\\', '/')
                dir_key = '' if parent == '.' else parent + '/'
                fp = rel

            ne = _cp.copy(template_entry)
            new_raw = p.read_bytes()
            pak_rel = PurePath(fp)

            ne.uncompressed_size = len(new_raw)
            ne.compression_method = template_entry.compression_method
            ne.encryption_method = template_entry.encryption_method
            ne.encrypted = template_entry.encrypted
            ne.unk1 = template_entry.unk1
            full_path_str = mp_str + fp
            ne.unk2 = SHA1.new(full_path_str.lower().encode('utf-8')).digest()
            ne.index_new_sep = template_entry.index_new_sep

            stored_start = len(out_buf)
            if ne.compression_method == CM_NONE:
                cipher = (_encrypt_plaintext(new_raw, pak_rel, ne.encryption_method)
                          if ne.encrypted else new_raw)
                ne.offset = len(out_buf)
                ne.size = len(new_raw)
                out_buf += cipher
            else:
                cs = template_entry.compression_block_size if template_entry.compression_block_size > 0 else 65536
                chunks = [new_raw[i:i + cs] for i in range(0, len(new_raw), cs)]
                order = _block_permutation(len(chunks), ne.encryption_method)
                cipher_by_logical = []
                for chunk in chunks:
                    compressed = _best_compress(chunk, ne.compression_method, pak_file._zstd_dict)
                    cipher = (_encrypt_plaintext(compressed, pak_rel, ne.encryption_method)
                              if ne.encrypted else compressed)
                    cipher_by_logical.append(cipher)
                inv = [0] * len(chunks)
                for logical_i, phys_i in enumerate(order):
                    inv[phys_i] = logical_i
                new_blks = [None] * len(chunks)
                for phys_i in range(len(chunks)):
                    blk = PakCompressedBlock.__new__(PakCompressedBlock)
                    blk.start = len(out_buf)
                    blk.end = blk.start + len(cipher_by_logical[inv[phys_i]])
                    out_buf += cipher_by_logical[inv[phys_i]]
                    new_blks[phys_i] = blk
                ne.compressed_blocks = new_blks
                ne.offset = new_blks[0].start if new_blks else len(out_buf)
                ne.size = sum(b.end - b.start for b in new_blks)

            stored_bytes = bytes(out_buf[ne.offset:ne.offset + ne.size])
            ne.content_hash = SHA1.new(stored_bytes).digest()

            new_files.append(ne)
            all_dirs.setdefault(dir_key, {})[p.name] = ne
            file_rows.append((fp, ne.uncompressed_size, ne.size))
            progress.update(task, advance=1, description=f"{p.name[:30]}")

    summary = Table(title=f"◆ {t('new_pak_files')} · {CREDIT}", box=ROUNDED, border_style=GOLD)
    summary.add_column(t('path_in_pak'), style=f"bold {NEON}")
    summary.add_column(t('original_size'), justify="right", style=MUTED)
    summary.add_column(t('stored_size'), justify="right", style=ICE)
    for fp, orig_sz, stored_sz in file_rows:
        summary.add_row(fp, human_size(orig_sz), human_size(stored_sz))
    console.print(summary)

    id_to_idx = {id(ne): i for i, ne in enumerate(new_files)}

    idx = bytearray(_pw_string(mp_str))
    idx += struct.pack('<I', len(new_files))
    for ne in new_files:
        idx += _pw_entry(ne, version)
    idx += struct.pack('<Q', len(all_dirs))
    for dp_str, dir_files in all_dirs.items():
        idx += _pw_string(dp_str)
        idx += struct.pack('<Q', len(dir_files))
        for name, e in dir_files.items():
            idx += _pw_string(name)
            idx += struct.pack('<i', ~id_to_idx[id(e)])

    index_plain = bytes(idx)
    new_sha1 = SHA1.new(index_plain).digest()

    if pak_file._pak_info.index_encrypted:
        try:
            key = PakCrypto.rsa_extract(pak_file._pak_info.packed_key, RSA_MOD_1)
            iv = PakCrypto.rsa_extract(pak_file._pak_info.packed_iv, RSA_MOD_1)
            if key and iv and len(key) == 32 and len(iv) >= 16:
                aes = AES.new(key, MODE_CBC, iv[:16])
                pad = (-len(index_plain)) % AES.block_size or AES.block_size
                index_bytes = aes.encrypt(index_plain + bytes([pad] * pad))
            else:
                index_bytes = index_plain
        except:
            index_bytes = index_plain
    else:
        index_bytes = index_plain

    new_idx_offset = len(out_buf)
    new_idx_size = len(index_bytes)
    out_buf += index_bytes

    orig_fc = pak_file._file_content
    footer_sz = TencentPakInfo._mem_size(version)
    new_footer = bytearray(orig_fc[-footer_sz:])

    h_key = struct.pack('<5I', *keystream[4:9])
    new_footer[-36:-16] = bytes(a ^ b for a, b in zip(new_sha1, h_key))
    new_footer[-16:-8] = ((new_idx_size ^ (keystream[10] << 32 | keystream[11])).to_bytes(8, 'little'))
    new_footer[-8:] = ((new_idx_offset ^ (keystream[0] << 32 | keystream[1])).to_bytes(8, 'little'))
    out_buf += new_footer

    with open(output_path, 'wb') as f:
        f.write(out_buf)

    console.print(f"[{SUCCESS}]◆ {t('new_pak_written', path=output_path)}  [dim]· {CREDIT}[/dim][/{SUCCESS}]")
    console.print(f"[{SUCCESS}]◆ {t('files_included', count=len(new_files))}  [dim]· {CREDIT}[/dim][/{SUCCESS}]")

    try:
        check_pak = TencentPakFile(output_path, is_od=True)
    except AssertionError:
        console.print(f"[{ERR}]{t('verified_failed_hash')}  [dim]({CREDIT})[/dim][/{ERR}]")
    except Exception as e:
        console.print(f"[{ERR}]{t('verified_failed')}: {e}  [dim]({CREDIT})[/dim][/{ERR}]")

    return len(new_files)

def display_file_selector(title, folder_path, file_pattern="*.pak"):
    files = list(folder_path.glob(file_pattern))
    if not files:
        hexa_alert(t('no_pak_files', pattern=file_pattern, path=folder_path), "error")
        return None, None

    table = Table(box=HEAVY, show_header=True, expand=True, padding=(0, 2), border_style=GOLD)
    table.add_column(t('col_num'), justify="right", style=f"bold {GOLD}", width=4)
    table.add_column(t('col_file'), style=f"bold {NEON}")
    table.add_column(t('col_size'), justify="right", style=ICE)

    for i, f in enumerate(files, 1):
        size_mb = f.stat().st_size / (1024 * 1024)
        table.add_row(f"[{i}]", f.name, f"{size_mb:.2f} MB")

    console.print()
    console.print(Panel(table, title=f"[bold {GOLD}]★ {title} ★  ·  {CREDIT}[/bold {GOLD}]",
                        border_style=GOLD, box=HEAVY, padding=(1, 2)))

    try:
        idx = int(hexa_prompt(t('select_file_prompt', n=len(files)))) - 1
        if idx < 0 or idx >= len(files):
            hexa_alert(t('invalid_selection'), "error")
            return None, None
        return files[idx], files
    except ValueError:
        hexa_alert(t('invalid_number'), "error")
        return None, None

def _show_file_tree(root: Path, max_files: int = 40):
    """Print a compact file tree of extracted files."""
    ab = AnimatedBorder.get_instance()
    c1 = ab.get_moving_border_style(0, 0.4)
    all_files = sorted(root.rglob("*"))
    files_only = [f for f in all_files if f.is_file()]
    dirs_only  = [d for d in all_files if d.is_dir()]
    console.print()
    console.print(f"  [{c1}]┌{'─'*58}┐[/{c1}]")
    console.print(f"  [{c1}]│[/{c1}]  [bold {ICE}]📂  EXTRACTED FILE TREE[/bold {ICE}]  [dim]· {CREDIT}[/dim]  [{c1}]│[/{c1}]")
    console.print(f"  [{c1}]├{'─'*58}┤[/{c1}]")
    shown = 0
    seen_dirs = set()
    for f in files_only:
        if shown >= max_files:
            remaining = len(files_only) - shown
            console.print(f"  [{c1}]│[/{c1}]  [dim]... and {remaining} more files[/dim]")
            break
        try:
            rel = f.relative_to(root)
        except ValueError:
            rel = f
        parts = rel.parts
        # show parent dir once
        if len(parts) > 1:
            parent = str(Path(*parts[:-1]))
            if parent not in seen_dirs:
                seen_dirs.add(parent)
                console.print(f"  [{c1}]│[/{c1}]  [bold {NEON}]📁 {parent}/[/bold {NEON}]")
        ext = f.suffix.lower()
        icon = "📜" if ext in ('.lua','.luac','.slua') else "📄" if ext in ('.json','.txt','.ini','.cfg') else "🗜" if ext in ('.pak','.zip','.gz') else "🖼" if ext in ('.png','.jpg','.bmp','.tga') else "📦"
        size = human_size(f.stat().st_size)
        indent = "   " if len(parts) > 1 else ""
        console.print(f"  [{c1}]│[/{c1}]  {indent}{icon}  [{ICE}]{parts[-1]}[/{ICE}]  [dim]({size})[/dim]")
        shown += 1
    console.print(f"  [{c1}]├{'─'*58}┤[/{c1}]")
    console.print(f"  [{c1}]│[/{c1}]  [bold {SUCCESS}]✔  {len(files_only)} files  ·  {len(dirs_only)} dirs[/bold {SUCCESS}]  [{c1}]│[/{c1}]")
    console.print(f"  [{c1}]└{'─'*58}┘[/{c1}]")

def action_unpack_pak():
    pak_dir = PAK_DIR
    if not pak_dir.exists():
        hexa_alert(t('pak_not_found', path=pak_dir), "error")
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    pak_file, _ = display_file_selector(t('select_unpack'), pak_dir)
    if not pak_file:
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    hexa_section(t('unpacking', name=pak_file.name))
    unpack_path = PAK_UNPACK_DIR / pak_file.stem

    # --- Universal unpack: try Tencent PAK first, fallback to raw zlib/zstd scan ---
    extracted = False
    try:
        pak = TencentPakFile(pak_file)
        pak.dump(unpack_path)
        extracted = True
    except Exception as e_tencent:
        hexa_alert(f"Tencent PAK parse failed: {escape(str(e_tencent))} — trying raw extraction...", "warning")
        try:
            _raw_unpack_pak(pak_file, unpack_path)
            extracted = True
        except Exception as e_raw:
            hexa_alert(f"Raw extraction also failed: {escape(str(e_raw))}", "error")

    if extracted:
        hexa_alert(t('extracted_to', path=unpack_path), "success")
        _show_file_tree(unpack_path)
    safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')

def _raw_unpack_pak(pak_file: Path, out_path: Path):
    """
    Fallback unpacker: walks the raw PAK bytes looking for zlib/zstd/lz4
    compressed blocks and embedded files, extracting anything it can decode.
    Handles standard UE4 PAK (no Tencent encryption), plain zip-like, and
    raw compressed chunks.
    """
    out_path.mkdir(parents=True, exist_ok=True)
    data = pak_file.read_bytes()
    extracted_count = 0

    # --- Try standard UE4 PAK (non-Tencent) magic 0x5A6F12E1 ---
    UE4_MAGIC = struct.pack('<I', 0x5A6F12E1)
    magic_pos = data.rfind(UE4_MAGIC)
    if magic_pos != -1:
        try:
            _ue4_raw_unpack(data, magic_pos, out_path)
            return
        except Exception:
            pass  # fall through to brute-force scan

    # --- Try ZIP format ---
    import zipfile, io
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            zf.extractall(out_path)
            return
    except Exception:
        pass

    # --- Brute-force: scan for zlib/zstd compressed chunks ---
    # zlib magic: 0x789C, 0x7801, 0x78DA, 0x78BB, 0x785E
    zlib_magics = [b'\x78\x9c', b'\x78\x01', b'\xda\x78', b'\x78\xbb', b'\x78\x5e']
    # zstd magic: 0xFD2FB528
    zstd_magic = b'\x28\xb5\x2f\xfd'

    chunk_idx = 0
    pos = 0
    while pos < len(data) - 4:
        found = False
        # check zstd
        if data[pos:pos+4] == zstd_magic:
            try:
                import zstandard as zstd
                dctx = zstd.ZstdDecompressor()
                decompressed = dctx.decompress(data[pos:pos+65536*4], max_output_size=1024*1024*16)
                chunk_file = out_path / f"chunk_{chunk_idx:04d}.bin"
                chunk_file.write_bytes(decompressed)
                extracted_count += 1
                chunk_idx += 1
                pos += 4
                found = True
            except Exception:
                pass
        # check zlib
        if not found:
            for magic in zlib_magics:
                if data[pos:pos+2] == magic:
                    try:
                        decompressed = zlib.decompress(data[pos:pos+65536*8])
                        if len(decompressed) > 64:
                            chunk_file = out_path / f"chunk_{chunk_idx:04d}.bin"
                            chunk_file.write_bytes(decompressed)
                            extracted_count += 1
                            chunk_idx += 1
                            pos += 2
                            found = True
                            break
                    except Exception:
                        pass
        if not found:
            pos += 1

    # Always dump raw as fallback
    raw_out = out_path / f"{pak_file.stem}_raw.pak"
    shutil.copy2(pak_file, raw_out)
    if extracted_count == 0:
        hexa_alert(f"No compressed chunks found — saved raw PAK to {raw_out}", "warning")
    else:
        hexa_alert(f"Raw extraction: {extracted_count} chunks extracted", "success")

def _ue4_raw_unpack(data: bytes, magic_pos: int, out_path: Path):
    """Parse standard (non-Tencent) UE4 PAK footer and extract entries."""
    # Footer: magic(4) ver(4) index_off(8) index_size(8) index_hash(20) = 44 bytes
    footer = data[magic_pos:]
    magic, version = struct.unpack_from('<II', footer, 0)
    index_offset, index_size = struct.unpack_from('<QQ', footer, 8)
    if not (0 < index_offset < len(data) and 0 < index_size < len(data)):
        raise ValueError("Invalid UE4 footer offsets")
    index_data = data[index_offset:index_offset+index_size]
    pos = 0
    mount_len = struct.unpack_from('<i', index_data, pos)[0]; pos += 4
    if mount_len < 0 or mount_len > 4096:
        raise ValueError("Invalid mount point length")
    mount_point = index_data[pos:pos+mount_len].decode('utf-8','replace').rstrip('\x00'); pos += mount_len
    num_entries = struct.unpack_from('<i', index_data, pos)[0]; pos += 4
    if num_entries < 0 or num_entries > 500000:
        raise ValueError("Unreasonable entry count")
    for i in range(num_entries):
        name_len = struct.unpack_from('<i', index_data, pos)[0]; pos += 4
        if name_len < 0 or name_len > 8192:
            break
        name = index_data[pos:pos+name_len].decode('utf-8','replace').rstrip('\x00'); pos += name_len
        entry_offset, _, entry_size = struct.unpack_from('<QQQ', index_data, pos); pos += 24
        pos += 21  # flags, hash, etc.
        safe_name = re.sub(r'[-<>:"/\\|?*]','', name).strip()
        if not safe_name:
            continue
        file_out = out_path / safe_name
        file_out.parent.mkdir(parents=True, exist_ok=True)
        try:
            raw = data[entry_offset:entry_offset+entry_size]
            # try zlib decompress
            try:
                raw = zlib.decompress(raw)
            except Exception:
                pass
            file_out.write_bytes(raw)
        except Exception:
            pass

def action_clean_all():
    try:
        xvaLuex_dir = Path("/storage/emulated/0/Documents/JINSHIFORYOU/xvaLuex")

        if xvaLuex_dir.exists():
            console.print(f"[bold {WARN}]◆ {t('cleanup_found')}  [dim]· {CREDIT}[/dim][/bold {WARN}]")
            shutil.rmtree(xvaLuex_dir)
            console.print(f"[bold {SUCCESS}]◆ {t('cleanup_removed')}  [dim]· {CREDIT}[/dim][/bold {SUCCESS}]")
        else:
            console.print(f"[dim]◆ {t('cleanup_none')}  · {CREDIT}[/dim]")

        temp_files = list(Path("/storage/emulated/0/Documents/JINSHIFORYOU").glob("*.temp.std.luac"))
        if temp_files:
            for f in temp_files:
                try:
                    f.unlink()
                except:
                    pass
            console.print(f"[{SUCCESS}]◆ {t('cleanup_temp', count=len(temp_files))}  · {CREDIT}[/{SUCCESS}]")

        cache_dirs = list(Path("/storage/emulated/0/Documents/JINSHIFORYOU").glob("__pycache__"))
        for cache_dir in cache_dirs:
            try:
                shutil.rmtree(cache_dir)
                console.print(f"[{SUCCESS}]◆ {t('cleanup_cache', path=cache_dir)}  · {CREDIT}[/{SUCCESS}]")
            except:
                pass

        console.print(f"[bold {SUCCESS}]◆ {t('cleanup_done')}  · {CREDIT}[/bold {SUCCESS}]")
    except Exception as e:
        console.print(f"[{ERR}]◆ {t('cleanup_error', err=e)}  · {CREDIT}[/{ERR}]")

    safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')

def action_close_termux():
    try:
        console.print()
        ab = AnimatedBorder.get_instance()
        border_color = ab.get_moving_border_style(6, 0.7)
        ab2 = AnimatedBorder.get_instance()
        cc = ab2.get_moving_border_style(0, 0.5)
        console.print()
        console.print(f"  [{cc}]╔{'═'*48}╗[/{cc}]")
        console.print(f"  [{cc}]║[/{cc}]  [bold {NEON}]◈  {TOOL_NAME}  —  See you next time!  ◈[/bold {NEON}]  [{cc}]║[/{cc}]")
        console.print(f"  [{cc}]╠{'─'*48}╣[/{cc}]")
        console.print(f"  [{cc}]║[/{cc}]  [bold {ICE}]DEVELOPER[/bold {ICE}]  :  @JINSHIFORYOU                      [{cc}]║[/{cc}]")
        console.print(f"  [{cc}]║[/{cc}]  [bold {ICE}]CREDIT   [/bold {ICE}]  :  {CREDIT}                    [{cc}]║[/{cc}]")
        console.print(f"  [{cc}]║[/{cc}]  [bold {ICE}]VERSION  [/bold {ICE}]  :  {TOOL_VERSION}                  [{cc}]║[/{cc}]")
        console.print(f"  [{cc}]╚{'═'*48}╝[/{cc}]")
        console.print()
        time.sleep(1.5)

        if sys.platform != 'win32':
            sys.stdout.flush()
            sys.stderr.flush()
            os.system('pkill -9 -f com.termux 2>/dev/null')
            os._exit(0)
        else:
            sys.exit(0)
    except Exception as e:
        console.print(f"[{WARN}]{t('force_closing')}  [dim]· {CREDIT}[/dim][/{WARN}]")
        try:
            os.system('pkill -9 -f com.termux 2>/dev/null')
        except:
            pass
        os._exit(0)

def action_repack_inject():
    pak_dir = PAK_DIR
    edit_dir = EDIT_DIR
    result_dir = RESULT_DIR

    if not pak_dir.exists():
        hexa_alert(t('pak_not_found', path=pak_dir), "error")
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    pak_file, _ = display_file_selector(t('select_repack'), pak_dir)
    if not pak_file:
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    if not edit_dir.exists() or not any(edit_dir.iterdir()):
        hexa_alert(t('no_files_compiled'), "error")
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    console.print()
    console.print(Panel(
        f"[bold {ICE}]{t('target_path_title')}[/bold {ICE}]\n"
        f"[dim]{t('target_path_example')}[/dim]\n"
        f"[dim]{t('credit_field')}: {CREDIT}[/dim]",
        border_style=ICE, box=ROUNDED, padding=(0, 2)
    ))

    console.print(f"[dim]{t('press_enter_default')}[/dim]")

    target_path = safe_input(f"\n[bold {GOLD}]{t('path_prompt')} [{CREDIT}]: [/bold {GOLD}]").strip()

    if not target_path:
        target_path = "Content/Lua/"
        console.print(f"[dim]{t('using_default', path=target_path)}[/dim]")
    else:
        console.print(f"[dim]{t('using_custom', path=target_path)}[/dim]")

    target_path = target_path.replace('\\', '/').strip('/')
    if not target_path:
        hexa_alert(t('invalid_target_path'), "error")
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    try:
        hexa_section(f"{t('repack')} {target_path} · {pak_file.name}")
        pak = TencentPakFile(pak_file)
        output_pak = result_dir / pak_file.name

        console.print(f"[bold {SUCCESS}]{t('auto_proceeding')}  [dim]· {CREDIT}[/dim][/bold {SUCCESS}]")

        count = repack_pak_file_full(pak, edit_dir, output_pak, target_path, force_add=True)
        if count > 0:
            hexa_alert(t('processed_files', count=count, path=target_path, output=output_pak), "success")
        else:
            hexa_alert(t('no_files_processed'), "error")
    except Exception as e:
        hexa_alert(t('repack_failed', err=e), "error")
        traceback.print_exc()
    safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')

def action_build_new_pak():
    pak_dir = PAK_DIR
    edit_dir = EDIT_DIR
    result_dir = RESULT_DIR

    if not pak_dir.exists():
        hexa_alert(t('pak_not_found', path=pak_dir), "error")
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    pak_file, _ = display_file_selector(t('select_template'), pak_dir)
    if not pak_file:
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    if not edit_dir.exists() or not any(edit_dir.iterdir()):
        hexa_alert(t('no_files_compiled'), "error")
        safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')
        return

    console.print()
    console.print(Panel(
        f"[bold {ICE}]{t('new_pak_title')}[/bold {ICE}]\n"
        f"[white]{t('new_pak_files_info')}[/white]\n"
        f"[dim]{t('target_path_example')}[/dim]\n"
        f"[dim]{t('new_pak_enter_root')}[/dim]\n"
        f"[dim]{t('credit_field')}: {CREDIT}[/dim]",
        border_style=ICE, box=ROUNDED, padding=(0, 2)
    ))

    target_path = safe_input(f"\n[bold {GOLD}]{t('target_path_enter_root')} [{CREDIT}]: [/bold {GOLD}]").strip()

    if target_path:
        target_path = target_path.replace('\\', '/').strip('/')
        console.print(f"[dim]{t('using_custom', path=target_path)}[/dim]")
    else:
        target_path = ""
        console.print(f"[dim]{t('no_path_root')}[/dim]")

    output_pak = result_dir / pak_file.name

    try:
        hexa_section(t('building_new_pak', name=pak_file.name))
        console.print(f"[bold {SUCCESS}]{t('auto_proceeding')}  [dim]· {CREDIT}[/dim][/bold {SUCCESS}]")
        count = build_new_pak_from_template(pak_file, edit_dir, output_pak, target_path)
        if count > 0:
            hexa_alert(t('new_pak_built', count=count), "success")
            hexa_alert(t('output', path=output_pak), "info")
        else:
            hexa_alert(t('build_no_files'), "error")
    except Exception as e:
        hexa_alert(t('build_failed', err=e), "error")
        traceback.print_exc()
    safe_input(f'\n[{ICE}]{t("press_enter")}[/{ICE}]')

def action_inject_lua():
    console.print()
    console.print(Rule(f"[bold {GOLD}]◈ {t('inject_title')} ◈[/bold {GOLD}]", style=GOLD))
    console.print(f"[white]{t('inject_desc')}  [dim]· {CREDIT}[/dim][/white]")
    console.print()

    edit_dir = EDIT_DIR
    out_path = RESULT_DIR
    pak_dir = PAK_DIR

    if not edit_dir.exists():
        edit_dir.mkdir(parents=True, exist_ok=True)
        console.print(f"[{WARN}]◆ {t('created_empty_folder', path=edit_dir)}  [dim]· {CREDIT}[/dim][/{WARN}]")
        console.print(f"[{WARN}]{t('add_lua_first')}  [dim]· {CREDIT}[/dim][/{WARN}]")
        safe_input(f"\n[{ICE}]{t('press_enter')}[/{ICE}]")
        return

    files_in_edit = [f for f in edit_dir.rglob("*") if f.is_file() and f.name not in ['pak_manifest.json','.DS_Store']]
    if not files_in_edit:
        console.print(f"[bold {ERR}]◆ {t('compiled_empty')}  [dim]({CREDIT})[/dim][/bold {ERR}]")
        console.print(f"[{ERR}]{t('put_lua_in', path=edit_dir)}  [dim]· {CREDIT}[/dim][/{ERR}]")
        safe_input(f"\n[{ICE}]{t('press_enter')}[/{ICE}]")
        return

    console.print()
    console.print(Rule(f"[bold {GOLD}]◈ {t('files_found')} ◈[/bold {GOLD}]", style=GOLD))
    files = []
    for idx, f in enumerate(files_in_edit, 1):
        rel_path = str(f.relative_to(edit_dir)).replace("\\", "/")
        files.append((f, rel_path))
        if len(rel_path) > 60:
            display_path = "..." + rel_path[-57:]
        else:
            display_path = rel_path
        console.print(f"  [bold {GOLD}][{idx}][/bold {GOLD}] {display_path}")

    console.print()
    console.print(f"[bold {ICE}]{t('enter_target_path')}[/bold {ICE}]  [dim]({CREDIT})[/dim]")
    console.print(f"[dim]{t('path_example_2')}[/dim]")
    console.print(f"[dim]{t('path_default_hint')}[/dim]")

    base_path = safe_input(f"\n[bold {GOLD}]{t('path_prompt')} [{CREDIT}]: [/bold {GOLD}]").strip()

    if not base_path:
        base_path = ""
        console.print(f"[dim]{t('no_base_path')}[/dim]")
    else:
        if not base_path.endswith('/'):
            base_path += '/'
        console.print(f"[dim]{t('using_custom', path=base_path)}[/dim]")

    file_locations = {}
    for f, rel_path in files:
        if base_path:
            file_locations[str(f)] = base_path + f.name
        else:
            file_locations[str(f)] = f.name

    console.print(f"\n[{SUCCESS}]◆ {t('files_will_inject', count=len(files))}  [dim]· {CREDIT}[/dim][/{SUCCESS}]")

    for f, loc in list(file_locations.items())[:5]:
        short_name = Path(f).name[:30] + "..." if len(Path(f).name) > 30 else Path(f).name
        console.print(f"  [dim]•[/dim] {short_name} → [{GOLD}]{loc}[/{GOLD}]")
    if len(file_locations) > 5:
        console.print(f"  [dim]{t('and_more', count=len(file_locations) - 5)}  · {CREDIT}[/dim]")

    console.print(f"\n[bold {SUCCESS}]{t('auto_proceeding_inject')}  [dim]· {CREDIT}[/dim][/bold {SUCCESS}]")

    console.print(f"[{ICE}]{t('searching_pak')}  [dim]({CREDIT})[/dim][/{ICE}]")
    pak_files = []
    for file in pak_dir.iterdir():
        if file.name.lower().endswith('.pak'):
            pak_files.append(file)

    if not pak_files:
        console.print(f"[bold {ERR}]◆ {t('no_pak_found')}  [dim]({CREDIT})[/dim][/bold {ERR}]")
        console.print(f"[{ERR}]{t('put_pak_in', path=pak_dir)}  [dim]· {CREDIT}[/dim][/{ERR}]")
        safe_input(f"\n[{ICE}]{t('press_enter')}[/{ICE}]")
        return

    if len(pak_files) == 1:
        pak_path = pak_files[0]
        console.print(f"[{SUCCESS}]◆ {t('found_pak', name=pak_path.name)}  [dim]· {CREDIT}[/dim][/{SUCCESS}]")
    else:
        console.print(f"[{WARN}]◆ {t('multiple_pak')}  [dim]({CREDIT})[/dim][/{WARN}]")
        for i, pak in enumerate(pak_files, 1):
            console.print(f"  [{i}] {pak.name}")
        console.print(f"\n[bold {GOLD}]{t('enter_number_select')} [{CREDIT}]:[/bold {GOLD}]")
        try:
            choice_pak = int(safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip())
            if 1 <= choice_pak <= len(pak_files):
                pak_path = pak_files[choice_pak - 1]
                console.print(f"[{SUCCESS}]◆ {t('selected', name=pak_path.name)}  · {CREDIT}[/{SUCCESS}]")
            else:
                console.print(f"[bold {ERR}]◆ {t('invalid_selection')}  [dim]({CREDIT})[/dim][/bold {ERR}]")
                safe_input(f"\n[{ICE}]{t('press_enter')}[/{ICE}]")
                return
        except:
            console.print(f"[bold {ERR}]◆ {t('invalid_input')}  [dim]({CREDIT})[/dim][/bold {ERR}]")
            safe_input(f"\n[{ICE}]{t('press_enter')}[/{ICE}]")
            return

    BACKUP_FOLDER = PAK_DIR.parent / "BACKUP"
    BACKUP_FOLDER.mkdir(exist_ok=True)
    backup_name = f"{pak_path.stem}_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pak"
    backup_path = BACKUP_FOLDER / backup_name
    shutil.copy2(pak_path, backup_path)
    console.print(f"[bold {SUCCESS}]◆ {t('backup_created', path=backup_path)}  · {CREDIT}[/bold {SUCCESS}]")

    try:
        console.print(f"[{ICE}]{t('loading_pak')}  [dim]({CREDIT})[/dim][/{ICE}]")
        pak = TencentPakFile(PurePath(pak_path))
        output_name = f"{pak_path.stem}_MODIFIED.pak"
        output_pak = out_path / output_name

        console.print(f"[{ICE}]{t('repacking_pak')}  [dim]({CREDIT})[/dim][/{ICE}]")

        dominant = pak.detect_dominant_style()
        console.print(f"[{ICE}]{t('dominant_style', comp=dominant['comp_method'], enc=dominant['enc_method'], encrypted=dominant['encrypted'], block=dominant['block_size'])}  · {CREDIT}[/{ICE}]")

        inject_plan = []
        for f, rel_path in files:
            internal_path = file_locations.get(str(f), f.name)

            if internal_path.startswith('/'):
                internal_path = internal_path[1:]

            inject_plan.append({
                'src_path': f,
                'internal_path': internal_path,
                'comp_method': dominant['comp_method'],
                'enc_method': dominant['enc_method'],
                'encrypted': dominant['encrypted'],
                'block_size': dominant['block_size'],
            })

        console.print(f"[{SUCCESS}]{t('plan_files', count=len(inject_plan))}  · {CREDIT}[/{SUCCESS}]")

        pak.inject_files(inject_plan, Path(output_pak))
        console.print(f"[bold {SUCCESS}]◆ {t('repack_complete_msg', path=output_pak)}  · {CREDIT}[/bold {SUCCESS}]")
        console.print(f"[{SUCCESS}]{t('processed_with_locations', count=len(inject_plan))}  · {CREDIT}[/{SUCCESS}]")

    except Exception as e:
        console.print(f"[bold {ERR}]◆ {t('error_label', err=e)}  [dim]({CREDIT})[/dim][/bold {ERR}]")
        import traceback
        traceback.print_exc()

    safe_input(f"\n[{ICE}]{t('press_enter')}[/{ICE}]")

def select_language():
    global LANG_CODE
    os.system('cls' if os.name == 'nt' else 'clear')
    ab = AnimatedBorder.get_instance()
    c1 = ab.get_moving_border_style(0, 0.6)
    c2 = ab.get_moving_border_style(6, 0.6)

    console.print()
    console.print(f"[bold {c1}]╔══════════════════════════════════════════════════════════════════╗[/bold {c1}]")
    console.print(f"[bold {c1}]║[/bold {c1}]        [bold {NEON}]◈  {TOOL_NAME}  ◈[/bold {NEON}]          [bold {c1}]║[/bold {c1}]")
    console.print(f"[bold {c2}]╠══════════════════════════════════════════════════════════════════╣[/bold {c2}]")
    console.print(f"[bold {c2}]║[/bold {c2}]        [bold {ICE}]🌐 SELECT LANGUAGE  /  ВЫБОР ЯЗЫКА[/bold {ICE}]              [bold {c2}]║[/bold {c2}]")
    console.print(f"[bold {c2}]║[/bold {c2}]        [bold {ICE}]اختر اللغة  /  选择语言[/bold {ICE}]                       [bold {c2}]║[/bold {c2}]")
    console.print(f"[bold {c1}]╚══════════════════════════════════════════════════════════════════╝[/bold {c1}]")
    console.print()

    lang_table = Table(box=ROUNDED, show_header=False, padding=(0, 3), border_style=NEON)
    lang_table.add_column(justify="right", style=f"bold {NEON}", width=4)
    lang_table.add_column(justify="left", style=f"bold {ICE}", min_width=20)

    lang_table.add_row("[1]", "English")
    lang_table.add_row("[2]", "Русский (Russian)")
    lang_table.add_row("[3]", "العربية (Arabic)")
    lang_table.add_row("[4]", "中文 (Chinese)")

    console.print(Panel(lang_table, title=f"[bold {NEON}]◈ 🌐 ◈  ·  {CREDIT}[/bold {NEON}]",
                        border_style=NEON, box=HEAVY, padding=(1, 3)))
    console.print()

    while True:
        choice = safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip()
        if choice == '1':
            LANG_CODE = 'en'; break
        elif choice == '2':
            LANG_CODE = 'ru'; break
        elif choice == '3':
            LANG_CODE = 'ar'; break
        elif choice == '4':
            LANG_CODE = 'zh'; break
        else:
            console.print(f"  [{ERR}]◆ {STRINGS['en']['invalid_lang']}[/{ERR}]")

    os.system('cls' if os.name == 'nt' else 'clear')

def _print_menu_item(num, icon, name, desc, c_num, c_name, c_desc):
    console.print(
        f"  [{c_num}][{num}][/{c_num}]"
        f"  {icon}  "
        f"[bold {c_name}]{name:<18}[/bold {c_name}]"
        f"  [{c_desc}]{desc}[/{c_desc}]"
    )

def main_menu():
    setup_directories()
    ab = AnimatedBorder.get_instance()

    MENU_ITEMS = [
        ("1", "📦", "UNPACK PAK",      "extract all entries from a .pak file"),
        ("2", "🔧", "LUA MAKE",        "decompile & recompile .luac bytecode"),
        ("3", "🔁", "REPACK LUA PAK",  "inject files into a pak at target path"),
        ("4", "🏗",  "BUILD NEW PAK",   "build a brand new PAK from template"),
        ("5", "💉", "INJECT LUA",      "inject Lua directly — no firewall"),
        ("6", "🧹", "CLEAN ALL",       "remove the JINSHIFORYOU work directory"),
        ("7", "🚪", "EXIT",            "close the tool"),
    ]

    while True:
        print_main_banner(key_info=None)
        c1 = ab.get_moving_border_style(0, 0.4)
        c2 = ab.get_moving_border_style(5, 0.4)

        console.print(f"  [{c1}]┌{'─'*62}┐[/{c1}]")
        console.print(f"  [{c1}]│[/{c1}]  [bold {NEON}]◈  MAIN MENU  ·  {CREDIT:<38}[/bold {NEON}]  [{c1}]│[/{c1}]")
        console.print(f"  [{c1}]├{'─'*62}┤[/{c1}]")
        for num, icon, name, desc in MENU_ITEMS:
            console.print(
                f"  [{c1}]│[/{c1}]  "
                f"[bold {NEON}][{num}][/bold {NEON}]  {icon}  "
                f"[bold {ICE}]{name:<18}[/bold {ICE}]"
                f"  [{MUTED}]{desc}[/{MUTED}]"
            )
        console.print(f"  [{c1}]└{'─'*62}┘[/{c1}]")
        console.print()
        console.print(f"  [bold {NEON}]◈[/bold {NEON}]  [bold {ICE}]Select option :[/bold {ICE}]  [dim]· {CREDIT}[/dim]")
        choice = safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip()

        if choice == '1':
            action_unpack_pak()
        elif choice == '2':
            lua_mode_menu()
        elif choice == '3':
            action_repack_inject()
        elif choice == '4':
            action_build_new_pak()
        elif choice == '5':
            action_inject_lua()
        elif choice == '6':
            action_clean_all()
        elif choice == '7':
            action_close_termux()
            break
        else:
            hexa_alert(t('invalid_choice'), "error")
            time.sleep(1.5)

def lua_mode_menu():
    ab = AnimatedBorder.get_instance()

    LUA_ITEMS = [
        ("1", "⚙", "RECOMPILE",  "LUA_EDIT  ──▶  COMPILED"),
        ("2", "🔓", "DECOMPILE",  "LUA_ORIGINAL ──▶ LUA_EDIT"),
        ("3", "↩", "BACK",       "return to main menu"),
    ]

    while True:
        print_main_banner("LUA MAKE ENGINE")
        c1 = ab.get_moving_border_style(2, 0.4)

        console.print(f"  [{c1}]┌{'─'*54}┐[/{c1}]")
        console.print(f"  [{c1}]│[/{c1}]  [bold {ICE}]◈  LUA MAKE  ·  {CREDIT:<32}[/bold {ICE}]  [{c1}]│[/{c1}]")
        console.print(f"  [{c1}]├{'─'*54}┤[/{c1}]")
        for num, icon, name, desc in LUA_ITEMS:
            console.print(
                f"  [{c1}]│[/{c1}]  "
                f"[bold {NEON}][{num}][/bold {NEON}]  {icon}  "
                f"[bold {ICE}]{name:<14}[/bold {ICE}]"
                f"  [{MUTED}]{desc}[/{MUTED}]"
            )
        console.print(f"  [{c1}]└{'─'*54}┘[/{c1}]")
        console.print()
        console.print(f"  [bold {NEON}]◈[/bold {NEON}]  [bold {ICE}]Select option :[/bold {ICE}]  [dim]· {CREDIT}[/dim]")
        choice = safe_input(f"  [{SUCCESS}]└─▶[/{SUCCESS}] ").strip()

        if choice == '1':
            action_repack_unpack()
        elif choice == '2':
            action_unpack()
        elif choice == '3':
            return
        else:
            hexa_alert(t('invalid_option'), "error")
            time.sleep(1)

if __name__ == "__main__":
    LANG_CODE = "en"

    # Splash screen
    os.system('cls' if os.name == 'nt' else 'clear')
    ab = AnimatedBorder.get_instance()
    c1 = ab.get_moving_border_style(0, 0.5)
    c2 = ab.get_moving_border_style(4, 0.5)
    c3 = ab.get_moving_border_style(8, 0.5)

    logo = [
        " ██████╗ ███████╗███╗  ██╗███╗  ██╗███████╗ ██████╗ ██╗  ██╗██╗  ██╗",
        " ██╔══██╗██╔════╝████╗ ██║████╗ ██║╚══███╔╝██╔═══██╗██║  ██║██║  ██║",
        " ██████╔╝█████╗  ██╔██╗██║██╔██╗██║  ███╔╝ ██║   ██║███████║███████║",
        " ██╔══██╗██╔══╝  ██║╚████║██║╚████║ ███╔╝  ██║   ██║██╔══██║██╔══██║",
        " ██║  ██║███████╗██║ ╚███║██║ ╚███║███████╗╚██████╔╝██║  ██║██║  ██║",
        " ╚═╝  ╚═╝╚══════╝╚═╝  ╚══╝╚═╝  ╚══╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝",
    ]
    logo_colors = [NEON, NEON, ICE, ICE, MAGENTA, PURPLE]
    console.print()
    for line, color in zip(logo, logo_colors):
        console.print(f"[bold {color}]{line}[/bold {color}]")
    console.print()
    console.print(f"  [bold {c1}]{'─'*66}[/bold {c1}]")
    console.print(f"  [bold {NEON}]  ⚡  {TOOL_VERSION}  ·  PAK TOOLS + LUA ENGINE  ·  NO LOGIN REQUIRED  ⚡[/bold {NEON}]")
    console.print(f"  [bold {MAGENTA}]  ✦  DEVELOPER : @JINSHIFORYOU   ·   CREDIT : {CREDIT}   ·   LIFETIME ACCESS  ✦[/bold {MAGENTA}]")
    console.print(f"  [bold {c1}]{'─'*66}[/bold {c1}]")
    console.print()
    console.print(f"  [bold {ICE}]  Workspace : /storage/emulated/0/Documents/JINSHIFORYOU/[/bold {ICE}]")
    console.print(f"  [dim]  All files will be organized inside the JINSHIFORYOU folder.[/dim]")
    console.print()
    time.sleep(1.2)

    try:
        main_menu()
    except KeyboardInterrupt:
        console.print(f"\n[bold {WARN}]  Interrupted. Exiting...  [dim]({CREDIT})[/dim][/bold {WARN}]")
        sys.exit(0)
    except Exception as e:
        console.print(f"[bold {ERR}]  FATAL: {escape(str(e))}  [dim]({CREDIT})[/dim][/bold {ERR}]")
        traceback.print_exc()
        safe_input(f'\n  Press Enter to exit...')
        sys.exit(1)