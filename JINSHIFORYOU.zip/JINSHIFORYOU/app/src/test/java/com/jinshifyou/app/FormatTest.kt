package com.jinshifyou.app

import com.jinshifyou.app.engine.Format
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FormatTest {

    @Test
    fun humanSize_bytes() {
        assertEquals("512 B", Format.humanSize(512L))
    }

    @Test
    fun humanSize_kilobytes() {
        assertEquals("1.0 KB", Format.humanSize(1024L))
    }

    @Test
    fun humanSize_megabytes() {
        assertEquals("2.5 MB", Format.humanSize((2.5 * 1024 * 1024).toLong()))
    }

    @Test
    fun shortError_takesFirstLineOnly() {
        val raw = "first line\nsecond line\nthird"
        assertEquals("first line", Format.shortError(raw))
    }

    @Test
    fun shortError_truncatesLongLines() {
        val raw = "x".repeat(500)
        assertTrue(Format.shortError(raw).length <= 161)
    }
}
